package bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;

//Resultado do relacionamento
public class Receita {
	private String codigo_R;
	private String medicamento;
	private String dose_diaria;
	private String tempo_tratamento;
	private String CPF_Veterinario;
	private String CPF_Cliente;
	private String codigo_de_um_animal;
	private String data_hora;
	
	public Receita(String codigo_R, String medicamento, String dose_diaria, String tempo_tratamento,
			String cPF_Veterinario, String cPF_Cliente, String codigo_de_um_animal, String data_hora) {
		super();
		this.codigo_R = codigo_R;
		this.medicamento = medicamento;
		this.dose_diaria = dose_diaria;
		this.tempo_tratamento = tempo_tratamento;
		CPF_Veterinario = cPF_Veterinario;
		CPF_Cliente = cPF_Cliente;
		this.codigo_de_um_animal = codigo_de_um_animal;
		this.data_hora = data_hora;
	}
	
	public Receita() {
		
	}

	public String getCodigo_R() {
		return codigo_R;
	}

	public void setCodigo_R(String codigo_R) {
		this.codigo_R = codigo_R;
	}

	public String getMedicamento() {
		return medicamento;
	}

	public void setMedicamento(String medicamento) {
		this.medicamento = medicamento;
	}

	public String getDose_diaria() {
		return dose_diaria;
	}

	public void setDose_diaria(String dose_diaria) {
		this.dose_diaria = dose_diaria;
	}

	public String getTempo_tratamento() {
		return tempo_tratamento;
	}

	public void setTempo_tratamento(String tempo_tratamento) {
		this.tempo_tratamento = tempo_tratamento;
	}

	public String getCPF_Veterinario() {
		return CPF_Veterinario;
	}

	public void setCPF_Veterinario(String cPF_Veterinario) {
		CPF_Veterinario = cPF_Veterinario;
	}

	public String getCPF_Cliente() {
		return CPF_Cliente;
	}

	public void setCPF_Cliente(String cPF_Cliente) {
		CPF_Cliente = cPF_Cliente;
	}

	public String getCodigo_de_um_animal() {
		return codigo_de_um_animal;
	}

	public void setCodigo_de_um_animal(String codigo_de_um_animal) {
		this.codigo_de_um_animal = codigo_de_um_animal;
	}

	public String getData_hora() {
		return data_hora;
	}

	public void setData_hora(String data_hora) {
		this.data_hora = data_hora;
	}
	
	public boolean verificaData(String dataHora) {
		boolean achou = false;
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {
		    df.parse (dataHora);
		    // data v�lida
		    achou = true;
		} catch (ParseException ex) {
		   // data inv�lida
			achou = false;
		}
		
		return achou;
	}

	@Override
	public String toString() {
		return "Receita [codigo_R=" + codigo_R + ", medicamento=" + medicamento + ", dose_diaria=" + dose_diaria
				+ ", tempo_tratamento=" + tempo_tratamento + ", CPF_Veterinario=" + CPF_Veterinario + ", CPF_Cliente="
				+ CPF_Cliente + ", codigo_de_um_animal=" + codigo_de_um_animal + ", data_hora=" + data_hora + "]";
	}
	
	

}
