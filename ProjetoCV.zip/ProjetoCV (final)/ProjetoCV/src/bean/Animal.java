package bean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Animal {
	private String CPF_Cli;
	private String codigo;
	private String nome;
	private String raca;
	private String data_nas;
	private String especie;
	private String porte;

	public Animal(String cPF_Cli, String codigo, String nome, String raca, String data_nas, String especie, String porte) {
		super();
		CPF_Cli = cPF_Cli;
		this.codigo = codigo;
		this.nome = nome;
		this.raca = raca;
		this.data_nas = data_nas;
		this.especie = especie;
		this.porte = porte;
	}
	
	public Animal() {
		
	}

	public String getCPF_Cli() {
		return CPF_Cli;
	}

	public void setCPF_Cli(String cPF_Cli) {
		CPF_Cli = cPF_Cli;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRaca() {
		return raca;
	}

	public void setRaca(String raca) {
		this.raca = raca;
	}

	public String getData_nas() {
		return data_nas;
	}

	public void setData_nas(String data_nas) {
		this.data_nas = data_nas;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public String getPorte() {
		return porte;
	}

	public void setPorte(String porte) {
		this.porte = porte;
	}
	
	public boolean verificaData(String data) {
		boolean achou = false;
		DateFormat df = new SimpleDateFormat ("yyyy-MM-dd");
		df.setLenient (false); 
		try {
		    df.parse (data);
		    // data v�lida
		    achou = true;
		} catch (ParseException ex) {
		   // data inv�lida
			achou = false;
		}
		
		return achou;
	}

	@Override
	public String toString() {
		return "Animal [CPF_Cli=" + CPF_Cli + ", codigo=" + codigo + ", nome=" + nome + ", raca=" + raca + ", data_nas="
				+ data_nas + ", especie=" + especie + ", porte=" + porte + "]";
	}

	
	
	

}
