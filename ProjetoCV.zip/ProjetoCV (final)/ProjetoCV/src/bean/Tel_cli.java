package bean;

public class Tel_cli {
	private String CPF_Cliente;
	private String telefone_cli;
	public Tel_cli(String cPF_Cliente, String telefone) {
		super();
		CPF_Cliente = cPF_Cliente;
		this.telefone_cli = telefone;
	}
	public Tel_cli() {
		
	}
	public String getCPF_Cliente() {
		return CPF_Cliente;
	}
	public void setCPF_Cliente(String cPF_Cliente) {
		CPF_Cliente = cPF_Cliente;
	}
	public String getTelefone_cli() {
		return telefone_cli;
	}
	public void setTelefone_cli(String telefone) {
		this.telefone_cli = telefone;
	}
	@Override
	public String toString() {
		return "Tel_cli [CPF_Cliente=" + CPF_Cliente + ", telefone=" + telefone_cli + "]";
	}
	
	

}
