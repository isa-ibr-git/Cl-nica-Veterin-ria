package bean;

import java.util.ArrayList;


public class Cliente {
	private String CPF;
	private String RG;
	private String nome;
	private String email;
	private String cep;
	private int numero;
	private String logradouro;
	private String cidade;
	private String bairro;
	private String estado;
	private String pais;
	private ArrayList <Cliente> clientes;
	
	
	

	public Cliente(String cPF, String rG, String nome, String email, String cep, int numero, String logradouro,
			String cidade, String bairro, String estado, String pais) {
		super();
		CPF = cPF;
		RG = rG;
		this.nome = nome;
		this.email = email;
		this.cep = cep;
		this.numero = numero;
		this.logradouro = logradouro;
		this.cidade = cidade;
		this.bairro = bairro;
		this.estado = estado;
		this.pais = pais;
	}
	
	public Cliente() {
		
	}
	
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	public String getRG() {
		return RG;
	}
	public void setRG(String rG) {
		RG = rG;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	
	public ArrayList<Cliente> getClientes() {
		return clientes;
	}
	


	@Override
	public String toString() {
		return "Cliente [CPF=" + CPF + ", RG=" + RG + ", nome=" + nome + ", email=" + email + ", cep=" + cep
				+ ", numero=" + numero + ", logradouro=" + logradouro + ", cidade=" + cidade + ", bairro=" + bairro
				+ ", estado=" + estado + ", pais=" + pais + "]";
	}
	
	

}
