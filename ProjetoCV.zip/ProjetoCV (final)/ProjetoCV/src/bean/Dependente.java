package bean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Dependente {
	private String cpf_func;
	private String nome;
	private String data_nas;
	private String sexo;
	public Dependente(String cpf_func, String nome, String data_nas, String sexo) {
		super();
		this.cpf_func = cpf_func;
		this.nome = nome;
		this.data_nas = data_nas;
		this.sexo = sexo;
	}
	
	public Dependente() {
		
	}

	public String getCpf_func() {
		return cpf_func;
	}

	public void setCpf_func(String cpf_func) {
		this.cpf_func = cpf_func;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getData_nas() {
		return data_nas;
	}

	public void setData_nas(String data_nas) {
		this.data_nas = data_nas;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	public boolean verificaData(String data) {
		boolean achou = false;
		DateFormat df = new SimpleDateFormat ("yyyy-MM-dd");
		df.setLenient (false); 
		try {
		    df.parse (data);
		    // data v�lida
		    achou = true;
		} catch (ParseException ex) {
		   // data inv�lida
			achou = false;
		}
		
		return achou;
	}

	@Override
	public String toString() {
		return "Dependente [cpf_func=" + cpf_func + ", nome=" + nome + ", data_nas=" + data_nas + ", sexo=" + sexo
				+ "]";
	}
	
	

}
