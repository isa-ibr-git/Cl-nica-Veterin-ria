package bean;

public class Veterinario {
	private String CPF_Func;
	private String CRV;
	private String nro_cartao;
	private String nome;
	private String RG;
	private String data_nascimento;
	private double salario;
	private String CEP;
	private int numero;
	private String logradouro;
	private String cidade;
	private String bairro;
	private String estado;
	private String pais;
	private String instituicao;
	private String data_conclusao;

	
	
	public Veterinario(String cPF_Func, String cRV, String nro_cartao, String nome, String rG, String dataNas, double salario, String cEP, int numero, String logradouro, String cidade, String bairro, String estado,
			String pais, String instituicao, String data_conclusao) {
		super();
		CPF_Func = cPF_Func;
		CRV = cRV;
		this.nro_cartao = nro_cartao;
		this.nome = nome;
		RG = rG;
		this.data_nascimento = dataNas;
		this.salario = salario;
		CEP = cEP;
		this.numero = numero;
		this.logradouro = logradouro;
		this.cidade = cidade;
		this.bairro = bairro;
		this.estado = estado;
		this.pais = pais;
		this.instituicao = instituicao;
		this.data_conclusao = data_conclusao;
	}

	public Veterinario() {
		
	}

	public String getCPF_Func() {
		return CPF_Func;
	}

	public void setCPF_Func(String cPF_Func) {
		CPF_Func = cPF_Func;
	}

	public String getCRV() {
		return CRV;
	}

	public void setCRV(String cRV) {
		CRV = cRV;
	}

	public String getNro_cartao() {
		return nro_cartao;
	}

	public void setNro_cartao(String nro_cartao) {
		this.nro_cartao = nro_cartao;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRG() {
		return RG;
	}

	public void setRG(String rG) {
		RG = rG;
	}

	public String getData_nascimento() {
		return data_nascimento;
	}

	public void setData_nascimento(String data_nascimento) {
		this.data_nascimento = data_nascimento;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	public String getCEP() {
		return CEP;
	}

	public void setCEP(String cEP) {
		CEP = cEP;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getInstituicao() {
		return instituicao;
	}

	public void setInstituicao(String instituicao) {
		this.instituicao = instituicao;
	}

	public String getData_conclusao() {
		return data_conclusao;
	}

	public void setData_conclusao(String data_conclusao) {
		this.data_conclusao = data_conclusao;
	}

	@Override
	public String toString() {
		return "Veterinario [CPF_Func=" + CPF_Func + ", CRV=" + CRV + ", nro_cartao=" + nro_cartao + ", nome=" + nome
				+ ", RG=" + RG + ", data_nascimento=" + data_nascimento + ", salario=" + salario + ", CEP=" + CEP
				+ ", numero=" + numero + ", logradouro=" + logradouro + ", cidade=" + cidade + ", bairro=" + bairro
				+ ", estado=" + estado + ", pais=" + pais + ", instituicao=" + instituicao + ", data_conclusao="
				+ data_conclusao + "]";
	}
	
	

}