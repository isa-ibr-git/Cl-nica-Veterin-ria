package bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

//Resultado do relacionamento
public class Exame {
	private String codigo_exame;
	private String CPF_Veterinario;
	private String CPF_Cliente;
	private String codigo_animal;
	private String data_hora;
	private ArrayList <Exame> exames;
	public Exame(String codigo_exame, String cPF_Veterinario, String cPF_Cliente, String codigo_animal,
			String data_hora) {
		super();
		this.codigo_exame = codigo_exame;
		CPF_Veterinario = cPF_Veterinario;
		CPF_Cliente = cPF_Cliente;
		this.codigo_animal = codigo_animal;
		this.data_hora = data_hora;
	}
	
	public Exame() {
		
	}

	public String getCodigo_exame() {
		return codigo_exame;
	}

	public void setCodigo_exame(String codigo_exame) {
		this.codigo_exame = codigo_exame;
	}

	public String getCPF_Veterinario() {
		return CPF_Veterinario;
	}

	public void setCPF_Veterinario(String cPF_Veterinario) {
		CPF_Veterinario = cPF_Veterinario;
	}

	public String getCPF_Cliente() {
		return CPF_Cliente;
	}

	public void setCPF_Cliente(String cPF_Cliente) {
		CPF_Cliente = cPF_Cliente;
	}

	public String getCodigo_animal() {
		return codigo_animal;
	}

	public void setCodigo_animal(String codigo_animal) {
		this.codigo_animal = codigo_animal;
	}

	public String getData_hora() {
		return data_hora;
	}

	public void setData_hora(String data_hora) {
		this.data_hora = data_hora;
	}
	
	
	
	public ArrayList<Exame> getExames() {
		return exames;
	}

	public void addExame(Exame ex) {
		if(exames == null) {
			exames = new ArrayList<>();
		}
		exames.add(ex);
	}

	public boolean verificaData(String dataHora) {
		boolean achou = false;
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {
		    df.parse (dataHora);
		    // data v�lida
		    achou = true;
		} catch (ParseException ex) {
		   // data inv�lida
			achou = false;
		}
		
		return achou;
	}
	@Override
	public String toString() {
		return "Exame [codigo_exame=" + codigo_exame + ", CPF_Veterinario=" + CPF_Veterinario + ", CPF_Cliente="
				+ CPF_Cliente + ", codigo_animal=" + codigo_animal + ", data_hora=" + data_hora + "]";
	}
	
	
}
