package bean;

public class Tel_vet {
	private String CPF_Veterinario;
	private String telefone_vet;
	public Tel_vet(String cPF_Veterinario, String telefone_vet) {
		super();
		CPF_Veterinario = cPF_Veterinario;
		this.telefone_vet = telefone_vet;
	}
	
	public Tel_vet() {
		
	}
	public String getCPF_Veterinario() {
		return CPF_Veterinario;
	}
	public void setCPF_Veterinario(String cPF_Veterinario) {
		CPF_Veterinario = cPF_Veterinario;
	}
	public String getTelefone_vet() {
		return telefone_vet;
	}
	public void setTelefone_vet(String telefone_vet) {
		this.telefone_vet = telefone_vet;
	}
	@Override
	public String toString() {
		return "Tel_vet [CPF_Veterinario=" + CPF_Veterinario + ", telefone_vet=" + telefone_vet + "]";
	}
	
	

}
