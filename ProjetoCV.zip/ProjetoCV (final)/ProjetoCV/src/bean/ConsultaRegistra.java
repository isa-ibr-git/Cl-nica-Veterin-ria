package bean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

//Esse � o relacionamento
public class ConsultaRegistra {
	private String CPF_Veterinairo;
	private String CPF_Cliente;
	private String codigo_animal;
	private String data_hora;
	private Double valor;
	private String diagnostico;
	
	public ConsultaRegistra(String cPF_Veterinairo, String cPF_Cliente, String codigo_animal, String data_hora,
			Double valor, String diagnostico) {
		super();
		CPF_Veterinairo = cPF_Veterinairo;
		CPF_Cliente = cPF_Cliente;
		this.codigo_animal = codigo_animal;
		this.data_hora = data_hora;
		this.valor = valor;
		this.diagnostico = diagnostico;
	}
	
	public ConsultaRegistra() {
		
	}

	public String getCPF_Veterinairo() {
		return CPF_Veterinairo;
	}

	public void setCPF_Veterinairo(String cPF_Veterinairo) {
		CPF_Veterinairo = cPF_Veterinairo;
	}

	public String getCPF_Cliente() {
		return CPF_Cliente;
	}

	public void setCPF_Cliente(String cPF_Cliente) {
		CPF_Cliente = cPF_Cliente;
	}

	public String getCodigo_animal() {
		return codigo_animal;
	}

	public void setCodigo_animal(String codigo_animal) {
		this.codigo_animal = codigo_animal;
	}

	public String getData_hora() {
		return data_hora;
	}

	public void setData_hora(String data_hora) {
		this.data_hora = data_hora;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public String getDiagnostico() {
		return diagnostico;
	}

	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}
	
	public boolean verificaData(String dataHora) {
		boolean achou = false;
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {
		    df.parse (dataHora);
		    // data v�lida
		    achou = true;
		} catch (ParseException ex) {
		   // data inv�lida
			achou = false;
		}
		
		return achou;
	}

	@Override
	public String toString() {
		return "ConsultaRegistra [CPF_Veterinairo=" + CPF_Veterinairo + ", CPF_Cliente=" + CPF_Cliente
				+ ", codigo_animal=" + codigo_animal + ", data_hora=" + data_hora + ", valor=" + valor
				+ ", diagnostico=" + diagnostico + "]";
	}
	
	

}
