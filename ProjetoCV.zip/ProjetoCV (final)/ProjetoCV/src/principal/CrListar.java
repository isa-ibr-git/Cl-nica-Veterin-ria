package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.ConsultaRegistraDAO;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CrListar extends JFrame {

	private JPanel contentPane;
	private JTable table;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrListar frame = new CrListar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public CrListar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CrListar.class.getResource("/img/listar.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 625, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(crdao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					model.addRow(new Object[] {"", "", "", "", "", ""});
				}else {
					
					for(int i = 0; i<crdao.getLista().size(); i++) {
						model.addRow(new Object[] {crdao.getLista().get(i).getCPF_Veterinairo(), crdao.getLista().get(i).getCPF_Cliente(), crdao.getLista().get(i).getCodigo_animal(),
								crdao.getLista().get(i).getData_hora(), crdao.getLista().get(i).getValor(), crdao.getLista().get(i).getDiagnostico()});
					}
				}
			}
		});
		btnNewButton.setBounds(10, 26, 89, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 60, 589, 190);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF V.", "CPF C.", "C\u00F3digo A.", "Data e hora", "Valor", "Diagn\u00F3stico"
			}
		));
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(510, 26, 89, 23);
		contentPane.add(btnNewButton_1);
		centralizarComponente();
	}
}
