package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Animal;
import bean.Veterinario;
import dao.AnimalDAO;
import dao.ClienteDAO;
import dao.VeterinarioDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class AnimalAlterar extends JFrame {

	private JPanel contentPane;
	ClienteDAO cdao = new ClienteDAO();
	AnimalDAO adao = new AnimalDAO();
	private JTextField tfNome;
	private JTextField tfRaca;
	private JTextField tfEspecie;
	private JTextField tfDataNas;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimalAlterar frame = new AnimalAlterar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
	}

	/**
	 * Create the frame.
	 */
	public AnimalAlterar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AnimalAlterar.class.getResource("/img/lapis (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblCpfDoCliente = new JLabel("CPF do Cliente:");
		lblCpfDoCliente.setForeground(Color.WHITE);
		lblCpfDoCliente.setBounds(20, 44, 74, 24);
		contentPane.add(lblCpfDoCliente);

		JLabel lblCdigoDoAnimal = new JLabel("C\u00F3digo do animal:");
		lblCdigoDoAnimal.setForeground(Color.WHITE);
		lblCdigoDoAnimal.setBounds(20, 84, 101, 24);
		contentPane.add(lblCdigoDoAnimal);



		JComboBox comboBoxCpf = new JComboBox();
		comboBoxCpf.setBounds(131, 45, 106, 22);
		ArrayList <String > linha = new ArrayList<>();

		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}

		for(int j=0; j < linha.size(); j++) {

			comboBoxCpf.addItem(linha.get(j));

		}
		contentPane.add(comboBoxCpf);

		JComboBox comboBoxCod = new JComboBox();
		comboBoxCod.setBounds(131, 85, 106, 22);
		ArrayList <String > linhaC = new ArrayList<>();
		for(int k = 0; k < adao.getLista().size(); k++) {
			linhaC.add(adao.getLista().get(k).getCodigo());

		}
		for(int l = 0; l < linhaC.size(); l++ ) {
			comboBoxCod.addItem(linhaC.get(l));
		}
		contentPane.add(comboBoxCod);

		JComboBox comboBoxPorte = new JComboBox();
		comboBoxPorte.setBounds(286, 155, 59, 22);
		comboBoxPorte.setModel(new DefaultComboBoxModel(new String[] {"P", "M", "G"}));
		contentPane.add(comboBoxPorte);
		centralizarComponente();

		JButton btnNewButton = new JButton("Verificar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf =  (String) comboBoxCpf.getSelectedItem();
				String cod = (String) comboBoxCod.getSelectedItem();
				AnimalDAO adao2 = new AnimalDAO();
				Animal a = adao2.verificaAnimal(cpf, cod);
				boolean achou = false;
				int i;
				for (i = 0; i < adao.getLista().size(); i++) {
					if(adao.getLista().get(i).getCPF_Cli().equals(cpf) && adao.getLista().get(i).getCodigo().equals(cod)) {
						achou = true;
						break;
					}
				}

				if(achou) {
					tfNome.setText(adao.getLista().get(i).getNome());
					tfRaca.setText(adao.getLista().get(i).getRaca());
					tfDataNas.setText(adao.getLista().get(i).getData_nas());
					tfEspecie.setText(adao.getLista().get(i).getEspecie());
					comboBoxPorte.setSelectedItem(adao.getLista().get(i).getPorte());

				}else {
					tfNome.setText("");
					tfRaca.setText("");
					tfDataNas.setText("");
					tfEspecie.setText("");
					JOptionPane.showMessageDialog(null, "Combina��o de CPF e c�digo n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton.setBounds(273, 61, 89, 23);
		contentPane.add(btnNewButton);

		JLabel lblNovoNome = new JLabel("Novo nome:");
		lblNovoNome.setForeground(Color.WHITE);
		lblNovoNome.setBounds(20, 124, 89, 30);
		contentPane.add(lblNovoNome);

		JLabel lblNovaRaa = new JLabel("Nova ra\u00E7a:");
		lblNovaRaa.setForeground(Color.WHITE);
		lblNovaRaa.setBounds(20, 154, 101, 24);
		contentPane.add(lblNovaRaa);

		JLabel lblNovaEspcie = new JLabel("Nova esp\u00E9cie:");
		lblNovaEspcie.setForeground(Color.WHITE);
		lblNovaEspcie.setBounds(198, 127, 101, 24);
		contentPane.add(lblNovaEspcie);

		JLabel lblNovoPorte = new JLabel("Novo porte:");
		lblNovoPorte.setForeground(Color.WHITE);
		lblNovoPorte.setBounds(198, 154, 101, 24);
		contentPane.add(lblNovoPorte);

		JLabel lblNovaData = new JLabel("Nova data");
		lblNovaData.setForeground(Color.WHITE);
		lblNovaData.setBounds(20, 214, 101, 24);
		contentPane.add(lblNovaData);

		JLabel lblDeNascimento = new JLabel("de nascimento:");
		lblDeNascimento.setForeground(Color.WHITE);
		lblDeNascimento.setBounds(20, 226, 101, 24);
		contentPane.add(lblDeNascimento);

		JButton btnNewButton_1 = new JButton("Alterar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if( tfNome.getText().isEmpty() || tfRaca.getText().isEmpty()|| tfDataNas.getText().isEmpty() || tfEspecie.getText().isEmpty()
						|| comboBoxCpf.getItemCount() == 0 ||  comboBoxCod.getItemCount() == 0  ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf = (String) comboBoxCpf.getSelectedItem();
					String codigo  = (String) comboBoxCod.getSelectedItem();
					String nome = tfNome.getText();
					String raca = tfRaca.getText();
					String DN = tfDataNas.getText();
					String esp = tfEspecie.getText();
					String porte = (String) comboBoxPorte.getSelectedItem();

					Animal a = new Animal(cpf, codigo, nome, raca, DN, esp, porte);
					int alterar = adao.alterar(a);
					if(alterar > 0) {
						JOptionPane.showMessageDialog(null, "Alterado com sucesso!", "Altera��o realizada", JOptionPane.NO_OPTION);
						tfNome.setText("");
						tfRaca.setText("");
						tfDataNas.setText("");
						tfEspecie.setText("");
					}else {
						JOptionPane.showMessageDialog(null, "Houve algum erro na altera��o", "Erro ao tentar alterar", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		btnNewButton_1.setBounds(256, 215, 89, 23);
		contentPane.add(btnNewButton_1);

		tfNome = new JTextField();
		tfNome.setBounds(96, 129, 86, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);

		tfRaca = new JTextField();
		tfRaca.setColumns(10);
		tfRaca.setBounds(96, 156, 86, 20);
		contentPane.add(tfRaca);

		tfEspecie = new JTextField();
		tfEspecie.setColumns(10);
		tfEspecie.setBounds(276, 129, 86, 20);
		contentPane.add(tfEspecie);

		tfDataNas = new JTextField();
		tfDataNas.setColumns(10);
		tfDataNas.setBounds(96, 216, 86, 20);
		contentPane.add(tfDataNas);


	}

}
