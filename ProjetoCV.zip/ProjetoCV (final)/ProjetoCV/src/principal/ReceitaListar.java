package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.ReceitaDAO;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReceitaListar extends JFrame {

	private JPanel contentPane;
	private JTable table;
	ReceitaDAO rdao = new ReceitaDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceitaListar frame = new ReceitaListar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public ReceitaListar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ReceitaListar.class.getResource("/img/listar.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 626, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(rdao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					model.addRow(new Object[] {"", "", "", "", "", ""});
				}else {
					
					for(int i = 0; i<rdao.getLista().size(); i++) {
						model.addRow(new Object[] {rdao.getLista().get(i).getCodigo_R(), rdao.getLista().get(i).getMedicamento(), rdao.getLista().get(i).getDose_diaria(), rdao.getLista().get(i).getTempo_tratamento(),
								rdao.getLista().get(i).getCPF_Veterinario(), rdao.getLista().get(i).getCPF_Cliente(), rdao.getLista().get(i).getCodigo_de_um_animal(), rdao.getLista().get(i).getData_hora()});
					}
				}
			}
		});
		btnNewButton.setBounds(10, 22, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(512, 22, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 56, 591, 200);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d.Receita", "Medicamento", "Dose di\u00E1ria", "Tempo tratamento", "CPF V.", "CPF C.", "C\u00F3d. Animal", "Data e hora"
			}
		));
		
		centralizarComponente();
	}
}
