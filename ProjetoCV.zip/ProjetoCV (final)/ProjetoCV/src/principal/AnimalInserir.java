package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Animal;
import bean.Cliente;
import dao.AnimalDAO;
import dao.ClienteDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class AnimalInserir extends JFrame {

	private JPanel contentPane;
	ClienteDAO cdao = new ClienteDAO();
	AnimalDAO adao = new AnimalDAO();
	private JTextField tfCod;
	private JTextField tfNome;
	private JTextField tfRaca;
	private JTextField tfDataNas;
	private JTextField tfEspecie;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimalInserir frame = new AnimalInserir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public AnimalInserir() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AnimalInserir.class.getResource("/img/adicao (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CPF do cliente:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(20, 55, 102, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBoxCPF = new JComboBox();
		comboBoxCPF.setBounds(114, 51, 91, 22);
		contentPane.add(comboBoxCPF);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo:");
		lblCdigo.setForeground(Color.WHITE);
		lblCdigo.setBounds(20, 88, 102, 14);
		contentPane.add(lblCdigo);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setBounds(20, 113, 102, 14);
		contentPane.add(lblNome);
		
		JLabel lblRaa = new JLabel("Ra\u00E7a:");
		lblRaa.setForeground(Color.WHITE);
		lblRaa.setBounds(20, 144, 102, 14);
		contentPane.add(lblRaa);
		
		tfCod = new JTextField();
		tfCod.setBounds(114, 80, 86, 20);
		contentPane.add(tfCod);
		tfCod.setColumns(10);
		
		JLabel lblDataDe = new JLabel("Data de");
		lblDataDe.setForeground(Color.WHITE);
		lblDataDe.setBounds(20, 169, 102, 14);
		contentPane.add(lblDataDe);
		
		JLabel lblEspcie = new JLabel("Esp\u00E9cie:");
		lblEspcie.setForeground(Color.WHITE);
		lblEspcie.setBounds(20, 203, 102, 14);
		contentPane.add(lblEspcie);
		
		JLabel lblPorte = new JLabel("Porte:");
		lblPorte.setForeground(Color.WHITE);
		lblPorte.setBounds(20, 228, 102, 14);
		contentPane.add(lblPorte);
		
		JLabel lblNascimento = new JLabel("Nascimento:");
		lblNascimento.setForeground(Color.WHITE);
		lblNascimento.setBounds(20, 181, 102, 14);
		contentPane.add(lblNascimento);
		
		tfNome = new JTextField();
		tfNome.setColumns(10);
		tfNome.setBounds(114, 110, 86, 20);
		contentPane.add(tfNome);
		
		tfRaca = new JTextField();
		tfRaca.setColumns(10);
		tfRaca.setBounds(114, 141, 86, 20);
		contentPane.add(tfRaca);
		
		tfDataNas = new JTextField();
		tfDataNas.setColumns(10);
		tfDataNas.setBounds(114, 169, 86, 20);
		contentPane.add(tfDataNas);
		
		tfEspecie = new JTextField();
		tfEspecie.setColumns(10);
		tfEspecie.setBounds(114, 200, 86, 20);
		contentPane.add(tfEspecie);
		
		JLabel lblInseroAnimal = new JLabel("Inser\u00E7\u00E3o - Animal");
		lblInseroAnimal.setForeground(Color.WHITE);
		lblInseroAnimal.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblInseroAnimal.setBounds(147, 11, 189, 19);
		contentPane.add(lblInseroAnimal);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(132, 224, 44, 22);
		contentPane.add(comboBox);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"P", "M", "G"}));
		
		JButton btnNewButton = new JButton("Enviar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfCod.getText().isEmpty() || tfNome.getText().isEmpty() || tfRaca.getText().isEmpty()|| tfDataNas.getText().isEmpty() || tfEspecie.getText().isEmpty() || comboBoxCPF.getItemCount() == 0 ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpf = (String) comboBoxCPF.getSelectedItem();
				String codigo = tfCod.getText();
				String nome = tfNome.getText();
				String raca = tfRaca.getText();
				String DN = tfDataNas.getText();
				String esp = tfEspecie.getText();
				String porte = (String) comboBox.getSelectedItem();
				
				Animal a = new Animal(cpf, codigo, nome, raca, DN, esp, porte);
				Animal a2 = adao.verificaAnimal(cpf, codigo);
				boolean v = a.verificaData(DN);
					if(v == false) {
						JOptionPane.showMessageDialog(null, "Digite a data na seguinte formata��o: aaaa-MM-dd", "Data inv�lida", JOptionPane.ERROR_MESSAGE, null);
					}
					else {
						if(a2 != null) {
							JOptionPane.showMessageDialog(null, "J� existe um Animal cadastrado esse CPF e c�digo", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
						}else {
							adao.inserir(a);
							JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
						}
						
						tfCod.setText("");
						tfNome.setText("");
						tfRaca.setText("");
						tfDataNas.setText("");
						tfEspecie.setText("");
						}
				}
			}
		
		});
		btnNewButton.setBounds(230, 51, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(AnimalInserir.class.getResource("/img/cat (1).png")));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(247, 132, 161, 129);
		contentPane.add(lblNewLabel_1);
		
		
		
	ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCPF.addItem(linha.get(j));
		
		}
		centralizarComponente();
	}
}
