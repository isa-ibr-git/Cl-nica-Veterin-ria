package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Tel_vet;
import dao.Tel_vetDAO;
import dao.VeterinarioDAO;

import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelVet extends JFrame {

	private JPanel contentPane;
	private JTextField tfTel;
	private JTable table;
	AbstractButton jTblFindOF;
	VeterinarioDAO vdao = new VeterinarioDAO();
	Tel_vetDAO tvdao = new Tel_vetDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelVet frame = new TelVet();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	
	 
	 
	public TelVet() {
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelVet.class.getResource("/img/tel (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CPF Veterin\u00E1rio:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 46, 97, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setForeground(Color.WHITE);
		lblTelefone.setBounds(10, 71, 97, 14);
		contentPane.add(lblTelefone);
		
		JComboBox comboBoxCpf = new JComboBox();
		comboBoxCpf.setBounds(99, 42, 103, 22);
		VeterinarioDAO vdao = new VeterinarioDAO();
		ArrayList <String > linha = new ArrayList<>();
	
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpf.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpf);
		
		tfTel = new JTextField();
		tfTel.setBounds(98, 68, 86, 20);
		contentPane.add(tfTel);
		tfTel.setColumns(10);
		
		JComboBox comboBoxTel = new JComboBox();
		comboBoxTel.setBounds(321, 67, 103, 22);
		ArrayList <String > linha3 = new ArrayList<>();
		for(int k=0; k < tvdao.getLista().size(); k++) {
			linha3.add(tvdao.getLista().get(k).getTelefone_vet());
		}
		
		for(int l=0; l < linha3.size(); l++) {
			
		comboBoxTel.addItem(linha3.get(l));
		
		}
		
		contentPane.add(comboBoxTel);
		


		
		JButton btnNewButton = new JButton("Inserir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCpf.getItemCount() == 0 || comboBoxTel.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					}else {
					if(tfTel.getText().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					}else {
					String cpf = (String) comboBoxCpf.getSelectedItem();
					String tel = tfTel.getText();
					Tel_vet tv = new Tel_vet(cpf, tel);
					Tel_vet tv2 = tvdao.verificaTel_vet(cpf, tel);
					if(tv2 != null) {
						JOptionPane.showMessageDialog(null, "J� existe um telefone de veterin�rio cadastrado esse CPF e esse n�mero", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
					}else {
						tvdao.inserir(tv);
						JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
						comboBoxTel.addItem(tv.getTelefone_vet());
					
						
					}
					
					tfTel.setText("");
					
					
					}
				}
				
			}
		});
		btnNewButton.setBounds(10, 93, 174, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblInserir = new JLabel("Inserir Telefone");
		lblInserir.setForeground(Color.WHITE);
		lblInserir.setBounds(66, 11, 97, 14);
		contentPane.add(lblInserir);
		
		JLabel lblRemoverTelefone = new JLabel("Remover Telefone");
		lblRemoverTelefone.setForeground(Color.WHITE);
		lblRemoverTelefone.setBounds(282, 11, 114, 14);
		contentPane.add(lblRemoverTelefone);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setForeground(Color.WHITE);
		lblCpf.setBounds(258, 46, 97, 14);
		contentPane.add(lblCpf);
		
		JLabel lblTelefone_1 = new JLabel("Telefone:");
		lblTelefone_1.setForeground(Color.WHITE);
		lblTelefone_1.setBounds(258, 71, 97, 14);
		contentPane.add(lblTelefone_1);
		
		JComboBox comboBoxCpf2 = new JComboBox();
		comboBoxCpf2.setBounds(321, 42, 103, 22);
		VeterinarioDAO vdao2 = new VeterinarioDAO();
		ArrayList <String > linha2 = new ArrayList<>();
	
		for(int i=0; i < vdao2.getLista().size(); i++) {
			linha2.add(vdao2.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha2.size(); j++) {
			
		comboBoxCpf2.addItem(linha2.get(j));
		
		}
		contentPane.add(comboBoxCpf2);
		
		
		JButton btnNewButton_1 = new JButton("Remover");
		btnNewButton_1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				boolean achou = false;
				boolean achou2 = false;
				int i;
				int j;
				int k = 1;
				if(comboBoxCpf2.getItemCount() == 0 || comboBoxTel.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf = (String) comboBoxCpf2.getSelectedItem();
					String tel = (String) comboBoxTel.getSelectedItem();
					for(i = 0; i < vdao.getLista().size(); i++) {
						if(vdao.getLista().get(i).getCPF_Func().equals(cpf)) {
							achou = true;
							break;
						}
					}
					
					for(j = 0; j < tvdao.getLista().size(); j++) {
						if(tvdao.getLista().get(j).getTelefone_vet().equals(tel)) {
							achou2 = true;
							break;
						}
					}
					
					
					
					Tel_vet tv = new Tel_vet(vdao.getLista().get(i).getCPF_Func(), tvdao.getLista().get(j).getTelefone_vet());
					int removeu = tvdao.remover(tv);
					if(removeu > 0) {
						JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
						comboBoxTel.removeItem(tel);
	
						
					        
					       
						
				
						
						
					}else {
						JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
						}
				
				}
				
			}
		});
		btnNewButton_1.setBounds(258, 93, 166, 23);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(64, 166, 311, 85);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Veterin\u00E1rio", "Telefone"
			}
		));
		
		JLabel lblNewLabel_1 = new JLabel("Bem vindo(a) ao gerenciamento de Cl\u00EDnica Veterin\u00E1ria!");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Bookshelf Symbol 7", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(10, 127, 414, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_3 = new JButton("Atualizar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				
				if(model.getRowCount() == 0) {
					model.addRow(new Object[] {"", ""});
				}
				 if (model.getRowCount() > 0){
			            for (int i=0;i<=model.getRowCount();i++){
			                model.removeRow(0);
			            }   
			            for(int i = 0; i<tvdao.getLista().size(); i++) {
							model.addRow(new Object[] {tvdao.getLista().get(i).getCPF_Veterinario(), tvdao.getLista().get(i).getTelefone_vet()});
						}
			        }
				 
				 

			    }
			
		});
		btnNewButton_3.setBounds(145, 140, 152, 23);
		contentPane.add(btnNewButton_3);
	
		
		
		centralizarComponente();
	}
}
