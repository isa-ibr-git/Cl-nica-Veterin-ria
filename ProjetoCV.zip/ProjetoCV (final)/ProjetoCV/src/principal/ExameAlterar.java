package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Animal;
import bean.ConsultaRegistra;
import bean.Exame;
import dao.AnimalDAO;
import dao.ConsultaRegistraDAO;
import dao.ExameDAO;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExameAlterar extends JFrame {

	private JPanel contentPane;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();
	ExameDAO exdao = new ExameDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExameAlterar frame = new ExameAlterar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public ExameAlterar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ExameAlterar.class.getResource("/img/lapis (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		JLabel lblCdigoExame = new JLabel("C\u00F3digo Exame:");
		lblCdigoExame.setForeground(Color.WHITE);
		lblCdigoExame.setBounds(10, 53, 81, 14);
		contentPane.add(lblCdigoExame);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setBounds(10, 78, 81, 14);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(10, 106, 81, 14);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setBounds(10, 134, 81, 14);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setBounds(10, 159, 81, 14);
		contentPane.add(lblDataEHora);
		
		JComboBox comboBoxEx = new JComboBox();
		comboBoxEx.setBounds(101, 49, 100, 22);
		int y;
		boolean achou9 = true;
		 DefaultComboBoxModel model9 = (DefaultComboBoxModel) comboBoxEx.getModel();
		 
		 for(y = 0; y < exdao.getLista().size(); y++) {
			 String palavra = exdao.getLista().get(y).getCodigo_exame().toLowerCase();
				int a = model9.getIndexOf(palavra);
				if(a != -1) {
					achou9 = false;
		
		}else {
			
			comboBoxEx.addItem(exdao.getLista().get(y).getCodigo_exame().toLowerCase());
			contentPane.add(comboBoxEx);
		}
		 }
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(101, 74, 100, 22);
		DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCpfVet.getModel();
		boolean achou3 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model.getIndexOf(crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase()) != -1) {
				achou3 = false;
			
			}else {
				comboBoxCpfVet.addItem(crdao.getLista().get(i).getCPF_Veterinairo());
				comboBoxCpfVet.setVisible(true);
			}
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(101, 102, 100, 22);
		DefaultComboBoxModel model2 = (DefaultComboBoxModel) comboBoxCpfCli.getModel();
		boolean achou4 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model2.getIndexOf(crdao.getLista().get(i).getCPF_Cliente().toLowerCase()) != -1) {
				achou4 = false;
			
			}else {
				comboBoxCpfCli.addItem(crdao.getLista().get(i).getCPF_Cliente());
			}
		}
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(101, 130, 100, 22);
		boolean achou = true;
		DefaultComboBoxModel model5 = (DefaultComboBoxModel) comboBoxCodA.getModel();
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model5.getIndexOf(crdao.getLista().get(i).getCodigo_animal().toLowerCase()) != -1) {
				achou = false;
			
			}else {
				comboBoxCodA.addItem(crdao.getLista().get(i).getCodigo_animal());
			}
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(101, 155, 100, 22);
		ArrayList <String> linha4 = new ArrayList();
		
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0; j<linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
		
		contentPane.add(comboBoxDH);
		
		JButton btnNewButton = new JButton("Verificar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxEx.getItemCount() == 0 || comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String ex =  (String) comboBoxEx.getSelectedItem();
				String cpfVet =  (String) comboBoxCpfVet.getSelectedItem();
				String cpfCli =  (String) comboBoxCpfCli.getSelectedItem();
				String codA =  (String) comboBoxCodA.getSelectedItem();
				String dh=  (String) comboBoxDH.getSelectedItem();
				
				Exame ex2 = exdao.verificaEx(ex, cpfVet, cpfCli, codA, dh);
				if(ex2 != null) {
					JOptionPane.showMessageDialog(null, "Combina��o de dados encontrada! Pode alterar", "Erro de combina��o de dados", JOptionPane.NO_OPTION);
					
				}else {
					
					JOptionPane.showMessageDialog(null, "Combina��o de dados n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
				}
			}
			}
		
		});
		btnNewButton.setBounds(86, 200, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblVerifiqueSeOs = new JLabel("Verifique se os dados existem");
		lblVerifiqueSeOs.setForeground(Color.WHITE);
		lblVerifiqueSeOs.setBounds(20, 24, 199, 14);
		contentPane.add(lblVerifiqueSeOs);
		
		JLabel lblNovosDados = new JLabel("Novos dados");
		lblNovosDados.setForeground(Color.WHITE);
		lblNovosDados.setBounds(325, 24, 81, 14);
		contentPane.add(lblNovosDados);
		
		JLabel lblCdigoExame_1 = new JLabel("C\u00F3digo Exame:");
		lblCdigoExame_1.setForeground(Color.WHITE);
		lblCdigoExame_1.setBounds(233, 53, 81, 14);
		contentPane.add(lblCdigoExame_1);
		
		JLabel lblCpfVeterinrio_1 = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio_1.setForeground(Color.WHITE);
		lblCpfVeterinrio_1.setBounds(233, 78, 81, 14);
		contentPane.add(lblCpfVeterinrio_1);
		
		JLabel lblCpfCliente_1 = new JLabel("CPF Cliente:");
		lblCpfCliente_1.setForeground(Color.WHITE);
		lblCpfCliente_1.setBounds(233, 106, 81, 14);
		contentPane.add(lblCpfCliente_1);
		
		JLabel lblCdigoAnimal_1 = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal_1.setForeground(Color.WHITE);
		lblCdigoAnimal_1.setBounds(233, 134, 114, 14);
		contentPane.add(lblCdigoAnimal_1);
		
		JLabel lblDataEHora_1 = new JLabel("Data e hora:");
		lblDataEHora_1.setForeground(Color.WHITE);
		lblDataEHora_1.setBounds(233, 159, 81, 14);
		contentPane.add(lblDataEHora_1);
		
		JComboBox comboBoxEx_1 = new JComboBox();
		comboBoxEx_1.setBounds(325, 49, 100, 22);
		
		;
		boolean achou10 = true;
		int z;
	
		 DefaultComboBoxModel model10 = (DefaultComboBoxModel) comboBoxEx_1.getModel();
		 
		 for(z = 0; z < exdao.getLista().size(); z++) {
			 String palavra = exdao.getLista().get(z).getCodigo_exame().toLowerCase();
				int a = model10.getIndexOf(palavra);
				if(a != -1) {
					achou10 = false;
		
		}else {
			
			comboBoxEx_1.addItem(exdao.getLista().get(z).getCodigo_exame().toLowerCase());
			contentPane.add(comboBoxEx);
		}
		 }
		contentPane.add(comboBoxEx_1);
		
		JComboBox comboBoxCpfVet_1 = new JComboBox();
		comboBoxCpfVet_1.setBounds(325, 74, 100, 22);
		DefaultComboBoxModel model4 = (DefaultComboBoxModel) comboBoxCpfVet_1.getModel();
		boolean achou6 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model4.getIndexOf(crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase()) != -1) {
				achou6 = false;
			
			}else {
				comboBoxCpfVet_1.addItem(crdao.getLista().get(i).getCPF_Veterinairo());
			}
		}
		contentPane.add(comboBoxCpfVet_1);
		
		JComboBox comboBoxCpfCli_1 = new JComboBox();
		comboBoxCpfCli_1.setBounds(325, 102, 100, 22);
		DefaultComboBoxModel model3 = (DefaultComboBoxModel) comboBoxCpfCli_1.getModel();
		boolean achou5 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model3.getIndexOf(crdao.getLista().get(i).getCPF_Cliente().toLowerCase()) != -1) {
				achou5 = false;
			
			}else {
				comboBoxCpfCli_1.addItem(crdao.getLista().get(i).getCPF_Cliente());
			}
		}
		contentPane.add(comboBoxCpfCli_1);
		
		JComboBox comboBoxCodA_1 = new JComboBox();
		comboBoxCodA_1.setBounds(325, 130, 100, 22);
		boolean achou12 = true;
		DefaultComboBoxModel model51 = (DefaultComboBoxModel) comboBoxCodA_1.getModel();
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model51.getIndexOf(crdao.getLista().get(i).getCodigo_animal().toLowerCase()) != -1) {
				achou12= false;
			
			}else {
				comboBoxCodA_1.addItem(crdao.getLista().get(i).getCodigo_animal());
			}
		}
		contentPane.add(comboBoxCodA_1);
		
		JComboBox comboBoxDH_1 = new JComboBox();
		comboBoxDH_1.setBounds(325, 155, 100, 22);
		for(int j = 0; j<linha4.size(); j++) {
			comboBoxDH_1.addItem(linha4.get(j));
		}
		contentPane.add(comboBoxDH_1);
		
		JButton btnNewButton_1 = new JButton("Alterar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxEx_1.getItemCount() == 0 || comboBoxCpfVet_1.getItemCount() == 0 || comboBoxCpfCli_1.getItemCount() == 0 || comboBoxCodA_1.getItemCount() == 0 || comboBoxDH_1.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String ex =  (String) comboBoxEx.getSelectedItem();
				String cpfVet =  (String) comboBoxCpfVet.getSelectedItem();
				String cpfCli =  (String) comboBoxCpfCli.getSelectedItem();
				String codA =  (String) comboBoxCodA.getSelectedItem();
				String dh=  (String) comboBoxDH.getSelectedItem();
				
				String codex2 =  (String) comboBoxEx_1.getSelectedItem();
				String cpfVet2 =  (String) comboBoxCpfVet_1.getSelectedItem();
				String cpfCli2 =  (String) comboBoxCpfCli_1.getSelectedItem();
				String codA2 =  (String) comboBoxCodA_1.getSelectedItem();
				String dh2=  (String) comboBoxDH_1.getSelectedItem();
				
				Exame ex2 = exdao.verificaEx(ex, cpfVet, cpfCli, codA, dh);
				ConsultaRegistra cr = crdao.verificaCR(cpfVet2, cpfCli2, codA2, dh2);
				
				if(cr == null) {
					JOptionPane.showMessageDialog(null, "Existem tabelas referenciadas, � necess�rio alter�-las primeiro", "Erro de refer�ncia", JOptionPane.WARNING_MESSAGE);
				}else {
					if(ex2 != null) {
						Exame exame = new Exame(ex, cpfVet, cpfCli, codA, dh);
						Exame exame2 = new Exame(codex2, cpfVet2, cpfCli2, codA2, dh2);
						int alterar = exdao.alterar(exame, exame2);
						if(alterar > 0) {
							JOptionPane.showMessageDialog(null, "Alterado com sucesso!", "Altera��o realizada", JOptionPane.NO_OPTION);
						}else {
							JOptionPane.showMessageDialog(null, "Houve algum erro na altera��o", "Erro ao tentar alterar", JOptionPane.ERROR_MESSAGE);
						}
							
					
						
					}else {
						
						JOptionPane.showMessageDialog(null, "Combina��o de dados n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
					}
				}
			
			}
			}
		});
		btnNewButton_1.setBounds(317, 200, 89, 23);
		contentPane.add(btnNewButton_1);
		centralizarComponente();
		
		
		
	}

}
