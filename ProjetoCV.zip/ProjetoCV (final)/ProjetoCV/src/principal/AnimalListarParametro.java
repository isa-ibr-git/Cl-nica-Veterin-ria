package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import bean.Animal;
import dao.AnimalDAO;
import dao.ClienteDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AnimalListarParametro extends JFrame {

	private JPanel contentPane;
	private JTable table;
	AnimalDAO adao = new AnimalDAO();
	ClienteDAO cdao = new ClienteDAO();
	private JLabel lblIndiqueOCpf;
	private JLabel lblCpf;
	private JLabel lblCdigo;
	private JComboBox comboBoxCpf;
	private JButton btnNewButton;
	private JTextField textField;
	private JComboBox comboBoxCod;
	private JComboBox comboBoxCod2;
	private JButton btnNewButton_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimalListarParametro frame = new AnimalListarParametro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public AnimalListarParametro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AnimalListarParametro.class.getResource("/img/checklist_106575 (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 625, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		centralizarComponente();
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 99, 577, 151);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Cliente", "C\u00F3digo", "Nome", "Ra\u00E7a", "Data de N", "Esp\u00E9cie", "Porte"
			}
		));
		
		lblIndiqueOCpf = new JLabel("Indique o CPF do cliente e o c\u00F3digo do animal para a listagem por par\u00E2metro:\r\n");
		lblIndiqueOCpf.setForeground(Color.WHITE);
		lblIndiqueOCpf.setBounds(68, 11, 428, 24);
		contentPane.add(lblIndiqueOCpf);
		
		lblCpf = new JLabel("CPF:");
		lblCpf.setForeground(Color.WHITE);
		lblCpf.setBounds(10, 46, 42, 24);
		contentPane.add(lblCpf);
		
		lblCdigo = new JLabel("C\u00F3digo:\r\n");
		lblCdigo.setForeground(Color.WHITE);
		lblCdigo.setBounds(10, 75, 42, 24);
		contentPane.add(lblCdigo);
		
		comboBoxCpf = new JComboBox();
		comboBoxCpf.setBounds(62, 47, 110, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpf.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpf);
		
		btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCpf.getItemCount() == 0 ||  comboBoxCod2.getItemCount() == 0 ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf =  (String) comboBoxCpf.getSelectedItem();
					String cod = (String) comboBoxCod2.getSelectedItem();
					AnimalDAO adao2 = new AnimalDAO();
					Animal a = adao2.verificaAnimal(cpf, cod);
					boolean achou = false;
					int i;
					DefaultTableModel model = (DefaultTableModel) table.getModel();
				
					if(adao.getLista().isEmpty()) {
						JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
						model.addRow(new Object[] {"", "", "", "", "", "",""});
					}else {
						for (i = 0; i < adao.getLista().size(); i++) {
							if(adao.getLista().get(i).getCPF_Cli().equals(cpf) && adao.getLista().get(i).getCodigo().equals(cod)) {
								achou = true;
								break;
							}
						}
						
						if(achou) {
							
								model.addRow(new Object[] {adao.getLista().get(i).getCPF_Cli(), adao.getLista().get(i).getCodigo(), adao.getLista().get(i).getNome()
										, adao.getLista().get(i).getRaca(), adao.getLista().get(i).getData_nas(), adao.getLista().get(i).getEspecie(), adao.getLista().get(i).getPorte()});
				
						}else {
							JOptionPane.showMessageDialog(null, "Combina��o de CPF e c�digo n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
						
					}
					}
				}
			}
		});
		btnNewButton.setBounds(214, 65, 89, 23);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(72, 77, -206, 272);
		contentPane.add(textField);
		textField.setColumns(10);
		
		comboBoxCod2 = new JComboBox();
		comboBoxCod2.setBounds(62, 76, 110, 22);
		ArrayList <String > linhaC = new ArrayList<>();
		for(int k = 0; k < adao.getLista().size(); k++) {
			linhaC.add(adao.getLista().get(k).getCodigo());
			
		}
		for(int l = 0; l < linhaC.size(); l++ ) {
			comboBoxCod2.addItem(linhaC.get(l));
		}
		contentPane.add(comboBoxCod2);
		
		btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(337, 65, 89, 23);
		contentPane.add(btnNewButton_1);
		

		
		
	}

}
