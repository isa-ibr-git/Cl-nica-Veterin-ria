package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Dependente;
import bean.Veterinario;
import dao.ConsultasDAO;
import dao.DependenteDAO;
import dao.VeterinarioDAO;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class DepConsulta3 extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DepConsulta3 frame = new DepConsulta3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}


	/**
	 * Create the frame.
	 */
	public DepConsulta3() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(DepConsulta3.class.getResource("/img/87-872219_lupa-icon (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Listar dependentes, do mais novo para o mais velho");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(60, 32, 318, 14);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VeterinarioDAO vdao = new VeterinarioDAO();
				DependenteDAO ddao = new DependenteDAO();
				ConsultasDAO condao = new ConsultasDAO();
				ArrayList<Dependente> consulta3 = condao.consulta3();
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(ddao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					
				}else {
				
					for(int i = 0; i < consulta3.size(); i++) {
						model.addRow(new Object[] {condao.consulta3().get(i).getCpf_func(), condao.consulta3().get(i).getNome(), condao.consulta3().get(i).getData_nas()});
					}
				}
			}
			
		});
		btnNewButton.setBounds(45, 76, 89, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(45, 109, 343, 144);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF Funcion\u00E1rio", "Nome", "Data de N."
			}
		));
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(299, 76, 89, 23);
		contentPane.add(btnNewButton_1);
		centralizarComponente();
	}

}
