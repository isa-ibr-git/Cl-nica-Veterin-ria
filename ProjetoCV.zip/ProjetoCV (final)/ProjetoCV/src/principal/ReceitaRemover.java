package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Receita;
import dao.ConsultaRegistraDAO;
import dao.ReceitaDAO;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReceitaRemover extends JFrame {

	private JPanel contentPane;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();
	ReceitaDAO rdao = new ReceitaDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceitaRemover frame = new ReceitaRemover();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
	}
	/**
	 * Create the frame.
	 */
	public ReceitaRemover() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ReceitaRemover.class.getResource("/img/rmv (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Indique o c\u00F3digo da receita para remo\u00E7\u00E3o:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 11, 251, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBoxCodR = new JComboBox();
		comboBoxCodR.setBounds(300, 7, 96, 22);
		ArrayList <String> linha = new ArrayList<>();
		for(int i = 0; i < rdao.getLista().size(); i++) {
			linha.add(rdao.getLista().get(i).getCodigo_R());
		}
		
		for(int j = 0; j < linha.size(); j++) {
			comboBoxCodR.addItem(linha.get(j));
		}
		contentPane.add(comboBoxCodR);
		
		JButton btnNewButton = new JButton("Remover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String codR = (String) comboBoxCodR.getSelectedItem();
				boolean achou = false;
				int i;
				if(comboBoxCodR.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
			}else {
				for(i = 0; i < rdao.getLista().size(); i++) {
					if(rdao.getLista().get(i).getCodigo_R().equals(codR)) {
						achou = true;
						break;
					}
				}
				
				if(achou) {
					Receita r = new Receita (rdao.getLista().get(i).getCodigo_R(), rdao.getLista().get(i).getMedicamento(), rdao.getLista().get(i).getDose_diaria(), rdao.getLista().get(i).getTempo_tratamento(),rdao.getLista().get(i).getCPF_Veterinario(), 
							rdao.getLista().get(i).getCPF_Cliente(), rdao.getLista().get(i).getCodigo_de_um_animal(), rdao.getLista().get(i).getData_hora());			 
		
						
						int removeu = rdao.remover(r);
						if(removeu > 0) {
							JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
							comboBoxCodR.removeItem(codR);
						}else {
							JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
						}
				
				}
			}
			}
		});
		btnNewButton.setBounds(172, 92, 89, 23);
		contentPane.add(btnNewButton);
		centralizarComponente();
	}

}
