package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.ConsultaRegistraDAO;
import dao.ReceitaDAO;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReceitaListarParametro extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	ReceitaDAO rdao = new ReceitaDAO();
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceitaListarParametro frame = new ReceitaListarParametro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public ReceitaListarParametro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ReceitaListarParametro.class.getResource("/img/checklist_106575 (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 622, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		centralizarComponente();
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 96, 596, 154);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d.Receita", "Medicamento", "Dose di\u00E1ria", "Tempo tratamento", "CPF V.", "CPF C.", "C\u00F3d. Animal", "Data e hora"
			}
		));
		
		JComboBox comboBoxCodR = new JComboBox();
		comboBoxCodR.setBounds(385, 29, 116, 22);
		ArrayList <String> linha = new ArrayList<>();
		for(int i = 0; i < rdao.getLista().size(); i++) {
			linha.add(rdao.getLista().get(i).getCodigo_R());
		}
		
		for(int j = 0; j < linha.size(); j++) {
			comboBoxCodR.addItem(linha.get(j));
		}
		contentPane.add(comboBoxCodR);
	
		
		btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCodR.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String codR = (String) comboBoxCodR.getSelectedItem();
					int i;
					for(i=0; i<rdao.getLista().size(); i++) {
						if(codR.equals(rdao.getLista().get(i).getCodigo_R())) {
							break;
						}
					}
					
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.addRow(new Object[] {codR, rdao.getLista().get(i).getMedicamento(), rdao.getLista().get(i).getDose_diaria(), rdao.getLista().get(i).getTempo_tratamento(), rdao.getLista().get(i).getCPF_Veterinario(),
							rdao.getLista().get(i).getCPF_Cliente(), rdao.getLista().get(i).getCodigo_de_um_animal(), rdao.getLista().get(i).getData_hora()});
				}
			}
		});
		btnNewButton.setBounds(5, 62, 89, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
			
		});
		btnNewButton_1.setBounds(512, 62, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Indique o c\u00F3digo da receita para a listagem por par\u00E2metro:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(5, 28, 350, 23);
		contentPane.add(lblNewLabel);
	}
		
}
