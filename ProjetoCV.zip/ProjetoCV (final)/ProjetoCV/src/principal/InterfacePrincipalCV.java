package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Font;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.TextField;
import javax.swing.JLabel;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLayeredPane;
import java.awt.CardLayout;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;

import java.awt.SystemColor;

public class InterfacePrincipalCV extends JFrame {

	private JPanel contentPane;
	private VetInserir veti;

	/**
	 * Launch the application.
	 */



	public void centralizarComponente() {
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension dw = getSize();
		setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2);
	}

	public static void main(String[] args) {
		try {

			// setTheme(String themeName, String licenseKey, String logoString) com.jtattoo.plaf.acryl.AcrylLookAndFeel.setTheme("Green", "INSERT YOUR LICENSE KEY HERE", "my company");

			// select the Look and Feel
			UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel");

			// start the demo application
			new InterfacePrincipalCV().setVisible(true);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	} // end main

	// end class SimpleThemesDemo

	/**
	 * Create the frame.
	 */
	public InterfacePrincipalCV() {

		setTitle("Projeto Cl\u00EDnica Veterin\u00E1ria");
		setBackground(Color.BLACK);
		setForeground(Color.BLACK);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\iconclinicavet (2).png"));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 671, 461);
		centralizarComponente();

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.black);
		setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("Veterin\u00E1rio");
		mnNewMenu.setBackground(Color.BLACK);
		mnNewMenu.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\vet (1).png"));

		mnNewMenu.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		menuBar.add(mnNewMenu);


		JMenuItem mntmNewMenuItem = new JMenuItem("Adicionar");
		mntmNewMenuItem.setBackground(Color.black);
		mntmNewMenuItem.setForeground(Color.white);
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetInserir veti = new VetInserir();
				veti.setVisible(true);

			}
		});

		mntmNewMenuItem.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\adicao (1).png"));
		mntmNewMenuItem.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Remover");
		mntmNewMenuItem_1.setBackground(Color.black);
		mntmNewMenuItem_1.setForeground(Color.white);
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetRemover veta = new VetRemover();
				veta.setVisible(true);
			}
		});
		mntmNewMenuItem_1.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\rmv (1).png"));
		mntmNewMenuItem_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem_1);

		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Alterar");
		mntmNewMenuItem_2.setBackground(Color.black);
		mntmNewMenuItem_2.setForeground(Color.white);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetAlterar vetalt = new VetAlterar();
				vetalt.setVisible(true);
			}
		});
		mntmNewMenuItem_2
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\lapis (1).png"));
		mntmNewMenuItem_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem_2);

		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Listar");
		mntmNewMenuItem_3.setBackground(Color.black);
		mntmNewMenuItem_3.setForeground(Color.white);
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetListar vetlist = new VetListar();
				vetlist.setVisible(true);
			}
		});
		mntmNewMenuItem_3.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\listar.png"));
		mntmNewMenuItem_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem_3);

		JMenuItem mntmNewMenuItem_4 = new JMenuItem("Listar - Par\u00E2metro");
		mntmNewMenuItem_4.setBackground(Color.black);
		mntmNewMenuItem_4.setForeground(Color.white);
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetListarParametro vetLP = new VetListarParametro();
				vetLP.setVisible(true);
			}
		});
		mntmNewMenuItem_4.setIcon(
				new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\checklist_106575 (1).png"));
		mntmNewMenuItem_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem_4);

		JMenuItem mntmNewMenuItem_30 = new JMenuItem("Telefones");
		mntmNewMenuItem_30.setBackground(Color.black);
		mntmNewMenuItem_30.setForeground(Color.white);
		mntmNewMenuItem_30.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/tel (1).png")));
		mntmNewMenuItem_30.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_30.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelVet tv = new TelVet();
				tv.setVisible(true);
			}
		});
		mnNewMenu.add(mntmNewMenuItem_30);

		JMenuItem mntmNewMenuItem_32 = new JMenuItem("Dependentes");
		mntmNewMenuItem_32.setBackground(Color.black);
		mntmNewMenuItem_32.setForeground(Color.white);
		mntmNewMenuItem_32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dependented dep = new Dependented();
				dep.setVisible(true);
			}
		});
		mntmNewMenuItem_32.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/dep (1).png")));
		mntmNewMenuItem_32.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu.add(mntmNewMenuItem_32);

		JMenu mnNewMenu_1 = new JMenu("Cliente");
		mnNewMenu_1.setForeground(Color.BLACK);
		mnNewMenu_1.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\client-5253.png"));
		mnNewMenu_1.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		menuBar.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem_5 = new JMenuItem("Adicionar");
		mntmNewMenuItem_5.setBackground(Color.black);
		mntmNewMenuItem_5.setForeground(Color.white);
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CliInserir CI = new CliInserir();
				CI.setVisible(true);
			}
		});
		mntmNewMenuItem_5.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\adicao (1).png"));
		mntmNewMenuItem_5.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_1.add(mntmNewMenuItem_5);

		JMenuItem mntmNewMenuItem_6 = new JMenuItem("Remover");
		mntmNewMenuItem_6.setBackground(Color.black);
		mntmNewMenuItem_6.setForeground(Color.white);
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CliRemover crev = new CliRemover();
				crev.setVisible(true);
			}
		});
		mntmNewMenuItem_6.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\rmv (1).png"));
		mntmNewMenuItem_6.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_1.add(mntmNewMenuItem_6);

		JMenuItem mntmNewMenuItem_7 = new JMenuItem("Alterar");
		mntmNewMenuItem_7.setBackground(Color.black);
		mntmNewMenuItem_7.setForeground(Color.white);
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CliAlterar calt = new CliAlterar();
				calt.setVisible(true);
			}
		});
		mntmNewMenuItem_7
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\lapis (1).png"));
		mntmNewMenuItem_7.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_1.add(mntmNewMenuItem_7);

		JMenuItem mntmNewMenuItem_8 = new JMenuItem("Listar");
		mntmNewMenuItem_8.setBackground(Color.black);
		mntmNewMenuItem_8.setForeground(Color.white);
		mntmNewMenuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CliListar CL = new CliListar();
				CL.setVisible(true);
			}
		});
		mntmNewMenuItem_8.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\listar.png"));
		mntmNewMenuItem_8.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_1.add(mntmNewMenuItem_8);

		JMenuItem mntmNewMenuItem_9 = new JMenuItem("Listar - Par\u00E2metro");
		mntmNewMenuItem_9.setBackground(Color.black);
		mntmNewMenuItem_9.setForeground(Color.white);
		mntmNewMenuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CliListarParametro CLT = new CliListarParametro();
				CLT.setVisible(true);
			}
		});
		mntmNewMenuItem_9.setIcon(
				new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\checklist_106575 (1).png"));
		mntmNewMenuItem_9.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_1.add(mntmNewMenuItem_9);

		JMenuItem mntmNewMenuItem_31 = new JMenuItem("Telefones");
		mntmNewMenuItem_31.setBackground(Color.black);
		mntmNewMenuItem_31.setForeground(Color.white);
		mntmNewMenuItem_31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelCli tc = new TelCli();
				tc.setVisible(true);
			}
		});
		mntmNewMenuItem_31.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_31.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/tel (1).png")));
		mnNewMenu_1.add(mntmNewMenuItem_31);

		JMenu mnNewMenu_2 = new JMenu("Animal");
		mnNewMenu_2.setForeground(Color.BLACK);
		mnNewMenu_2.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\animal (1).png"));
		mnNewMenu_2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		menuBar.add(mnNewMenu_2);

		JMenuItem mntmNewMenuItem_10 = new JMenuItem("Adicionar");
		mntmNewMenuItem_10.setBackground(Color.black);
		mntmNewMenuItem_10.setForeground(Color.white);
		mntmNewMenuItem_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnimalInserir AI = new AnimalInserir();
				AI.setVisible(true);
			}
		});
		mntmNewMenuItem_10
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\adicao (1).png"));
		mntmNewMenuItem_10.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_2.add(mntmNewMenuItem_10);

		JMenuItem mntmNewMenuItem_11 = new JMenuItem("Remover");
		mntmNewMenuItem_11.setBackground(Color.black);
		mntmNewMenuItem_11.setForeground(Color.white);
		mntmNewMenuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnimalRemover AR = new AnimalRemover();
				AR.setVisible(true);
			}
		});
		mntmNewMenuItem_11
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\rmv (1).png"));
		mntmNewMenuItem_11.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_2.add(mntmNewMenuItem_11);

		JMenuItem mntmNewMenuItem_12 = new JMenuItem("Alterar");
		mntmNewMenuItem_12.setBackground(Color.black);
		mntmNewMenuItem_12.setForeground(Color.white);
		mntmNewMenuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnimalAlterar AA = new AnimalAlterar();
				AA.setVisible(true);
			}
		});
		mntmNewMenuItem_12
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\lapis (1).png"));
		mntmNewMenuItem_12.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_2.add(mntmNewMenuItem_12);

		JMenuItem mntmNewMenuItem_13 = new JMenuItem("Listar");
		mntmNewMenuItem_13.setBackground(Color.black);
		mntmNewMenuItem_13.setForeground(Color.white);
		mntmNewMenuItem_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnimalListar AL = new AnimalListar();
				AL.setVisible(true);
			}
		});
		mntmNewMenuItem_13.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\listar.png"));
		mntmNewMenuItem_13.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_2.add(mntmNewMenuItem_13);

		JMenuItem mntmNewMenuItem_14 = new JMenuItem("Listar - Par\u00E2metro");
		mntmNewMenuItem_14.setBackground(Color.black);
		mntmNewMenuItem_14.setForeground(Color.white);
		mntmNewMenuItem_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnimalListarParametro ALP = new AnimalListarParametro();
				ALP.setVisible(true);
			}
		});
		mntmNewMenuItem_14.setIcon(
				new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\checklist_106575 (1).png"));
		mntmNewMenuItem_14.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_2.add(mntmNewMenuItem_14);

		JMenu mnNewMenu_3 = new JMenu("Consulta");
		mnNewMenu_3.setForeground(Color.BLACK);
		mnNewMenu_3.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\Conanimal.png"));
		mnNewMenu_3.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		menuBar.add(mnNewMenu_3);

		JMenuItem mntmNewMenuItem_15 = new JMenuItem("Adicionar");
		mntmNewMenuItem_15.setBackground(Color.black);
		mntmNewMenuItem_15.setForeground(Color.white);
		mntmNewMenuItem_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrInserir CRI = new CrInserir();
				CRI.setVisible(true);
			}
		});
		mntmNewMenuItem_15
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\adicao (1).png"));
		mntmNewMenuItem_15.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_3.add(mntmNewMenuItem_15);

		JMenuItem mntmNewMenuItem_16 = new JMenuItem("Remover");
		mntmNewMenuItem_16.setBackground(Color.black);
		mntmNewMenuItem_16.setForeground(Color.white);
		mntmNewMenuItem_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrRemover CRR = new CrRemover();
				CRR.setVisible(true);
			}
		});
		mntmNewMenuItem_16
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\rmv (1).png"));
		mntmNewMenuItem_16.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_3.add(mntmNewMenuItem_16);

		JMenuItem mntmNewMenuItem_17 = new JMenuItem("Alterar");
		mntmNewMenuItem_17.setBackground(Color.black);
		mntmNewMenuItem_17.setForeground(Color.white);
		mntmNewMenuItem_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrAlterar CRA = new CrAlterar();
				CRA.setVisible(true);
			}
		});
		mntmNewMenuItem_17
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\lapis (1).png"));
		mntmNewMenuItem_17.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_3.add(mntmNewMenuItem_17);

		JMenuItem mntmNewMenuItem_18 = new JMenuItem("Listar");
		mntmNewMenuItem_18.setBackground(Color.black);
		mntmNewMenuItem_18.setForeground(Color.white);
		mntmNewMenuItem_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrListar CRL = new CrListar();
				CRL.setVisible(true);
			}
		});
		mntmNewMenuItem_18.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\listar.png"));
		mntmNewMenuItem_18.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_3.add(mntmNewMenuItem_18);

		JMenuItem mntmNewMenuItem_19 = new JMenuItem("Listar - Par\u00E2metro");
		mntmNewMenuItem_19.setBackground(Color.black);
		mntmNewMenuItem_19.setForeground(Color.white);
		mntmNewMenuItem_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrListarParametro CRLP = new CrListarParametro();
				CRLP.setVisible(true);
			}
		});
		mntmNewMenuItem_19.setIcon(
				new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\checklist_106575 (1).png"));
		mntmNewMenuItem_19.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_3.add(mntmNewMenuItem_19);

		JMenu mnNewMenu_4 = new JMenu("Exame");
		mnNewMenu_4.setForeground(Color.BLACK);
		mnNewMenu_4.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\exam (1).png"));
		mnNewMenu_4.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		menuBar.add(mnNewMenu_4);

		JMenuItem mntmNewMenuItem_20 = new JMenuItem("Adicionar");
		mntmNewMenuItem_20.setBackground(Color.black);
		mntmNewMenuItem_20.setForeground(Color.white);
		mntmNewMenuItem_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExameAdicionar eadd = new ExameAdicionar();
				eadd.setVisible(true);
			}
		});
		mntmNewMenuItem_20
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\adicao (1).png"));
		mntmNewMenuItem_20.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_4.add(mntmNewMenuItem_20);

		JMenuItem mntmNewMenuItem_21 = new JMenuItem("Remover");
		mntmNewMenuItem_21.setBackground(Color.black);
		mntmNewMenuItem_21.setForeground(Color.white);
		mntmNewMenuItem_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExameRemover exrem =  new ExameRemover();
				exrem.setVisible(true);
			}
		});
		mntmNewMenuItem_21
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\rmv (1).png"));
		mntmNewMenuItem_21.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_4.add(mntmNewMenuItem_21);

		JMenuItem mntmNewMenuItem_22 = new JMenuItem("Alterar");
		mntmNewMenuItem_22.setBackground(Color.black);
		mntmNewMenuItem_22.setForeground(Color.white);
		mntmNewMenuItem_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExameAlterar exalt = new ExameAlterar();
				exalt.setVisible(true);
			}
		});
		mntmNewMenuItem_22
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\lapis (1).png"));
		mntmNewMenuItem_22.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_4.add(mntmNewMenuItem_22);

		JMenuItem mntmNewMenuItem_23 = new JMenuItem("Listar");
		mntmNewMenuItem_23.setBackground(Color.black);
		mntmNewMenuItem_23.setForeground(Color.white);
		mntmNewMenuItem_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExameListar exL = new ExameListar();
				exL.setVisible(true);
			}
		});
		mntmNewMenuItem_23.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\listar.png"));
		mntmNewMenuItem_23.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_4.add(mntmNewMenuItem_23);

		JMenuItem mntmNewMenuItem_24 = new JMenuItem("Listar - Par\u00E2metro");
		mntmNewMenuItem_24.setBackground(Color.black);
		mntmNewMenuItem_24.setForeground(Color.white);
		mntmNewMenuItem_24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExameListarParametro exLP = new ExameListarParametro();
				exLP.setVisible(true);
			}
		});
		mntmNewMenuItem_24.setIcon(
				new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\checklist_106575 (1).png"));
		mntmNewMenuItem_24.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_4.add(mntmNewMenuItem_24);

		JMenu mnNewMenu_5 = new JMenu("Receita");
		mnNewMenu_5.setForeground(Color.BLACK);
		mnNewMenu_5.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\preceita (1).png"));
		mnNewMenu_5.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.add(mnNewMenu_5);

		JMenuItem mntmNewMenuItem_25 = new JMenuItem("Adicionar");
		mntmNewMenuItem_25.setBackground(Color.black);
		mntmNewMenuItem_25.setForeground(Color.white);
		mntmNewMenuItem_25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReceitaInserir RI = new ReceitaInserir();
				RI.setVisible(true);
			}
		});
		mntmNewMenuItem_25
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\adicao (1).png"));
		mntmNewMenuItem_25.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_5.add(mntmNewMenuItem_25);

		JMenuItem mntmNewMenuItem_26 = new JMenuItem("Remover");
		mntmNewMenuItem_26.setBackground(Color.black);
		mntmNewMenuItem_26.setForeground(Color.white);
		mntmNewMenuItem_26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReceitaRemover RR = new ReceitaRemover();
				RR.setVisible(true);
			}
		});
		mntmNewMenuItem_26
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\rmv (1).png"));
		mntmNewMenuItem_26.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_5.add(mntmNewMenuItem_26);

		JMenuItem mntmNewMenuItem_27 = new JMenuItem("Alterar");
		mntmNewMenuItem_27.setBackground(Color.black);
		mntmNewMenuItem_27.setForeground(Color.white);
		mntmNewMenuItem_27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReceitaAlterar RA = new ReceitaAlterar();
				RA.setVisible(true);
			}
		});
		mntmNewMenuItem_27
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\lapis (1).png"));
		mntmNewMenuItem_27.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_5.add(mntmNewMenuItem_27);

		JMenuItem mntmNewMenuItem_28 = new JMenuItem("Listar");
		mntmNewMenuItem_28.setBackground(Color.black);
		mntmNewMenuItem_28.setForeground(Color.white);
		mntmNewMenuItem_28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReceitaListar RL = new ReceitaListar();
				RL.setVisible(true);
			}
		});
		mntmNewMenuItem_28.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\listar.png"));
		mntmNewMenuItem_28.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_5.add(mntmNewMenuItem_28);

		JMenuItem mntmNewMenuItem_29 = new JMenuItem("Listar - Par\u00E2metro");
		mntmNewMenuItem_29.setBackground(Color.black);
		mntmNewMenuItem_29.setForeground(Color.white);
		mntmNewMenuItem_29.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ReceitaListarParametro RLP = new ReceitaListarParametro();
				RLP.setVisible(true);
			}
		});
		mntmNewMenuItem_29.setIcon(
				new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\checklist_106575 (1).png"));
		mntmNewMenuItem_29.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_5.add(mntmNewMenuItem_29);

		JMenu mnNewMenu_6 = new JMenu("Pesquisas");
		mnNewMenu_6.setForeground(SystemColor.activeCaptionText);
		mnNewMenu_6.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/addressbook-search (1).png")));

		menuBar.add(mnNewMenu_6);

		JMenuItem mntmNewMenuItem_33 = new JMenuItem("Consulta 1");
		mntmNewMenuItem_33.setBackground(Color.black);
		mntmNewMenuItem_33.setForeground(Color.white);
		mntmNewMenuItem_33.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/87-872219_lupa-icon (1).png")));
		mntmNewMenuItem_33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetConsulta1 vc1 = new VetConsulta1();
				vc1.setVisible(true);
			}
		});
		mntmNewMenuItem_33.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_6.add(mntmNewMenuItem_33);

		JMenuItem mntmNewMenuItem_34 = new JMenuItem("Consulta 2");
		mntmNewMenuItem_34.setBackground(Color.black);
		mntmNewMenuItem_34.setForeground(Color.white);
		mntmNewMenuItem_34.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/87-872219_lupa-icon (1).png")));
		mntmNewMenuItem_34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VetConsulta2 vetC2 = new VetConsulta2();
				vetC2.setVisible(true);
			}
		});
		mntmNewMenuItem_34.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_6.add(mntmNewMenuItem_34);

		JMenuItem mntmNewMenuItem_35 = new JMenuItem("Consulta 3");
		mntmNewMenuItem_35.setBackground(Color.black);
		mntmNewMenuItem_35.setForeground(Color.white);
		mntmNewMenuItem_35.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/87-872219_lupa-icon (1).png")));
		mntmNewMenuItem_35.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DepConsulta3 depC3 = new DepConsulta3();
				depC3.setVisible(true);

			}
		});
		mntmNewMenuItem_35.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_6.add(mntmNewMenuItem_35);

		JMenuItem mntmNewMenuItem_36 = new JMenuItem("Consulta 4");
		mntmNewMenuItem_36.setBackground(Color.black);
		mntmNewMenuItem_36.setForeground(Color.white);
		mntmNewMenuItem_36.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/87-872219_lupa-icon (1).png")));
		mntmNewMenuItem_36.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DepConsulta4 depC4 = new DepConsulta4();
				depC4.setVisible(true);
			}
		});
		mntmNewMenuItem_36.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_6.add(mntmNewMenuItem_36);

		JMenuItem mntmNewMenuItem_37 = new JMenuItem("Consulta 5");
		mntmNewMenuItem_37.setBackground(Color.black);
		mntmNewMenuItem_37.setForeground(Color.white);
		mntmNewMenuItem_37.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/87-872219_lupa-icon (1).png")));
		mntmNewMenuItem_37.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AnimalConsulta5 aC5 = new AnimalConsulta5();
				aC5.setVisible(true);

			}
		});
		mntmNewMenuItem_37.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mnNewMenu_6.add(mntmNewMenuItem_37);

		JMenuItem mntmNewMenuItem_38 = new JMenuItem("Consulta 6");
		mntmNewMenuItem_38.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TelCliConsulta6 tcc6 = new TelCliConsulta6();
				tcc6.setVisible(true);
			}
		});
		mntmNewMenuItem_38.setIcon(new ImageIcon(InterfacePrincipalCV.class.getResource("/img/87-872219_lupa-icon (1).png")));
		mntmNewMenuItem_38.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		mntmNewMenuItem_38.setBackground(Color.black);
		mntmNewMenuItem_38.setForeground(Color.white);
		mnNewMenu_6.add(mntmNewMenuItem_38);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Bem vindo(a) ao gerenciamento de Cl\u00EDnica Veterin\u00E1ria!");
		lblNewLabel.setBounds(64, 82, 531, 14);
		lblNewLabel.setFont(new Font("Bookshelf Symbol 7", Font.PLAIN, 11));
		lblNewLabel.setForeground(Color.WHITE);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_2 = new JLabel("Bem vindo(a) ao gerenciamento de Cl\u00EDnica Veterin\u00E1ria!");
		lblNewLabel_2.setBounds(64, 43, 497, 14);
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Bookshelf Symbol 7", Font.PLAIN, 11));
		contentPane.add(lblNewLabel_2);

		JLabel lblGerenciamentoDeClnica = new JLabel("Gerenciamento de Cl\u00EDnica Veterin\u00E1ria");
		lblGerenciamentoDeClnica.setBounds(120, 42, 400, 54);
		lblGerenciamentoDeClnica.setForeground(Color.WHITE);
		lblGerenciamentoDeClnica.setFont(new Font("Colonna MT", Font.PLAIN, 25));
		contentPane.add(lblGerenciamentoDeClnica);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(556, 11, 134, 79);
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\preguica.png"));
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(10, 260, 167, 164);
		lblNewLabel_3
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\cachorro1 (1).png"));
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Gerenciamento de:");
		lblNewLabel_4.setBounds(102, 292, 145, 14);
		lblNewLabel_4.setFont(new Font("Trebuchet MS", Font.PLAIN, 16));
		lblNewLabel_4.setForeground(Color.WHITE);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_4_1 = new JLabel("Veterin\u00E1rios");
		lblNewLabel_4_1.setBounds(132, 366, 90, 14);
		lblNewLabel_4_1.setForeground(Color.WHITE);
		lblNewLabel_4_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		contentPane.add(lblNewLabel_4_1);

		JLabel lblNewLabel_4_1_1 = new JLabel("Clientes");
		lblNewLabel_4_1_1.setBounds(143, 317, 183, 14);
		lblNewLabel_4_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		contentPane.add(lblNewLabel_4_1_1);

		JLabel lblNewLabel_4_1_2 = new JLabel("Animais");
		lblNewLabel_4_1_2.setBounds(143, 341, 59, 14);
		lblNewLabel_4_1_2.setForeground(Color.WHITE);
		lblNewLabel_4_1_2.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		contentPane.add(lblNewLabel_4_1_2);

		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(95, 101, 487, 150);
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\animais.png"));
		contentPane.add(lblNewLabel_5);

		JLabel lblNewLabel_4_2 = new JLabel("Registros de:");
		lblNewLabel_4_2.setBounds(465, 280, 140, 39);
		lblNewLabel_4_2.setForeground(Color.WHITE);
		lblNewLabel_4_2.setFont(new Font("Trebuchet MS", Font.PLAIN, 16));
		contentPane.add(lblNewLabel_4_2);

		JLabel lblNewLabel_4_1_1_1 = new JLabel("Exames");
		lblNewLabel_4_1_1_1.setBounds(485, 317, 183, 14);
		lblNewLabel_4_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		contentPane.add(lblNewLabel_4_1_1_1);

		JLabel lblNewLabel_4_1_1_1_1 = new JLabel("Consultas");
		lblNewLabel_4_1_1_1_1.setBounds(479, 341, 82, 14);
		lblNewLabel_4_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1_1.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		contentPane.add(lblNewLabel_4_1_1_1_1);

		JLabel lblNewLabel_4_1_1_1_2 = new JLabel("Receitas m\u00E9dicas");
		lblNewLabel_4_1_1_1_2.setBounds(451, 366, 116, 14);
		lblNewLabel_4_1_1_1_2.setForeground(Color.WHITE);
		lblNewLabel_4_1_1_1_2.setFont(new Font("Trebuchet MS", Font.PLAIN, 13));
		contentPane.add(lblNewLabel_4_1_1_1_2);

		JLabel lblNewLabel_3_1 = new JLabel("");
		lblNewLabel_3_1.setBounds(547, 260, 167, 178);
		lblNewLabel_3_1
		.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\bird-icon (1).png"));
		contentPane.add(lblNewLabel_3_1);
	}
}
