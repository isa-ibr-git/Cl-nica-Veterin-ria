package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Dependente;
import dao.ConsultasDAO;
import dao.DependenteDAO;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class DepConsulta4 extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DepConsulta4 frame = new DepConsulta4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public DepConsulta4() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(DepConsulta4.class.getResource("/img/87-872219_lupa-icon (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Indique o sexo de filtragem para a listagem dos dependentes:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 21, 364, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBoxSexo = new JComboBox();
		comboBoxSexo.setBounds(384, 17, 40, 22);
		comboBoxSexo.setModel(new DefaultComboBoxModel(new String[] {"F", "M"}));
		contentPane.add(comboBoxSexo);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 84, 402, 154);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF Funcion\u00E1rio", "Nome", "Data de N.", "Sexo"
			}
		));
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sexo = (String) comboBoxSexo.getSelectedItem();
				ConsultasDAO condao = new ConsultasDAO();
				DependenteDAO ddao = new DependenteDAO();
				ArrayList<Dependente> consulta4 = condao.consulta4(sexo);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(ddao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					
				}else {
				
					for(int i = 0; i < consulta4.size(); i++) {
					
						model.addRow(new Object[] {condao.consulta4(sexo).get(i).getCpf_func(), condao.consulta4(sexo).get(i).getNome(), condao.consulta4(sexo).get(i).getData_nas(), condao.consulta4(sexo).get(i).getSexo()});
						
				}
				}
			}
		});
		btnNewButton.setBounds(22, 50, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		           while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(335, 50, 89, 23);
		contentPane.add(btnNewButton_1);
		centralizarComponente();
	}

}
