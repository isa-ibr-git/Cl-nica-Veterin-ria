package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.ConsultaRegistra;
import dao.AnimalDAO;
import dao.ClienteDAO;
import dao.ConsultaRegistraDAO;
import dao.VeterinarioDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CrInserir extends JFrame {

	private JPanel contentPane;
	private JTextField tfDH;
	private JTextField tfValor;
	private JTextField tfDiagnostico;
	ClienteDAO cdao = new ClienteDAO();
	AnimalDAO adao = new AnimalDAO();
	VeterinarioDAO vdao = new VeterinarioDAO();
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrInserir frame = new CrInserir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public CrInserir() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CrInserir.class.getResource("/img/adicao (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInseroRegistros = new JLabel("Inser\u00E7\u00E3o - Registros de Consulta");
		lblInseroRegistros.setForeground(Color.WHITE);
		lblInseroRegistros.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblInseroRegistros.setBounds(108, 11, 276, 19);
		contentPane.add(lblInseroRegistros);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCpfVeterinrio.setBounds(10, 41, 103, 19);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCpfCliente.setBounds(10, 73, 103, 19);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCdigoAnimal.setBounds(10, 104, 103, 19);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblValor = new JLabel("Valor:");
		lblValor.setForeground(Color.WHITE);
		lblValor.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblValor.setBounds(10, 164, 103, 19);
		contentPane.add(lblValor);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblDataEHora.setBounds(10, 134, 103, 19);
		contentPane.add(lblDataEHora);
		
		JLabel lblDiagnstico = new JLabel("Diagn\u00F3stico:");
		lblDiagnstico.setForeground(Color.WHITE);
		lblDiagnstico.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblDiagnstico.setBounds(10, 194, 103, 19);
		contentPane.add(lblDiagnstico);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(108, 41, 92, 22);
		ArrayList <String > linha2 = new ArrayList<>();
		
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha2.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha2.size(); j++) {
			
		comboBoxCpfVet.addItem(linha2.get(j));
		
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(108, 71, 92, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpfCli.addItem(linha.get(j));
		
		}
		centralizarComponente();
	
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(108, 102, 92, 22);
		ArrayList<String> linha3 = new ArrayList<>();
		for(int i = 0; i < adao.getLista().size(); i++) {
			linha3.add(adao.getLista().get(i).getCodigo());
		}
		
		for(int j = 0 ; j < linha3.size(); j++) {
			comboBoxCodA.addItem(linha3.get(j));
		}
		contentPane.add(comboBoxCodA);
		
		tfDH = new JTextField();
		tfDH.setBounds(108, 134, 92, 20);
		contentPane.add(tfDH);
		tfDH.setColumns(10);
		
		tfValor = new JTextField();
		tfValor.setColumns(10);
		tfValor.setBounds(108, 163, 92, 20);
		contentPane.add(tfValor);
		
		tfDiagnostico = new JTextField();
		tfDiagnostico.setColumns(10);
		tfDiagnostico.setBounds(108, 193, 92, 20);
		contentPane.add(tfDiagnostico);
		
		JButton btnNewButton = new JButton("Enviar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfDH.getText().isEmpty() || tfValor.getText().isEmpty() || tfDiagnostico.getText().isEmpty() || comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 ){
					
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpfVet = (String) comboBoxCpfVet.getSelectedItem();
					String cpfCli = (String) comboBoxCpfCli.getSelectedItem();
					String codA = (String) comboBoxCodA.getSelectedItem();
					String dh = tfDH.getText();
					double valor = Double.parseDouble(tfValor.getText());
					String diag = tfDiagnostico.getText();
					
					ConsultaRegistra cr = new ConsultaRegistra(cpfVet, cpfCli, codA, dh, valor, diag);
					ConsultaRegistra cr2 = crdao.verificaCR(cpfVet, cpfCli, codA, dh);
					boolean v = cr.verificaData(dh);
					if(v == false) {
						JOptionPane.showMessageDialog(null, "Digite a data e hora na seguinte formata��o: aaaa-MM-dd hh:mm:ss", "Data e hora inv�lidos", JOptionPane.ERROR_MESSAGE, null);
						
					}
					else {
						if(cr2 != null) {
							JOptionPane.showMessageDialog(null, "J� existe um registro de consulta cadastrado esses dados", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
						}else {
							crdao.inserir(cr);
							JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
							
						}
						
						tfDH.setText("");
						tfValor.setText("");
						tfDiagnostico.setText("");
						}
					}
				}
		});
		btnNewButton.setBounds(238, 116, 89, 23);
		contentPane.add(btnNewButton);
		centralizarComponente();
	}
}
