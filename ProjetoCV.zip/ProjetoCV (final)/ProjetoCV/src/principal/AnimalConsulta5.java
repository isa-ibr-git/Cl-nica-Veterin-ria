package principal;

import java.awt.BorderLayout;

import java.awt.EventQueue;
import java.awt.Point;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.util.StringUtils;

import bean.Animal;
import bean.Dependente;
import dao.AnimalDAO;
import dao.ConsultasDAO;
import dao.DependenteDAO;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AnimalConsulta5 extends JFrame {

	private JPanel contentPane;
	AnimalDAO adao = new AnimalDAO();
	private JTable table;
	/**
	 * Launch the application.
	 */
	
	private boolean verificarExistencia(String s, ArrayList linha) {
	    for (int i = 0; i < linha.size(); i++) {
	        if (s.equals(linha.get(i))) {
	            return false;
	        }
	        
	        
	    }
	    return true;
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimalConsulta5 frame = new AnimalConsulta5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	
	/**
	 * Create the frame.
	 */
	public AnimalConsulta5() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AnimalConsulta5.class.getResource("/img/87-872219_lupa-icon (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 476, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIndiqueAEspcie = new JLabel("Indique a esp\u00E9cie de filtragem para a listagem dos animais:");
		lblIndiqueAEspcie.setForeground(Color.WHITE);
		lblIndiqueAEspcie.setBounds(10, 11, 385, 14);
		contentPane.add(lblIndiqueAEspcie);
		
		
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(370, 7, 54, 22);
		boolean achou = true;
		 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBox.getModel();
		for(int i = 0; i<adao.getLista().size(); i++) {
			String palavra = adao.getLista().get(i).getEspecie().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBox.addItem(adao.getLista().get(i).getEspecie().toLowerCase());
			}
			
		}

		contentPane.add(comboBox);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 86, 440, 164);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF C.", "C\u00F3digo", "Nome", "Ra\u00E7a", "Data de N", "Esp\u00E9cie", "Porte"
			}
		));
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String esp  = (String) comboBox.getSelectedItem();
				ConsultasDAO condao = new ConsultasDAO();
				AnimalDAO adao = new AnimalDAO();
				ArrayList<Animal> consulta5 = condao.consulta5(esp);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				
				if(comboBox.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					if(adao.getLista().isEmpty()) {
						JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
						model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
					}else {
					
						for(int i = 0; i < consulta5.size(); i++) {
						
							model.addRow(new Object[] {condao.consulta5(esp).get(i).getCPF_Cli(), condao.consulta5(esp).get(i).getCodigo(), condao.consulta5(esp).get(i).getNome(), condao.consulta5(esp).get(i).getRaca(), condao.consulta5(esp).get(i).getData_nas(), condao.consulta5(esp).get(i).getEspecie(), condao.consulta5(esp).get(i).getPorte()});
							
					}
					}
				}
			}
		});
		btnNewButton.setBounds(66, 52, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar tabela");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
		           
		            
		            
			
			}
		});
		btnNewButton_1.setBounds(280, 52, 115, 23);
		contentPane.add(btnNewButton_1);
		centralizarComponente();

	}
}
