package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.ConsultaRegistra;
import dao.AnimalDAO;
import dao.ClienteDAO;
import dao.ConsultaRegistraDAO;
import dao.VeterinarioDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CrRemover extends JFrame {

	private JPanel contentPane;
	ClienteDAO cdao = new ClienteDAO();
	AnimalDAO adao = new AnimalDAO();
	VeterinarioDAO vdao = new VeterinarioDAO();
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrRemover frame = new CrRemover();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public CrRemover() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CrRemover.class.getResource("/img/rmv (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIndiqueOCpf = new JLabel("Indique o CPF do cliente e do veterin\u00E1rio, c\u00F3digo do animal e data e hora ");
		lblIndiqueOCpf.setForeground(Color.WHITE);
		lblIndiqueOCpf.setBounds(10, 11, 414, 31);
		contentPane.add(lblIndiqueOCpf);
		
		JLabel lblNewLabel = new JLabel("para remo\u00E7\u00E3o:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 38, 90, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("CPF Veterin\u00E1rio:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 81, 90, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("CPF Cliente:");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setBounds(10, 113, 90, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("C\u00F3digo Animal:");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setBounds(10, 151, 90, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Data e hora:");
		lblNewLabel_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_3.setBounds(10, 184, 90, 14);
		contentPane.add(lblNewLabel_1_3);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(127, 77, 102, 22);
		ArrayList <String > linha2 = new ArrayList<>();
		
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha2.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha2.size(); j++) {
			
		comboBoxCpfVet.addItem(linha2.get(j));
		
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(127, 109, 102, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpfCli.addItem(linha.get(j));
		
		}
		centralizarComponente();
	
		contentPane.add(comboBoxCpfCli);
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(127, 143, 102, 22);
		ArrayList<String> linha3 = new ArrayList<>();
		for(int i = 0; i < adao.getLista().size(); i++) {
			linha3.add(adao.getLista().get(i).getCodigo());
		}
		
		for(int j = 0 ; j < linha3.size(); j++) {
			comboBoxCodA.addItem(linha3.get(j));
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(127, 176, 102, 22);
		ArrayList<String> linha4 = new ArrayList<>();
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0 ; j < linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
		contentPane.add(comboBoxDH);
		
		JButton btnNewButton = new JButton("Remover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0  ){
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpfVet = (String) comboBoxCpfVet.getSelectedItem();
				String cpfCli = (String) comboBoxCpfCli.getSelectedItem();
				String codA = (String) comboBoxCodA.getSelectedItem();
				String dh = (String) comboBoxDH.getSelectedItem();
				
				boolean achou = false;
				boolean achou2 = false;
				boolean achou3 = false;
				boolean achou4 = false;
				int i;
				int j;
				int k;
				int l;
				
				for(i=0;i<vdao.getLista().size();i++) {
					if(vdao.getLista().get(i).getCPF_Func().equals(cpfVet)) {
						achou = true;
						break;
					}
				}
				for(j=0;j<cdao.getLista().size();j++) {
					if(cdao.getLista().get(j).getCPF().equals(cpfCli)) {
						achou2 = true;
						break;
					}
				}
				
				for(k=0; k < adao.getLista().size(); k++) {
					if(adao.getLista().get(k).getCodigo().equals(codA)) {
						achou3 = true;
						break;
					}
				}
				
				for(l=0;l<crdao.getLista().size(); l++) {
					if(crdao.getLista().get(l).getData_hora().equals(dh)) {
						achou4 = true;
						break;
					}
				}
				
				ConsultaRegistra cr = new ConsultaRegistra(vdao.getLista().get(i).getCPF_Func(), cdao.getLista().get(j).getCPF(), adao.getLista().get(k).getCodigo(), crdao.getLista().get(l).getData_hora(),
						crdao.getLista().get(l).getValor(), crdao.getLista().get(l).getDiagnostico());
				int removeu = crdao.remover(cr);
				if(removeu > 0) {
					JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
					comboBoxDH.removeItem(dh);
				}else {
					JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
					}
			
				
				}
				
			}
		});
		btnNewButton.setBounds(90, 209, 89, 23);
		contentPane.add(btnNewButton);
		centralizarComponente();
	}

}
