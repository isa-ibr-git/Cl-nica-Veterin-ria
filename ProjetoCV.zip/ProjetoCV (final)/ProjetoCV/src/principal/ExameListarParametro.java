package principal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.ConsultaRegistraDAO;
import dao.ExameDAO;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Exame;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExameListarParametro extends JFrame {

	private JPanel contentPane;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();
	ExameDAO exdao = new ExameDAO();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExameListarParametro frame = new ExameListarParametro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public ExameListarParametro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ExameListarParametro.class.getResource("/img/checklist_106575 (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 624, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		centralizarComponente();
		contentPane.setLayout(null);
		
		JLabel lblCdigoExame = new JLabel("C\u00F3digo Exame:");
		lblCdigoExame.setForeground(Color.WHITE);
		lblCdigoExame.setBounds(10, 36, 81, 14);
		contentPane.add(lblCdigoExame);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setBounds(215, 36, 81, 14);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(423, 36, 81, 14);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setBounds(10, 61, 81, 14);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setBounds(215, 61, 81, 14);
		contentPane.add(lblDataEHora);
		
		JComboBox comboBoxEx = new JComboBox();
		comboBoxEx.setBounds(101, 32, 100, 22);
		ArrayList <String> linha5 = new ArrayList();
		
		for(int i = 0; i < exdao.getLista().size(); i++) {
			linha5.add(exdao.getLista().get(i).getCodigo_exame());
		}
		
		for(int j = 0; j<linha5.size(); j++) {
			comboBoxEx.addItem(linha5.get(j));
		}
		contentPane.add(comboBoxEx);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(302, 32, 100, 22);
		DefaultComboBoxModel model3 = (DefaultComboBoxModel) comboBoxCpfVet.getModel();
		boolean achou5 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model3.getIndexOf(crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase()) != -1) {
				achou5 = false;
			
			}else {
				comboBoxCpfVet.addItem(crdao.getLista().get(i).getCPF_Veterinairo());
			}
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(498, 32, 100, 22);
		DefaultComboBoxModel model2 = (DefaultComboBoxModel) comboBoxCpfCli.getModel();
		boolean achou4 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model2.getIndexOf(crdao.getLista().get(i).getCPF_Cliente().toLowerCase()) != -1) {
				achou4 = false;
			
			}else {
				comboBoxCpfCli.addItem(crdao.getLista().get(i).getCPF_Cliente());
			}
		}
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(101, 57, 100, 22);
		boolean achou = true;
		DefaultComboBoxModel model5 = (DefaultComboBoxModel) comboBoxCodA.getModel();
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model5.getIndexOf(crdao.getLista().get(i).getCodigo_animal().toLowerCase()) != -1) {
				achou = false;
			
			}else {
				comboBoxCodA.addItem(crdao.getLista().get(i).getCodigo_animal());
			}
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(302, 61, 100, 22);
		contentPane.add(comboBoxDH);
		
		JLabel lblSelecioneACombinao = new JLabel("Selecione a combina\u00E7\u00E3o ");
		lblSelecioneACombinao.setForeground(Color.WHITE);
		lblSelecioneACombinao.setBounds(10, 11, 140, 14);
		contentPane.add(lblSelecioneACombinao);
		
		JLabel lblParaListagem = new JLabel("para listagem:");
		lblParaListagem.setForeground(Color.WHITE);
		lblParaListagem.setBounds(145, 11, 81, 14);
		contentPane.add(lblParaListagem);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 120, 576, 130);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3d. Exame", "CPF V.", "CPF C.", "C\u00F3d. Animal", "Data e Hora"
			}
		));
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxEx.getItemCount() == 0 || comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String ex =  (String) comboBoxEx.getSelectedItem();
				String cpfVet =  (String) comboBoxCpfVet.getSelectedItem();
				String cpfCli =  (String) comboBoxCpfCli.getSelectedItem();
				String codA =  (String) comboBoxCodA.getSelectedItem();
				String dh=  (String) comboBoxDH.getSelectedItem();
				
				Exame ex2 = exdao.verificaEx(ex, cpfVet, cpfCli, codA, dh);
				if(ex2 != null) {
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.addRow(new Object[] {ex, cpfVet, cpfCli, codA, dh});
					
				}else {
					
					JOptionPane.showMessageDialog(null, "Combina��o de dados n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
				}
			}
			}
			
		});
		btnNewButton.setBounds(20, 86, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(509, 86, 89, 23);
		contentPane.add(btnNewButton_1);
		ArrayList <String> linha4 = new ArrayList();
		
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0; j<linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
	}

}
