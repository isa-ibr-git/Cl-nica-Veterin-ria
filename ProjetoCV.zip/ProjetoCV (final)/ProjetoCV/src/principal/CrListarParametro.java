package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import bean.Animal;
import bean.ConsultaRegistra;
import dao.AnimalDAO;
import dao.ClienteDAO;
import dao.ConsultaRegistraDAO;
import dao.VeterinarioDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CrListarParametro extends JFrame {

	private JPanel contentPane;
	private JTable table;
	ClienteDAO cdao = new ClienteDAO();
	AnimalDAO adao = new AnimalDAO();
	VeterinarioDAO vdao = new VeterinarioDAO();
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrListarParametro frame = new CrListarParametro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public CrListarParametro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CrListarParametro.class.getResource("/img/checklist_106575 (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 626, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIndiqueOCpf = new JLabel("Indique o CPF do cliente e do veterin\u00E1rio, c\u00F3digo do animal e data e hora ");
		lblIndiqueOCpf.setForeground(Color.WHITE);
		lblIndiqueOCpf.setBounds(10, 0, 414, 31);
		contentPane.add(lblIndiqueOCpf);
		
		JLabel lblParaAListagem = new JLabel("para a listagem por par\u00E2metro:");
		lblParaAListagem.setForeground(Color.WHITE);
		lblParaAListagem.setBounds(366, 0, 414, 31);
		contentPane.add(lblParaAListagem);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setBounds(10, 26, 100, 31);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(243, 26, 84, 31);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setBounds(432, 26, 84, 31);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setBounds(10, 54, 84, 31);
		contentPane.add(lblDataEHora);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(120, 30, 113, 22);
		ArrayList <String > linha2 = new ArrayList<>();
		
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha2.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha2.size(); j++) {
			
		comboBoxCpfVet.addItem(linha2.get(j));
		
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(311, 30, 113, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpfCli.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(526, 30, 74, 22);
		ArrayList<String> linha3 = new ArrayList<>();
		for(int i = 0; i < adao.getLista().size(); i++) {
			linha3.add(adao.getLista().get(i).getCodigo());
		}
		
		for(int j = 0 ; j < linha3.size(); j++) {
			comboBoxCodA.addItem(linha3.get(j));
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(120, 58, 113, 22);
		ArrayList<String> linha4 = new ArrayList<>();
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0 ; j < linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
		contentPane.add(comboBoxDH);
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0  ){
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpfVet =  (String) comboBoxCpfVet.getSelectedItem();
					String cpfCli =  (String) comboBoxCpfCli.getSelectedItem();
					String cod = (String) comboBoxCodA.getSelectedItem();
					String dh =  (String) comboBoxDH.getSelectedItem();
					ConsultaRegistra cr = crdao.verificaCR(cpfVet, cpfCli, cod, dh);
					boolean achou = false;
					int i;
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					if(crdao.getLista().isEmpty()) {
						JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
						model.addRow(new Object[] {"", "", "", "", "", ""});
					}else {
						for (i = 0; i < crdao.getLista().size(); i++) {
							if(crdao.getLista().get(i).getCPF_Veterinairo().equals(cpfVet) && crdao.getLista().get(i).getCPF_Cliente().equals(cpfCli) && crdao.getLista().get(i).getCodigo_animal().equals(cod) && crdao.getLista().get(i).getData_hora().equals(dh)) {
								achou = true;
								break;
							}
						}
						
						if(achou) {
							
								model.addRow(new Object[] {crdao.getLista().get(i).getCPF_Veterinairo(), crdao.getLista().get(i).getCPF_Cliente(), crdao.getLista().get(i).getCodigo_animal(), crdao.getLista().get(i).getData_hora(), crdao.getLista().get(i).getValor(), crdao.getLista().get(i).getDiagnostico()});
				
						}else {
							JOptionPane.showMessageDialog(null, "Combina��o de dados selecionados n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
						}
					}
				}
			}
		});
		btnNewButton.setBounds(210, 91, 89, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 125, 600, 125);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF V.", "CPF C.", "C\u00F3digo A.", "Data e hora", "Valor", "Diagn\u00F3stico"
			}
		));
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(311, 91, 89, 23);
		contentPane.add(btnNewButton_1);
		centralizarComponente();
	

	}
}
