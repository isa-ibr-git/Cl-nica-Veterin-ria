package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Dependente;
import bean.Tel_vet;
import bean.Veterinario;

import dao.DependenteDAO;
import dao.VeterinarioDAO;

import javax.swing.JScrollPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class Dependented extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	DependenteDAO dDao = new DependenteDAO();
	VeterinarioDAO vdao = new VeterinarioDAO();
	private JButton btnNewButton;
	private JLabel lblNomeDoDependente;
	private JComboBox comboBoxCpf;
	private JTextField tfDep;
	private JLabel lblDataDeNascimento;
	private JLabel lblNascimento;
	private JLabel lblSexo;
	private JTextField tfDataNas;
	private JButton btnNewButton_1;
	private JLabel lblCpf;
	private JLabel lblNome;
	private JComboBox comboBoxCpf2;
	private JComboBox comboBoxNome;
	private JButton btnNewButton_2;
	private JComboBox comboBoxSexo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dependented frame = new Dependented();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public Dependented() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Dependented.class.getResource("/img/dep (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CPF do cliente:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 0, 89, 25);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 150, 414, 100);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Cliente", "Nome", "Data de N", "Sexo"
			}
		));
		
		btnNewButton = new JButton("Atualizar Tabela");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				
				
				if(model.getRowCount() == 0) {
					model.addRow(new Object[] {"", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            for (int i=0;i<=model.getRowCount();i++){
		                model.removeRow(0);
		            }      
		            for(int i = 0; i<dDao.getLista().size(); i++) {
						model.addRow(new Object[] {dDao.getLista().get(i).getCpf_func(), dDao.getLista().get(i).getNome(), dDao.getLista().get(i).getData_nas(), dDao.getLista().get(i).getSexo()});
					}
		       
			 
			

				}
				}
		});
		btnNewButton.setBounds(287, 130, 137, 23);
		contentPane.add(btnNewButton);
		
		lblNomeDoDependente = new JLabel("Nome do dependente:");
		lblNomeDoDependente.setForeground(Color.WHITE);
		lblNomeDoDependente.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNomeDoDependente.setBounds(10, 32, 107, 25);
		contentPane.add(lblNomeDoDependente);
		
		comboBoxCpf = new JComboBox();
		comboBoxCpf.setBounds(124, 1, 89, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i = 0; i < vdao.getLista().size(); i++) {
			linha.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpf.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpf);
		
		comboBoxSexo = new JComboBox();
		comboBoxSexo.setBounds(148, 94, 36, 22);
		contentPane.add(comboBoxSexo);
		comboBoxSexo.setModel(new DefaultComboBoxModel(new String[] {"F", "M"}));
		tfDep = new JTextField();
		tfDep.setBounds(127, 37, 86, 20);
		contentPane.add(tfDep);
		tfDep.setColumns(10);
		
		comboBoxCpf2 = new JComboBox();
		comboBoxCpf2.setBounds(301, 1, 89, 22);
		ArrayList <String > linha2 = new ArrayList<>();
		
		for(int i = 0; i < vdao.getLista().size(); i++) {
			linha2.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha2.size(); j++) {
			
		comboBoxCpf2.addItem(linha2.get(j));
		
		}
		contentPane.add(comboBoxCpf2);
		
		comboBoxNome = new JComboBox();
		comboBoxNome.setBounds(301, 33, 89, 22);
		ArrayList <String > linha3 = new ArrayList<>();
		
		for(int i = 0; i < dDao.getLista().size(); i++) {
			linha3.add(dDao.getLista().get(i).getNome());
		}
		
		for(int j=0; j < linha3.size(); j++) {
			
		comboBoxNome.addItem(linha3.get(j));
		
		}
		contentPane.add(comboBoxNome);
		
		lblDataDeNascimento = new JLabel("Data de");
		lblDataDeNascimento.setForeground(Color.WHITE);
		lblDataDeNascimento.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblDataDeNascimento.setBounds(10, 55, 89, 20);
		contentPane.add(lblDataDeNascimento);
		
		lblNascimento = new JLabel("Nascimento:");
		lblNascimento.setForeground(Color.WHITE);
		lblNascimento.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNascimento.setBounds(10, 58, 89, 41);
		contentPane.add(lblNascimento);
		
		lblSexo = new JLabel("Sexo:");
		lblSexo.setForeground(Color.WHITE);
		lblSexo.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblSexo.setBounds(10, 93, 89, 25);
		contentPane.add(lblSexo);
		
		tfDataNas = new JTextField();
		tfDataNas.setBounds(127, 68, 86, 20);
		contentPane.add(tfDataNas);
		tfDataNas.setColumns(10);
		
		btnNewButton_1 = new JButton("Inserir");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfDep.getText().isEmpty() || tfDataNas.getText().isEmpty() ||  comboBoxCpf.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf = (String) comboBoxCpf.getSelectedItem();
					String nome = tfDep.getText();
					String dn = tfDataNas.getText();
					String sexo = (String) comboBoxSexo.getSelectedItem();
					
					Dependente d = new Dependente(cpf, nome, dn, sexo);
					
					Dependente d2 = dDao.verificaDep(cpf, nome);
					
					boolean v = d.verificaData(dn);
					if(v==false) {
						JOptionPane.showMessageDialog(null, "Digite a data na seguinte formata��o: aaaa-MM-dd", "Data inv�lida", JOptionPane.ERROR_MESSAGE, null);
					}else {
						if(d2 != null) {
							JOptionPane.showMessageDialog(null, "J� existe um Cliente cadastrado esse CPF", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
						}else {
							dDao.inserir(d);
							JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
							comboBoxNome.addItem(nome);
						}
						tfDep.setText("");
						tfDataNas.setText("");
			
					}
				
				}
			}
		});
		btnNewButton_1.setBounds(47, 116, 89, 23);
		contentPane.add(btnNewButton_1);
		
		lblCpf = new JLabel("CPF:");
		lblCpf.setForeground(Color.WHITE);
		lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblCpf.setBounds(239, 5, 89, 25);
		contentPane.add(lblCpf);
		
		lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNome.setBounds(239, 37, 89, 25);
		contentPane.add(lblNome);
		
		
		
		btnNewButton_2 = new JButton("Remover");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean achou = false;
				boolean achou2 = false;
				int i;
				int j;
				int k = 1;
				String cpf = (String) comboBoxCpf2.getSelectedItem();
				String nome = (String) comboBoxNome.getSelectedItem();
				for(i = 0; i < vdao.getLista().size(); i++) {
					if(vdao.getLista().get(i).getCPF_Func().equals(cpf)) {
						achou = true;
						break;
					}
				}
				
				for(j = 0; j < dDao.getLista().size(); j++) {
					if(dDao.getLista().get(j).getNome().equals(nome)) {
						achou2 = true;
						break;
					}
				}
				
				
				if(comboBoxNome.getItemCount() == 0 || comboBoxCpf2.getItemCount()==0 ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				Dependente d= new Dependente(vdao.getLista().get(i).getCPF_Func(), dDao.getLista().get(j).getNome(), dDao.getLista().get(j).getData_nas(), dDao.getLista().get(j).getSexo());
				int removeu = dDao.remover(d);
				if(removeu > 0) {
					JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
					comboBoxNome.removeItem(nome);

	
				}else {
					JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
					}
				}
			
			}
		});
		btnNewButton_2.setBounds(301, 67, 89, 23);
		contentPane.add(btnNewButton_2);
		
	
		

		
		centralizarComponente();
	}

}
