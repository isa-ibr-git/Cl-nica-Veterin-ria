package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Veterinario;
import dao.VeterinarioDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class VetInserir extends JFrame {

	private JPanel contentPane;
	private JTextField tfCpf;
	private JTextField tfCrv;
	private JTextField tfRg;
	private JTextField tfDataNas;
	private JTextField tfNumCartao;
	private JTextField tfSalario;
	private JTextField tfNome;
	private JTextField tfBairro;
	private JTextField tfNum;
	private JTextField tfPais;
	private JTextField tfLog;
	private JTextField tfCidade;
	private JTextField tfInstituicao;
	private JTextField tfDataConclusao;
	private JTextField tfCep;
	
	VeterinarioDAO vdao = new VeterinarioDAO();
	ArrayList <Veterinario> vets = new ArrayList<>();

	/**
	 * Launch the application.
	 */
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VetInserir frame = new VetInserir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VetInserir() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VetInserir.class.getResource("/img/adicao (1).png")));
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 467, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Inser\u00E7\u00E3o - Veterin\u00E1rio");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(146, 0, 189, 19);
		contentPane.add(lblNewLabel);
		centralizarComponente();
		
		JLabel lblCPF = new JLabel("CPF:");
		lblCPF.setForeground(Color.WHITE);
		lblCPF.setBounds(10, 58, 46, 14);
		contentPane.add(lblCPF);
		
		JLabel lblCRV = new JLabel("CRV:");
		lblCRV.setForeground(Color.WHITE);
		lblCRV.setBackground(Color.WHITE);
		lblCRV.setBounds(10, 124, 46, 14);
		contentPane.add(lblCRV);
		
		JLabel lblNewLabel_1 = new JLabel("N\u00FAmero do cart\u00E3o:");
		lblNewLabel_1.setBounds(10, 124, 46, 0);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblnumCartao = new JLabel("N\u00FAmero");
		lblnumCartao.setForeground(Color.WHITE);
		lblnumCartao.setBackground(Color.WHITE);
		lblnumCartao.setBounds(10, 222, 46, 19);
		contentPane.add(lblnumCartao);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setForeground(Color.WHITE);
		lblNome.setBackground(Color.WHITE);
		lblNome.setBounds(10, 33, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblRg = new JLabel("RG:");
		lblRg.setForeground(Color.WHITE);
		lblRg.setBackground(Color.WHITE);
		lblRg.setBounds(10, 99, 29, 14);
		contentPane.add(lblRg);
		
		JLabel lblDataDeNascimento = new JLabel("Data de");
		lblDataDeNascimento.setForeground(Color.WHITE);
		lblDataDeNascimento.setBackground(Color.WHITE);
		lblDataDeNascimento.setBounds(10, 197, 46, 14);
		contentPane.add(lblDataDeNascimento);
		
		JLabel lblSalario = new JLabel("Sal\u00E1rio:");
		lblSalario.setForeground(Color.WHITE);
		lblSalario.setBackground(Color.WHITE);
		lblSalario.setBounds(10, 163, 46, 14);
		contentPane.add(lblSalario);
		
		JLabel lblCep = new JLabel("CEP:");
		lblCep.setForeground(Color.WHITE);
		lblCep.setBackground(Color.WHITE);
		lblCep.setBounds(146, 33, 46, 14);
		contentPane.add(lblCep);
		
		JLabel lblNmero = new JLabel("N\u00FAmero:");
		lblNmero.setForeground(Color.WHITE);
		lblNmero.setBackground(Color.WHITE);
		lblNmero.setBounds(146, 58, 46, 14);
		contentPane.add(lblNmero);
		
		JLabel lblLogradouro = new JLabel("Logradouro:");
		lblLogradouro.setForeground(Color.WHITE);
		lblLogradouro.setBackground(Color.WHITE);
		lblLogradouro.setBounds(146, 89, 62, 34);
		contentPane.add(lblLogradouro);
		
		JLabel lblCidade = new JLabel("Cidade:");
		lblCidade.setForeground(Color.WHITE);
		lblCidade.setBackground(Color.WHITE);
		lblCidade.setBounds(146, 124, 46, 14);
		contentPane.add(lblCidade);
		
		JLabel lblBairro = new JLabel("Bairro:");
		lblBairro.setForeground(Color.WHITE);
		lblBairro.setBackground(Color.WHITE);
		lblBairro.setBounds(152, 163, 46, 14);
		contentPane.add(lblBairro);
		
		JLabel lblEstado = new JLabel("Estado:");
		lblEstado.setForeground(Color.WHITE);
		lblEstado.setBackground(Color.WHITE);
		lblEstado.setBounds(152, 197, 46, 14);
		contentPane.add(lblEstado);
		
		JLabel lblPas = new JLabel("Pa\u00EDs:");
		lblPas.setForeground(Color.WHITE);
		lblPas.setBackground(Color.WHITE);
		lblPas.setBounds(152, 234, 46, 14);
		contentPane.add(lblPas);
		
		JLabel lblInstituio = new JLabel("Institui\u00E7\u00E3o:");
		lblInstituio.setForeground(Color.WHITE);
		lblInstituio.setBackground(Color.WHITE);
		lblInstituio.setBounds(297, 33, 81, 14);
		contentPane.add(lblInstituio);
		
		JLabel lblDataDeConcluso = new JLabel("Data de ");
		lblDataDeConcluso.setForeground(Color.WHITE);
		lblDataDeConcluso.setBackground(Color.WHITE);
		lblDataDeConcluso.setBounds(297, 58, 53, 14);
		contentPane.add(lblDataDeConcluso);
		
		tfCpf = new JTextField();
		tfCpf.setBounds(66, 55, 62, 20);
		contentPane.add(tfCpf);
		tfCpf.setColumns(10);
		
		tfCrv = new JTextField();
		tfCrv.setBounds(66, 121, 62, 19);
		contentPane.add(tfCrv);
		tfCrv.setColumns(10);
		
		tfRg = new JTextField();
		tfRg.setColumns(10);
		tfRg.setBounds(66, 96, 62, 20);
		contentPane.add(tfRg);
		
		tfDataNas = new JTextField();
		tfDataNas.setColumns(10);
		tfDataNas.setBounds(66, 194, 62, 20);
		contentPane.add(tfDataNas);
		
		tfNumCartao = new JTextField();
		tfNumCartao.setColumns(10);
		tfNumCartao.setBounds(66, 221, 62, 20);
		contentPane.add(tfNumCartao);
		
		tfSalario = new JTextField();
		tfSalario.setColumns(10);
		tfSalario.setBounds(66, 160, 62, 20);
		contentPane.add(tfSalario);
		
		tfNome = new JTextField();
		tfNome.setColumns(10);
		tfNome.setBounds(66, 30, 62, 20);
		contentPane.add(tfNome);
		
		JLabel lblNewLabel_2 = new JLabel("Nascimento:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(10, 206, 75, 14);
		contentPane.add(lblNewLabel_2);
		
		tfBairro = new JTextField();
		tfBairro.setColumns(10);
		tfBairro.setBounds(222, 160, 62, 20);
		contentPane.add(tfBairro);
		
		tfNum = new JTextField();
		tfNum.setColumns(10);
		tfNum.setBounds(222, 55, 62, 20);
		contentPane.add(tfNum);
		
		JComboBox comboBoxEstado = new JComboBox();
		comboBoxEstado.setToolTipText("");
		comboBoxEstado.setBounds(222, 193, 62, 22);
		comboBoxEstado.setModel(new DefaultComboBoxModel(new String[] {"AC", "AL", "AP", "AM", "BA", "CE", "ES", "GO", "MA", "MT", "MS",
				"MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", "DF"}));
		contentPane.add(comboBoxEstado);
		
		tfPais = new JTextField();
		tfPais.setColumns(10);
		tfPais.setBounds(222, 231, 62, 20);
		contentPane.add(tfPais);
		
		tfLog = new JTextField();
		tfLog.setColumns(10);
		tfLog.setBounds(222, 96, 62, 20);
		contentPane.add(tfLog);
		
		tfCidade = new JTextField();
		tfCidade.setColumns(10);
		tfCidade.setBounds(222, 121, 62, 20);
		contentPane.add(tfCidade);
		
		tfInstituicao = new JTextField();
		tfInstituicao.setColumns(10);
		tfInstituicao.setBounds(381, 30, 62, 20);
		contentPane.add(tfInstituicao);
		
		tfDataConclusao = new JTextField();
		tfDataConclusao.setColumns(10);
		tfDataConclusao.setBounds(381, 55, 62, 20);
		contentPane.add(tfDataConclusao);
		
		JLabel lblNewLabel_2_1 = new JLabel("do cart\u00E3o:");
		lblNewLabel_2_1.setForeground(Color.WHITE);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_2_1.setBounds(10, 227, 53, 34);
		contentPane.add(lblNewLabel_2_1);
		
		tfCep = new JTextField();
		tfCep.setColumns(10);
		tfCep.setBounds(222, 30, 62, 20);
		contentPane.add(tfCep);
		
		JLabel lblNewLabel_3 = new JLabel("conclus\u00E3o:");
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setBounds(297, 76, 68, 14);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("Enviar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfCpf.getText().isEmpty() || tfCrv.getText().isEmpty() || tfNumCartao.getText().isEmpty() || tfNome.getText().isEmpty() || tfRg.getText().isEmpty() || tfDataNas.getText().isEmpty() || tfSalario.getText() == null || tfCep.getText().isEmpty() || tfNum.getText() == null 
						|| tfNome.getText().isEmpty()|| tfCidade.getText().isEmpty() || tfBairro.getText().isEmpty()|| tfPais.getText().isEmpty() || tfInstituicao.getText().isEmpty() || tfDataConclusao.getText().isEmpty()) { 
					
					
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					
				}else {
					String cpf =  tfCpf.getText();
					String crv = tfCrv.getText();
					String numC = tfNumCartao.getText();
					String nome = tfNome.getText();
					String rg = tfRg.getText();
					String dataNas = tfDataNas.getText();
					double salario = Double.parseDouble(tfSalario.getText());
					String cep = tfCep.getText();
					int num = Integer.parseInt(tfNum.getText());
					String log = tfLog.getText();
					String cidade = tfCidade.getText();
					String bairro = tfBairro.getText();
					String estado =  (String) comboBoxEstado.getSelectedItem();
					String pais = tfPais.getText();
					String instituicao = tfInstituicao.getText();
					String dataC = tfDataConclusao.getText();
				
				
					Veterinario v = new Veterinario (cpf, crv, numC, nome, rg, dataNas, salario, cep, num, log, cidade, bairro, estado, pais, instituicao, dataC);			 
					Veterinario v2 = vdao.verificaVet(cpf);
					if(v2 != null) {
						JOptionPane.showMessageDialog(null, "J� existe um veterin�rio cadastrado esse CPF", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
					}else {
						vdao.inserir(v);
						JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
						vets.add(v);
					}
					
					tfCpf.setText("");
					tfCrv.setText("");
					tfNumCartao.setText("");
					tfNome.setText("");
					tfRg.setText("");
					tfDataNas.setText("");
					tfSalario.setText("");
					tfCep.setText("");
					tfNum.setText("");
					tfLog.setText("");
					tfCidade.setText("");
					tfBairro.setText("");
					tfPais.setText("");
					tfInstituicao.setText("");
					tfDataConclusao.setText("");
					
				
				}
			}
			
		});
		btnNewButton.setBounds(335, 101, 89, 23);
		contentPane.add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 0, 451, 261);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(301, 150, 150, 100);
		panel.add(lblNewLabel_4);
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Isabelly\\Desktop\\TEP\\ProjetoCV\\src\\img\\vetcac (1).png"));
		
		
		
		
	}
}
