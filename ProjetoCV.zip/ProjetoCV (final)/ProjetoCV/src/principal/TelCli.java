package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Tel_cli;
import bean.Tel_vet;
import dao.ClienteDAO;
import dao.Tel_cliDAO;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelCli extends JFrame {

	private JPanel contentPane;
	private JTextField tfTel;
	private JTable table;
	ClienteDAO cdao = new ClienteDAO();
	Tel_cliDAO tcdao = new Tel_cliDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelCli frame = new TelCli();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	
	/**
	 * Create the frame.
	 */
	public TelCli() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelCli.class.getResource("/img/tel (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInserir = new JLabel("Inserir Telefone");
		lblInserir.setForeground(Color.WHITE);
		lblInserir.setBounds(42, 11, 97, 14);
		contentPane.add(lblInserir);
		
		JLabel lblRemoverTelefone = new JLabel("Remover Telefone");
		lblRemoverTelefone.setForeground(Color.WHITE);
		lblRemoverTelefone.setBounds(308, 11, 114, 14);
		contentPane.add(lblRemoverTelefone);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(10, 36, 97, 14);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCpfTelefone = new JLabel("Telefone:");
		lblCpfTelefone.setForeground(Color.WHITE);
		lblCpfTelefone.setBounds(10, 61, 97, 14);
		contentPane.add(lblCpfTelefone);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setForeground(Color.WHITE);
		lblCpf.setBounds(253, 36, 51, 14);
		contentPane.add(lblCpf);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setForeground(Color.WHITE);
		lblTelefone.setBounds(253, 61, 46, 14);
		contentPane.add(lblTelefone);
		
		JComboBox comboBoxCpf = new JComboBox();
		comboBoxCpf.setBounds(81, 32, 103, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpf.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpf);
		
		JComboBox comboBoxCpf2 = new JComboBox();
		comboBoxCpf2.setBounds(319, 36, 103, 22);
		ArrayList <String > linha2 = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha2.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha2.size(); j++) {
			
		comboBoxCpf2.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpf2);
		
		JComboBox comboBoxTel = new JComboBox();
		comboBoxTel.setBounds(319, 57, 103, 22);
		ArrayList <String > linha3 = new ArrayList<>();
		for(int k=0; k < tcdao.getLista().size(); k++) {
			linha3.add(tcdao.getLista().get(k).getTelefone_cli());
		}
		
		for(int l=0; l < linha3.size(); l++) {
			
		comboBoxTel.addItem(linha3.get(l));
		
		}
		
		contentPane.add(comboBoxTel);
		
		tfTel = new JTextField();
		tfTel.setBounds(81, 58, 86, 20);
		contentPane.add(tfTel);
		tfTel.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Bem vindo(a) ao gerenciamento de Cl\u00EDnica Veterin\u00E1ria!");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Bookshelf Symbol 7", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(8, 118, 414, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Inserir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCpf.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					if(tfTel.getText().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					}else {
					String cpf = (String) comboBoxCpf.getSelectedItem();
					String tel = tfTel.getText();
					Tel_cli tc = new Tel_cli(cpf, tel);
					Tel_cli tc2 = tcdao.verificaTel_cli(cpf, tel);
					if(tc2 != null) {
						JOptionPane.showMessageDialog(null, "J� existe um telefone de cliente cadastrado esse CPF e esse n�mero", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
					}else {
						tcdao.inserir(tc);
						JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
						comboBoxTel.addItem(tc.getTelefone_cli());
					
						
					}
					
					tfTel.setText("");
					}
					
				}
			}
		});
		btnNewButton.setBounds(10, 86, 157, 23);
		contentPane.add(btnNewButton);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean achou = false;
				boolean achou2 = false;
				int i;
				int j;
				int k = 1;
				if(comboBoxCpf2.getItemCount() == 0 || comboBoxTel.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf = (String) comboBoxCpf2.getSelectedItem();
					String tel = (String) comboBoxTel.getSelectedItem();
					for(i = 0; i < cdao.getLista().size(); i++) {
						if(cdao.getLista().get(i).getCPF().equals(cpf)) {
							achou = true;
							break;
						}
					}
					
					for(j = 0; j < tcdao.getLista().size(); j++) {
						if(tcdao.getLista().get(j).getTelefone_cli().equals(tel)) {
							achou2 = true;
							break;
						}
					}
					
					
					
					Tel_cli tc = new Tel_cli(cdao.getLista().get(i).getCPF(), tcdao.getLista().get(j).getTelefone_cli());
					int removeu = tcdao.remover(tc);
					if(removeu > 0) {
						JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
						comboBoxTel.removeItem(tel);
						
						
					}else {
						JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
						}
				
				}
			}
		});
		btnRemover.setBounds(253, 86, 169, 23);
		contentPane.add(btnRemover);
		
		JButton btnNewButton_3 = new JButton("Atualizar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				
				if(model.getRowCount() == 0) {
					model.addRow(new Object[] {"", ""});
				}
				
				 if (model.getRowCount() > 0){
			            for (int i=0;i<=model.getRowCount();i++){
			                model.removeRow(0);
			            }  
			            for(int i = 0; i<tcdao.getLista().size(); i++) {
							model.addRow(new Object[] {tcdao.getLista().get(i).getCPF_Cliente(), tcdao.getLista().get(i).getTelefone_cli()});
						}
			        }
				 
				 

			}
		});
		btnNewButton_3.setBounds(147, 132, 152, 23);
		contentPane.add(btnNewButton_3);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(53, 163, 330, 87);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Cliente", "Telefone"
			}
		));
		centralizarComponente();
	}

}
