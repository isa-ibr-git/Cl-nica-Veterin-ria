package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.ConsultaRegistra;
import bean.Exame;
import bean.Receita;
import bean.Veterinario;
import dao.ConsultaRegistraDAO;
import dao.ReceitaDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ReceitaInserir extends JFrame {

	private JPanel contentPane;
	private JTextField tfCodR;
	private JTextField tfMedicamento;
	private JTextField tfDD;
	private JTextField tfTT;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();
	ReceitaDAO rdao = new ReceitaDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceitaInserir frame = new ReceitaInserir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
	}

	/**
	 * Create the frame.
	 */
	public ReceitaInserir() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ReceitaInserir.class.getResource("/img/adicao (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("C\u00F3digo da Receita:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(23, 36, 104, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblMedicamento = new JLabel("Medicamento:");
		lblMedicamento.setForeground(Color.WHITE);
		lblMedicamento.setBounds(23, 61, 104, 14);
		contentPane.add(lblMedicamento);
		
		JLabel lblDoseDiria = new JLabel("Dose di\u00E1ria:");
		lblDoseDiria.setForeground(Color.WHITE);
		lblDoseDiria.setBounds(23, 86, 104, 14);
		contentPane.add(lblDoseDiria);
		
		JLabel lblTempoDeTratamento = new JLabel("Tempo de tratamento:");
		lblTempoDeTratamento.setForeground(Color.WHITE);
		lblTempoDeTratamento.setBounds(23, 111, 127, 14);
		contentPane.add(lblTempoDeTratamento);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setBounds(234, 36, 104, 14);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(234, 61, 104, 14);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setBounds(234, 86, 104, 14);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setBounds(234, 111, 104, 14);
		contentPane.add(lblDataEHora);
		
		tfCodR = new JTextField();
		tfCodR.setBounds(135, 33, 86, 20);
		contentPane.add(tfCodR);
		tfCodR.setColumns(10);
		
		tfMedicamento = new JTextField();
		tfMedicamento.setColumns(10);
		tfMedicamento.setBounds(135, 58, 86, 20);
		contentPane.add(tfMedicamento);
		
		tfDD = new JTextField();
		tfDD.setColumns(10);
		tfDD.setBounds(135, 83, 86, 20);
		contentPane.add(tfDD);
		
		tfTT = new JTextField();
		tfTT.setColumns(10);
		tfTT.setBounds(135, 105, 86, 20);
		contentPane.add(tfTT);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(326, 32, 86, 22);
		DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCpfVet.getModel();
		boolean achou3 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model.getIndexOf(crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase()) != -1) {
				achou3 = false;
			
			}else {
				comboBoxCpfVet.addItem(crdao.getLista().get(i).getCPF_Veterinairo());
			}
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(326, 57, 86, 22);
		DefaultComboBoxModel model2 = (DefaultComboBoxModel) comboBoxCpfCli.getModel();
		boolean achou4 = true;
		for(int i = 0; i < crdao.getLista().size(); i++) {
			if(model2.getIndexOf(crdao.getLista().get(i).getCPF_Cliente().toLowerCase()) != -1) {
				achou4 = false;
			
			}else {
				comboBoxCpfCli.addItem(crdao.getLista().get(i).getCPF_Cliente());
			}
		}
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(326, 82, 86, 22);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model3 = (DefaultComboBoxModel) comboBoxCodA.getModel();
			String palavra = crdao.getLista().get(i).getCodigo_animal().toLowerCase();
			int a = model3.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCodA.addItem(crdao.getLista().get(i).getCodigo_animal().toLowerCase());
			}
			
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(326, 107, 86, 22);
		ArrayList <String> linha4 = new ArrayList();
		
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0; j<linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
		
		contentPane.add(comboBoxDH);
		
		JButton btnNewButton = new JButton("Inserir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(tfCodR.getText().isEmpty() || tfMedicamento.getText().isEmpty() || tfDD.getText().isEmpty() || tfTT.getText().isEmpty()
						|| comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String codR = tfCodR.getText();
					String med = tfMedicamento.getText();
					String doseD = tfDD.getText();
					String tempoT = tfTT.getText();
					String cpfVet =  (String) comboBoxCpfVet.getSelectedItem();
					String cpfCli =  (String) comboBoxCpfCli.getSelectedItem();
					String codA =  (String) comboBoxCodA.getSelectedItem();
					String dh=  (String) comboBoxDH.getSelectedItem();
					
					Receita r = new Receita (codR, med, doseD, tempoT, cpfVet, cpfCli, codA, dh);
					ConsultaRegistra cr = crdao.verificaCR(cpfVet, cpfCli, codA, dh);
					boolean v = r.verificaData(dh);
					if(v == false) {
						JOptionPane.showMessageDialog(null, "Digite a data e hora na seguinte formata��o: aaaa-MM-dd hh:mm:ss", "Data e hora inv�lidos", JOptionPane.ERROR_MESSAGE, null);
						
					}
					else {
						if( cr != null) {
										 
							Receita r2 = rdao.verificaReceita(codR);
							if(r2 != null) {
								JOptionPane.showMessageDialog(null, "J� existe uma receita cadastrada com esse c�digo", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
							}else {
								rdao.inserir(r);
								JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
								
							}
							
						}else {
							
							JOptionPane.showMessageDialog(null, "Combina��o de dados n�o encontrada", "Erro de combina��o de dados", JOptionPane.WARNING_MESSAGE);
						}
						tfCodR.setText("");
						tfMedicamento.setText("");
						tfDD.setText("");
						tfTT.setText("");
					}
				
				}
			}
			
			
		});
		btnNewButton.setBounds(179, 162, 89, 23);
		contentPane.add(btnNewButton);
		centralizarComponente();
	}

}
