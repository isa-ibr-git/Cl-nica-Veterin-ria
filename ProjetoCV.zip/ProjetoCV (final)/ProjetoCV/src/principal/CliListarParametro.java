package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.ClienteDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CliListarParametro extends JFrame {

	private JPanel contentPane;
	private JTable table;
	ClienteDAO cdao = new ClienteDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CliListarParametro frame = new CliListarParametro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public CliListarParametro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CliListarParametro.class.getResource("/img/listar.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 625, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Informe o CPF para a listagem pelo par\u00E2metro:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 34, 241, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(282, 30, 121, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBox.addItem(linha.get(j));
		
		}
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getItemCount() == 0  ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpf =  (String) comboBox.getSelectedItem();
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				boolean achou = false;
				int i;
				if(cdao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", ""});
				}else {
					for( i = 0; i < cdao.getLista().size(); i++) {
						if(cdao.getLista().get(i).getCPF().equals(cpf)) {
							model.addRow(new Object[] { cdao.getLista().get(i).getNome(), cdao.getLista().get(i).getCPF(), cdao.getLista().get(i).getRG(), cdao.getLista().get(i).getEmail(),
									cdao.getLista().get(i).getCep(), cdao.getLista().get(i).getNumero(), cdao.getLista().get(i).getLogradouro(), cdao.getLista().get(i).getCidade(), cdao.getLista().get(i).getBairro(), 
									cdao.getLista().get(i).getEstado(), cdao.getLista().get(i).getPais()});
							achou = true;
							break;
							
						}
					}
				}
				}
				
			}
		});
		btnNewButton.setBounds(467, 11, 89, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 79, 584, 166);
		contentPane.add(scrollPane);
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "CPF", "RG", "E-mail", "CEP", "N\u00FAmero", "Log", "Cidade", "Bairro", "Estado", "Pa\u00EDs"
			}
		));
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(467, 45, 89, 23);
		contentPane.add(btnNewButton_1);
		
		centralizarComponente();
	}

}
