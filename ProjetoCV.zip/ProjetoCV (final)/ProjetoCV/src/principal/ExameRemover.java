package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.ConsultaRegistra;
import bean.Exame;
import dao.ConsultaRegistraDAO;
import dao.ExameDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExameRemover extends JFrame {

	private JPanel contentPane;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();
	ExameDAO exdao = new ExameDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExameRemover frame = new ExameRemover();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public ExameRemover() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ExameRemover.class.getResource("/img/rmv (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Indique os dados para remo\u00E7\u00E3o:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 22, 243, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCdigoExame = new JLabel("C\u00F3digo Exame:");
		lblCdigoExame.setForeground(Color.WHITE);
		lblCdigoExame.setBounds(10, 53, 81, 14);
		contentPane.add(lblCdigoExame);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setBounds(10, 78, 81, 14);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(10, 106, 81, 14);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setBounds(10, 134, 81, 14);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setBounds(10, 159, 81, 14);
		contentPane.add(lblDataEHora);
		
		JComboBox comboBoxEx = new JComboBox();
		comboBoxEx.setBounds(120, 47, 100, 22);
		ArrayList <String> linha5 = new ArrayList();
		
		for(int i = 0; i < exdao.getLista().size(); i++) {
			linha5.add(exdao.getLista().get(i).getCodigo_exame());
		}
		
		for(int j = 0; j<linha5.size(); j++) {
			comboBoxEx.addItem(linha5.get(j));
		}
		contentPane.add(comboBoxEx);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(120, 74, 100, 22);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCpfVet.getModel();
			String palavra = crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCpfVet.addItem(crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase());
			}
		}
		contentPane.add(comboBoxCpfVet);
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(120, 102, 100, 22);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCpfCli.getModel();
			String palavra = crdao.getLista().get(i).getCPF_Cliente().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCpfCli.addItem(crdao.getLista().get(i).getCPF_Cliente().toLowerCase());
			}
			
		}
		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(120, 126, 100, 22);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCodA.getModel();
			String palavra = crdao.getLista().get(i).getCodigo_animal().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCodA.addItem(crdao.getLista().get(i).getCodigo_animal().toLowerCase());
			}
			
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(120, 151, 100, 22);
		ArrayList <String> linha4 = new ArrayList();
		
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0; j<linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
		contentPane.add(comboBoxDH);
		
		JButton btnNewButton = new JButton("Remover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(	comboBoxEx.getItemCount() == 0 ||	comboBoxCpfVet.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0  ){
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String ex = (String) comboBoxEx.getSelectedItem();
				String cpfVet = (String) comboBoxCpfVet.getSelectedItem();
				String cpfCli = (String) comboBoxCpfCli.getSelectedItem();
				String codA = (String) comboBoxCodA.getSelectedItem();
				String dh = (String) comboBoxDH.getSelectedItem();
				
				boolean achou = false;
				boolean achou2 = false;
				boolean achou3 = false;
				boolean achou4 = false;
				boolean achou5 = true;
				int i;
				int j;
				int k;
				int l;
				int m;
				
				for(i=0;i<crdao.getLista().size();i++) {
					if(crdao.getLista().get(i).getCPF_Veterinairo().equals(cpfVet)) {
						achou = true;
						break;
					}
				}
				for(j=0;j<crdao.getLista().size();j++) {
					if(crdao.getLista().get(j).getCPF_Cliente().equals(cpfCli)) {
						achou2 = true;
						break;
					}
				}
				
				for(k=0; k < crdao.getLista().size(); k++) {
					if(crdao.getLista().get(k).getCodigo_animal().equals(codA)) {
						achou3 = true;
						break;
					}
				}
				
				for(l=0;l<crdao.getLista().size(); l++) {
					if(crdao.getLista().get(l).getData_hora().equals(dh)) {
						achou4 = true;
						break;
					}
				}
				
				for(m=0; m < exdao.getLista().size(); m++) {
					if(exdao.getLista().get(m).getCodigo_exame().equals(ex)) {
						achou5 = true;
						break;
					}
				}
				
				Exame ex2 = new Exame(exdao.getLista().get(m).getCodigo_exame() ,crdao.getLista().get(i).getCPF_Veterinairo(), crdao.getLista().get(j).getCPF_Cliente(), crdao.getLista().get(k).getCodigo_animal(), crdao.getLista().get(l).getData_hora());
				int removeu = exdao.remover(ex2);
				if(removeu > 0) {
					JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
					comboBoxEx.removeItem(ex);
					
				}else {
					JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
					}
			
				
				}
			}
		});
		btnNewButton.setBounds(82, 195, 89, 23);
		contentPane.add(btnNewButton);
		centralizarComponente();
	}

}
