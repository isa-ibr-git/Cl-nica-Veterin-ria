package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Veterinario;
import dao.VeterinarioDAO;

import java.awt.Color;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VetAlterar extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfRg;
	private JTextField tfCrv;
	private JTextField tfSalario;
	private JTextField tfDataNas;
	private JTextField tfNumCartao;
	private JTextField tfCep;
	private JTextField tfCidade;
	private JTextField tfBairro;
	private JTextField tfPais;
	private JTextField tfNumero;
	private JTextField tfLog;
	private JTextField tfInstituicao;
	private JTextField tfDataConclusao;
	
	VeterinarioDAO vdao = new VeterinarioDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VetAlterar frame = new VetAlterar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	
	public VetAlterar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VetAlterar.class.getResource("/img/lapis (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBoxCPF = new JComboBox();
		comboBoxCPF.setBounds(221, 17, 126, 22);
		contentPane.add(comboBoxCPF);
		
		VeterinarioDAO vdao = new VeterinarioDAO();
		ArrayList <String > linha = new ArrayList<>();
	
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCPF.addItem(linha.get(j));
		
		}
		
		JLabel lblNewLabel = new JLabel("Selecione o CPF para altera\u00E7\u00E3o:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 11, 353, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Novo Nome:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 62, 78, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Novo RG:");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setBounds(10, 87, 78, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Novo CRV:");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setBounds(10, 112, 78, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_4 = new JLabel("Novo sal\u00E1rio:");
		lblNewLabel_1_4.setForeground(Color.WHITE);
		lblNewLabel_1_4.setBounds(10, 137, 78, 14);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Nova data");
		lblNewLabel_1_5.setForeground(Color.WHITE);
		lblNewLabel_1_5.setBounds(10, 162, 78, 14);
		contentPane.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Novo n\u00FAmero");
		lblNewLabel_1_6.setForeground(Color.WHITE);
		lblNewLabel_1_6.setBounds(10, 187, 78, 14);
		contentPane.add(lblNewLabel_1_6);
		
		tfNome = new JTextField();
		tfNome.setColumns(10);
		tfNome.setBounds(78, 59, 62, 20);
		contentPane.add(tfNome);
		
		tfRg = new JTextField();
		tfRg.setColumns(10);
		tfRg.setBounds(78, 84, 62, 20);
		contentPane.add(tfRg);
		
		tfCrv = new JTextField();
		tfCrv.setColumns(10);
		tfCrv.setBounds(78, 109, 62, 20);
		contentPane.add(tfCrv);
		
		tfSalario = new JTextField();
		tfSalario.setColumns(10);
		tfSalario.setBounds(78, 134, 62, 20);
		contentPane.add(tfSalario);
		
		tfDataNas = new JTextField();
		tfDataNas.setColumns(10);
		tfDataNas.setBounds(78, 159, 62, 20);
		contentPane.add(tfDataNas);
		
		tfNumCartao = new JTextField();
		tfNumCartao.setColumns(10);
		tfNumCartao.setBounds(78, 184, 62, 20);
		contentPane.add(tfNumCartao);
		
		JLabel lblNewLabel_1_5_1 = new JLabel("de nascimento:");
		lblNewLabel_1_5_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblNewLabel_1_5_1.setForeground(Color.WHITE);
		lblNewLabel_1_5_1.setBounds(10, 165, 78, 22);
		contentPane.add(lblNewLabel_1_5_1);
		
		JLabel lblNewLabel_1_5_2 = new JLabel("de cart\u00E3o:");
		lblNewLabel_1_5_2.setForeground(Color.WHITE);
		lblNewLabel_1_5_2.setBounds(10, 201, 78, 14);
		contentPane.add(lblNewLabel_1_5_2);
		
		JLabel lblNewLabel_1_7 = new JLabel("Novo CEP:");
		lblNewLabel_1_7.setForeground(Color.WHITE);
		lblNewLabel_1_7.setBounds(150, 62, 78, 14);
		contentPane.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Novo N\u00FAmero:");
		lblNewLabel_1_8.setForeground(Color.WHITE);
		lblNewLabel_1_8.setBounds(150, 87, 69, 14);
		contentPane.add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("Novo Logradouro:");
		lblNewLabel_1_9.setForeground(Color.WHITE);
		lblNewLabel_1_9.setBounds(150, 112, 93, 14);
		contentPane.add(lblNewLabel_1_9);
		
		JLabel lblNewLabel_1_10 = new JLabel("Nova Cidade:");
		lblNewLabel_1_10.setForeground(Color.WHITE);
		lblNewLabel_1_10.setBounds(150, 137, 78, 14);
		contentPane.add(lblNewLabel_1_10);
		
		JLabel lblNewLabel_1_11 = new JLabel("Novo Bairro:");
		lblNewLabel_1_11.setForeground(Color.WHITE);
		lblNewLabel_1_11.setBounds(150, 162, 78, 14);
		contentPane.add(lblNewLabel_1_11);
		
		JLabel lblNewLabel_1_12 = new JLabel("Novo Estado:");
		lblNewLabel_1_12.setForeground(Color.WHITE);
		lblNewLabel_1_12.setBounds(150, 187, 78, 14);
		contentPane.add(lblNewLabel_1_12);
		
		JLabel lblNewLabel_1_13 = new JLabel("Novo Pa\u00EDs:");
		lblNewLabel_1_13.setForeground(Color.WHITE);
		lblNewLabel_1_13.setBounds(150, 214, 78, 14);
		contentPane.add(lblNewLabel_1_13);
		
		JComboBox comboBoxEstado = new JComboBox();
		comboBoxEstado.setBounds(256, 183, 44, 22);
		comboBoxEstado.setModel(new DefaultComboBoxModel(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "ES", "GO", "MA", "MT", "MS",
				"MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", "DF"}));
		contentPane.add(comboBoxEstado);
		
		tfCep = new JTextField();
		tfCep.setColumns(10);
		tfCep.setBounds(246, 60, 62, 20);
		contentPane.add(tfCep);
		
		tfCidade = new JTextField();
		tfCidade.setColumns(10);
		tfCidade.setBounds(246, 134, 62, 20);
		contentPane.add(tfCidade);
		
		tfBairro = new JTextField();
		tfBairro.setColumns(10);
		tfBairro.setBounds(246, 159, 62, 20);
		contentPane.add(tfBairro);
		
		tfPais = new JTextField();
		tfPais.setColumns(10);
		tfPais.setBounds(246, 211, 62, 20);
		contentPane.add(tfPais);
		
		tfNumero = new JTextField();
		tfNumero.setColumns(10);
		tfNumero.setBounds(246, 84, 62, 20);
		contentPane.add(tfNumero);
		
		tfLog = new JTextField();
		tfLog.setColumns(10);
		tfLog.setBounds(246, 109, 62, 20);
		contentPane.add(tfLog);
		
		JLabel lblNewLabel_1_7_1 = new JLabel("Nova");
		lblNewLabel_1_7_1.setForeground(Color.WHITE);
		lblNewLabel_1_7_1.setBounds(318, 58, 78, 22);
		contentPane.add(lblNewLabel_1_7_1);
		
		JLabel lblNewLabel_1_7_2 = new JLabel("Institui\u00E7\u00E3o:");
		lblNewLabel_1_7_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblNewLabel_1_7_2.setForeground(Color.WHITE);
		lblNewLabel_1_7_2.setBounds(318, 62, 78, 36);
		contentPane.add(lblNewLabel_1_7_2);
		
		tfInstituicao = new JTextField();
		tfInstituicao.setColumns(10);
		tfInstituicao.setBounds(372, 59, 62, 20);
		contentPane.add(tfInstituicao);
		
		tfDataConclusao = new JTextField();
		tfDataConclusao.setColumns(10);
		tfDataConclusao.setBounds(372, 91, 62, 22);
		contentPane.add(tfDataConclusao);
		
		JLabel lblNewLabel_1_7_1_1 = new JLabel("Nova data");
		lblNewLabel_1_7_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_7_1_1.setBounds(314, 87, 78, 39);
		contentPane.add(lblNewLabel_1_7_1_1);
		
		JLabel lblNewLabel_1_7_1_2 = new JLabel("de conclus\u00E3o:");
		lblNewLabel_1_7_1_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblNewLabel_1_7_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_7_1_2.setBounds(314, 91, 78, 43);
		contentPane.add(lblNewLabel_1_7_1_2);
		
		JButton btnNewButton_1 = new JButton("Verificar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf =  (String) comboBoxCPF.getSelectedItem();
				VeterinarioDAO vdao2 = new VeterinarioDAO();
				Veterinario v = vdao2.verificaVet(cpf);
				boolean achou = false;
				int i;
				for (i = 0; i < vdao.getLista().size(); i++) {
					if(vdao.getLista().get(i).getCPF_Func().equals(cpf)) {
						achou = true;
						break;
					}
				}
				
				tfNome.setText(vdao.getLista().get(i).getNome());
				tfRg.setText(vdao.getLista().get(i).getRG());
				tfCrv.setText(vdao.getLista().get(i).getCRV());
				tfSalario.setText(String.valueOf(vdao.getLista().get(i).getSalario()));
				tfDataNas.setText(vdao.getLista().get(i).getData_nascimento());
				tfNumCartao.setText(vdao.getLista().get(i).getNro_cartao());
				tfCep.setText(vdao.getLista().get(i).getCEP());
				tfNumero.setText(String.valueOf(vdao.getLista().get(i).getNumero()));
				tfLog.setText(vdao.getLista().get(i).getLogradouro());
				tfCidade.setText(vdao.getLista().get(i).getCidade());
				tfBairro.setText(vdao.getLista().get(i).getBairro());
				tfPais.setText(vdao.getLista().get(i).getPais());
				tfInstituicao.setText(vdao.getLista().get(i).getInstituicao());
				tfDataConclusao.setText(vdao.getLista().get(i).getData_conclusao());
				comboBoxEstado.setSelectedItem(vdao.getLista().get(i).getEstado());
				
				
			}
		});
		btnNewButton_1.setBounds(356, 17, 78, 23);
		contentPane.add(btnNewButton_1);
		
		JButton botaoALterar = new JButton("Alterar");
		botaoALterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if( tfCrv.getText().isEmpty() || tfNumCartao.getText().isEmpty() || tfNome.getText().isEmpty() || tfRg.getText().isEmpty() || tfDataNas.getText().isEmpty() || tfSalario.getText() == null || tfCep.getText().isEmpty() || tfNumero.getText() == null 
						|| tfNome.getText().isEmpty()|| tfCidade.getText().isEmpty() || tfBairro.getText().isEmpty()|| tfPais.getText().isEmpty() || tfInstituicao.getText().isEmpty() || tfDataConclusao.getText().isEmpty()) { 
					
					
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					
				}else {
					String cpf =  (String) comboBoxCPF.getSelectedItem();
					String crv = tfCrv.getText();
					String numC = tfNumCartao.getText();
					String nome = tfNome.getText();
					String rg = tfRg.getText();
					String dataNas = tfDataNas.getText();
					double salario = Double.parseDouble(tfSalario.getText());
					String cep = tfCep.getText();
					int num = Integer.parseInt(tfNumero.getText());
					String log = tfLog.getText();
					String cidade = tfCidade.getText();
					String bairro = tfBairro.getText();
					String estado =  (String) comboBoxEstado.getSelectedItem();
					String pais = tfPais.getText();
					String instituicao = tfInstituicao.getText();
					String dataC = tfDataConclusao.getText();
				
				
					Veterinario v = new Veterinario (cpf, crv, numC, nome, rg, dataNas, salario, cep, num, log, cidade, bairro, estado, pais, instituicao, dataC);			 
					int alterar = vdao.alterar(v);
					if(alterar > 0) {
						JOptionPane.showMessageDialog(null, "Alterado com sucesso!", "Altera��o realizada", JOptionPane.NO_OPTION);
					}else {
						JOptionPane.showMessageDialog(null, "Houve algum erro na altera��o", "Erro ao tentar alterar", JOptionPane.ERROR_MESSAGE);
					}
						
					}
					
					
					tfCrv.setText("");
					tfNumCartao.setText("");
					tfNome.setText("");
					tfRg.setText("");
					tfDataNas.setText("");
					tfSalario.setText("");
					tfCep.setText("");
					tfNumero.setText("");
					tfLog.setText("");
					tfCidade.setText("");
					tfBairro.setText("");
					tfPais.setText("");
					tfInstituicao.setText("");
					tfDataConclusao.setText("");
					
				
				}
			
				
			
		});
		botaoALterar.setBounds(324, 133, 89, 23);
		contentPane.add(botaoALterar);

		
		
		
				
	
		
	}
}
