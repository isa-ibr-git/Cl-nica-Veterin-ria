package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Cliente;
import dao.ClienteDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class CliRemover extends JFrame {

	private JPanel contentPane;
	ClienteDAO cdao = new ClienteDAO();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CliRemover frame = new CliRemover();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public CliRemover() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CliRemover.class.getResource("/img/rmv (1).png")));
		centralizarComponente();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Indique o CPF do cliente para remo\u00E7\u00E3o:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 18, 258, 18);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(271, 18, 153, 22);
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Remover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getItemCount() == 0  ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpf =  (String) comboBox.getSelectedItem();
				boolean achou = false;
				int i;
				for(i=0;i<cdao.getLista().size(); i++) {
					if(cdao.getLista().get(i).getCPF().equals(cpf)){
						achou = true;
						break;
						
					}
				}
				
				Cliente c = new Cliente(cdao.getLista().get(i).getCPF(), cdao.getLista().get(i).getRG(), cdao.getLista().get(i).getNome(), cdao.getLista().get(i).getEmail(), cdao.getLista().get(i).getCep(), cdao.getLista().get(i).getNumero(), cdao.getLista().get(i).getLogradouro(), cdao.getLista().get(i).getCidade(), cdao.getLista().get(i).getBairro(),
						cdao.getLista().get(i).getEstado(), cdao.getLista().get(i).getPais());
				
				int removeu = cdao.remover(c);
				if(removeu > 0) {
					JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
					comboBox.removeItem(cpf);
				}else {
					JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
				}
			}
			}
			
			
		});
		btnNewButton.setBounds(167, 77, 89, 23);
		contentPane.add(btnNewButton);
		
		ArrayList <String > linha = new ArrayList<>();
	
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBox.addItem(linha.get(j));
		}
		
		centralizarComponente();
		
	
	}

}
