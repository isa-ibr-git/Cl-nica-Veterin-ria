package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Cliente;
import bean.Veterinario;
import dao.ClienteDAO;
import dao.VeterinarioDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CliAlterar extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfRg;
	private JTextField tfEmail;
	private JTextField tfCep;
	private JTextField tfNum;
	private JTextField tfLog;
	private JTextField tfCidade;
	private JTextField tfBairro;
	private JTextField tfPais;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CliAlterar frame = new CliAlterar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	/**
	 * Create the frame.
	 */
	public CliAlterar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CliAlterar.class.getResource("/img/lapis (1).png")));
		ClienteDAO cdao = new ClienteDAO();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Selecione o CPF para altera\u00E7\u00E3o:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 11, 214, 30);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBoxCPF = new JComboBox();
		comboBoxCPF.setBounds(228, 17, 113, 22);
		contentPane.add(comboBoxCPF);
		ArrayList <String > linha = new ArrayList<>();
	
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCPF.addItem(linha.get(j));
		
		}
		JComboBox comboBoxEstado = new JComboBox();
		comboBoxEstado.setBounds(296, 126, 60, 22);
		comboBoxEstado.setModel(new DefaultComboBoxModel(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "ES", "GO", "MA", "MT", "MS",
				"MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", "DF"}));
		contentPane.add(comboBoxEstado);
		
		JButton btnNewButton = new JButton("Verificar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCPF.getItemCount() == 0  ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpf =  (String) comboBoxCPF.getSelectedItem();
				ClienteDAO cdao2 = new ClienteDAO();
				Cliente c = cdao2.verificaCliente(cpf);
				boolean achou = false;
				int i;
				for (i = 0; i < cdao.getLista().size(); i++) {
					if(cdao.getLista().get(i).getCPF().equals(cpf)) {
						achou = true;
						break;
					}
				}
			
				tfNome.setText(cdao.getLista().get(i).getNome());
				tfRg.setText(cdao.getLista().get(i).getRG());
				tfEmail.setText(cdao.getLista().get(i).getEmail());
				tfCep.setText(cdao.getLista().get(i).getCep());
				tfNum.setText(String.valueOf(cdao.getLista().get(i).getNumero()));
				tfLog.setText(cdao.getLista().get(i).getLogradouro());
				tfCidade.setText(cdao.getLista().get(i).getCidade());
				tfBairro.setText(cdao.getLista().get(i).getBairro());
				tfPais.setText(cdao.getLista().get(i).getPais());
				comboBoxEstado.setSelectedItem(cdao.getLista().get(i).getEstado());
				
			}
			}
		});
		btnNewButton.setBounds(345, 17, 86, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Novo Nome:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 52, 78, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Novo RG:");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setBounds(10, 80, 78, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Novo E-mail:");
		lblNewLabel_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_3.setBounds(10, 105, 78, 14);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Novo CEP:");
		lblNewLabel_1_4.setForeground(Color.WHITE);
		lblNewLabel_1_4.setBounds(10, 130, 78, 14);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Novo N\u00FAmero:");
		lblNewLabel_1_5.setForeground(Color.WHITE);
		lblNewLabel_1_5.setBounds(10, 158, 104, 14);
		contentPane.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Novo Logradouro:");
		lblNewLabel_1_6.setForeground(Color.WHITE);
		lblNewLabel_1_6.setBounds(182, 55, 122, 14);
		contentPane.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Nova Cidade:");
		lblNewLabel_1_7.setForeground(Color.WHITE);
		lblNewLabel_1_7.setBounds(182, 80, 78, 14);
		contentPane.add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Novo Bairro:");
		lblNewLabel_1_8.setForeground(Color.WHITE);
		lblNewLabel_1_8.setBounds(182, 105, 78, 14);
		contentPane.add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_9 = new JLabel("Novo Estado:");
		lblNewLabel_1_9.setForeground(Color.WHITE);
		lblNewLabel_1_9.setBounds(182, 130, 78, 14);
		contentPane.add(lblNewLabel_1_9);
		
		JLabel lblNewLabel_1_10 = new JLabel("Novo Pa\u00EDs:");
		lblNewLabel_1_10.setForeground(Color.WHITE);
		lblNewLabel_1_10.setBounds(182, 158, 78, 14);
		contentPane.add(lblNewLabel_1_10);
		
		tfNome = new JTextField();
		tfNome.setBounds(86, 52, 86, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);
		
		tfRg = new JTextField();
		tfRg.setColumns(10);
		tfRg.setBounds(86, 77, 86, 20);
		contentPane.add(tfRg);
		
		tfEmail = new JTextField();
		tfEmail.setColumns(10);
		tfEmail.setBounds(86, 105, 86, 20);
		contentPane.add(tfEmail);
		
		tfCep = new JTextField();
		tfCep.setColumns(10);
		tfCep.setBounds(86, 130, 86, 20);
		contentPane.add(tfCep);
		
		tfNum = new JTextField();
		tfNum.setColumns(10);
		tfNum.setBounds(86, 155, 86, 20);
		contentPane.add(tfNum);
		
		tfLog = new JTextField();
		tfLog.setColumns(10);
		tfLog.setBounds(286, 55, 86, 20);
		contentPane.add(tfLog);
		
		tfCidade = new JTextField();
		tfCidade.setColumns(10);
		tfCidade.setBounds(286, 77, 86, 20);
		contentPane.add(tfCidade);
		
		tfBairro = new JTextField();
		tfBairro.setColumns(10);
		tfBairro.setBounds(286, 102, 86, 20);
		contentPane.add(tfBairro);
		
		tfPais = new JTextField();
		tfPais.setColumns(10);
		tfPais.setBounds(286, 159, 86, 20);
		contentPane.add(tfPais);
		
		JButton btnNewButton_1 = new JButton("Alterar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if( tfNome.getText().isEmpty() || tfRg.getText().isEmpty() || tfEmail.getText().isEmpty() || tfCep.getText().isEmpty()
						|| tfNum.getText() == null || tfLog.getText().isEmpty() || tfCidade.getText().isEmpty() || tfBairro.getText().isEmpty()|| tfPais.getText().isEmpty() || comboBoxCPF.getItemCount() == 0) { 
					
					
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					
				}else {
					String cpf =  (String) comboBoxCPF.getSelectedItem();
					String rg = tfRg.getText();
					String nome = tfNome.getText();
					String email = tfEmail.getText();
					String cep = tfCep.getText();
					int num = Integer.parseInt(tfNum.getText());
					String log = tfLog.getText();
					String cidade = tfCidade.getText();
					String bairro = tfBairro.getText();
					String estado =  (String) comboBoxEstado.getSelectedItem();
					String pais = tfPais.getText();
					
				
				
					Cliente c = new Cliente (cpf, rg, nome,email, cep, num, log, cidade, bairro, estado, pais);			 
					int alterar = cdao.alterar(c);
					if(alterar > 0) {
						JOptionPane.showMessageDialog(null, "Alterado com sucesso!", "Altera��o realizada", JOptionPane.NO_OPTION);
					}else {
						JOptionPane.showMessageDialog(null, "Houve algum erro na altera��o", "Erro ao tentar alterar", JOptionPane.ERROR_MESSAGE);
					}
						
					}
					
					
					tfNome.setText("");
					tfRg.setText("");
					tfEmail.setText("");
					tfCep.setText("");
					tfNum.setText("");
					tfLog.setText("");
					tfCidade.setText("");
					tfBairro.setText("");
					tfPais.setText("");
				
					
				
				}
			
		
		});
		btnNewButton_1.setBounds(171, 204, 89, 23);
		contentPane.add(btnNewButton_1);
		
		
		centralizarComponente();
	}

}
