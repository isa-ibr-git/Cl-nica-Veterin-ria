package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.AnimalDAO;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AnimalListar extends JFrame {

	private JPanel contentPane;
	private JTable table;
	AnimalDAO adao = new AnimalDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimalListar frame = new AnimalListar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public AnimalListar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AnimalListar.class.getResource("/img/listar.png")));
		
		
	
		centralizarComponente();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 625, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Listar Animais");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(adao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					model.addRow(new Object[] {"", "", "", "", "", "",""});
				}else {
				for(int i = 0; i<adao.getLista().size(); i++) {
					model.addRow(new Object[] {adao.getLista().get(i).getCPF_Cli(), adao.getLista().get(i).getCodigo(), adao.getLista().get(i).getNome()
							, adao.getLista().get(i).getRaca(), adao.getLista().get(i).getData_nas(), adao.getLista().get(i).getEspecie(), adao.getLista().get(i).getPorte()});
				}
				}
			}
		});
		
		btnNewButton.setBounds(10, 29, 140, 23);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 64, 589, 173);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Cliente", "C\u00F3digo", "Nome", "Ra\u00E7a", "Data de N", "Esp\u00E9cie", "Porte"
			}
		));
		
		JButton btnNewButton_1 = new JButton("Limpar lista");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(459, 29, 140, 23);
		contentPane.add(btnNewButton_1);
	
	}
}
