package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Animal;
import bean.Exame;
import dao.ConsultaRegistraDAO;
import dao.ExameDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExameAdicionar extends JFrame {

	private JPanel contentPane;
	private JTextField tfCodEx;
	ConsultaRegistraDAO crdao = new ConsultaRegistraDAO();
	ExameDAO exdao = new ExameDAO();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExameAdicionar frame = new ExameAdicionar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}
	
	

	/**
	 * Create the frame.
	 */
	public ExameAdicionar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ExameAdicionar.class.getResource("/img/adicao (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("C\u00F3digo do exame:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(34, 55, 110, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCpfVeterinrio = new JLabel("CPF Veterin\u00E1rio:");
		lblCpfVeterinrio.setForeground(Color.WHITE);
		lblCpfVeterinrio.setBounds(34, 84, 110, 14);
		contentPane.add(lblCpfVeterinrio);
		
		JLabel lblCpfCliente = new JLabel("CPF Cliente:");
		lblCpfCliente.setForeground(Color.WHITE);
		lblCpfCliente.setBounds(34, 109, 110, 14);
		contentPane.add(lblCpfCliente);
		
		JLabel lblCdigoAnimal = new JLabel("C\u00F3digo Animal:");
		lblCdigoAnimal.setForeground(Color.WHITE);
		lblCdigoAnimal.setBounds(34, 134, 110, 14);
		contentPane.add(lblCdigoAnimal);
		
		JLabel lblDataEHora = new JLabel("Data e hora:");
		lblDataEHora.setForeground(Color.WHITE);
		lblDataEHora.setBounds(34, 159, 110, 14);
		contentPane.add(lblDataEHora);
		
		tfCodEx = new JTextField();
		tfCodEx.setBounds(145, 52, 86, 20);
		contentPane.add(tfCodEx);
		tfCodEx.setColumns(10);
		
		JComboBox comboBoxCpfVet = new JComboBox();
		comboBoxCpfVet.setBounds(145, 80, 86, 22);
		
		JComboBox comboBoxCpfVet2 = new JComboBox();
		comboBoxCpfVet2.setBounds(145, 80, 86, 22);
		contentPane.add(comboBoxCpfVet2);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCpfVet2.getModel();
			String palavra = crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCpfVet2.addItem(crdao.getLista().get(i).getCPF_Veterinairo().toLowerCase());
			}
			
		}
		
		JComboBox comboBoxCpfCli = new JComboBox();
		comboBoxCpfCli.setBounds(145, 105, 86, 22);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCpfCli.getModel();
			String palavra = crdao.getLista().get(i).getCPF_Cliente().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCpfCli.addItem(crdao.getLista().get(i).getCPF_Cliente().toLowerCase());
			}
			
		}

		contentPane.add(comboBoxCpfCli);
		
		JComboBox comboBoxCodA = new JComboBox();
		comboBoxCodA.setBounds(145, 130, 86, 22);
		for(int i = 0; i<crdao.getLista().size(); i++) {
			boolean achou = true;
			 DefaultComboBoxModel model = (DefaultComboBoxModel) comboBoxCodA.getModel();
			String palavra = crdao.getLista().get(i).getCodigo_animal().toLowerCase();
			int a = model.getIndexOf(palavra);
			if(a != -1) {
				achou = false;
				
			
			}else {
				
				comboBoxCodA.addItem(crdao.getLista().get(i).getCodigo_animal().toLowerCase());
			}
			
		}
		contentPane.add(comboBoxCodA);
		
		JComboBox comboBoxDH = new JComboBox();
		comboBoxDH.setBounds(145, 155, 86, 22);
		ArrayList <String> linha4 = new ArrayList();
		
		for(int i = 0; i < crdao.getLista().size(); i++) {
			linha4.add(crdao.getLista().get(i).getData_hora());
		}
		
		for(int j = 0; j<linha4.size(); j++) {
			comboBoxDH.addItem(linha4.get(j));
		}
		contentPane.add(comboBoxDH);
		
		JButton btnNewButton = new JButton("Inserir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfCodEx.getText().isEmpty() || comboBoxCpfVet2.getItemCount() == 0 || comboBoxCpfCli.getItemCount() == 0 || comboBoxCodA.getItemCount() == 0 || comboBoxDH.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String codEx = tfCodEx.getText();
				String cpfVet = (String) comboBoxCpfVet2.getSelectedItem();
				String cpfCli = (String) comboBoxCpfCli.getSelectedItem();
				String codA = (String) comboBoxCodA.getSelectedItem();
				String dh = (String) comboBoxDH.getSelectedItem();
				
				Exame ex = new Exame(codEx, cpfVet, cpfCli, codA, dh);
				
				Exame ex2 = exdao.verificaEx(codEx, cpfVet, cpfCli, codA, dh);
				
				boolean v = ex.verificaData(dh);
				if(v == false) {
					JOptionPane.showMessageDialog(null, "Digite a data e hora na seguinte formata��o: aaaa-MM-dd hh:mm:ss", "Data e hora inv�lidos", JOptionPane.ERROR_MESSAGE, null);
					
				}
				else {
					if(ex2 != null) {
						JOptionPane.showMessageDialog(null, "J� existe um Exame cadastrado com esses dados", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
					}else {
						boolean achou = false;
						for(int i = 0; i < crdao.getLista().size(); i++) {
							if(ex.getCPF_Veterinario().equals(crdao.getLista().get(i).getCPF_Veterinairo()) && ex.getCPF_Cliente().equals(crdao.getLista().get(i).getCPF_Cliente()) &&
									ex.getCodigo_animal().equals(crdao.getLista().get(i).getCodigo_animal()) && ex.getData_hora().equals(crdao.getLista().get(i).getData_hora())) {
								achou = true;
								break;
						}
						}
							if(achou) {
								exdao.inserir(ex);
							JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
							}else {
								JOptionPane.showMessageDialog(null, "N�o existe nenhum registro de consulta cadastrado com esses dados para gerar um exame", "Aus�ncia de registro com os dados", JOptionPane.ERROR_MESSAGE, null);
							}
					
					
					tfCodEx.setText("");
					}
				}
			}
			}
		});
		btnNewButton.setBounds(89, 202, 89, 23);
		contentPane.add(btnNewButton);
		
		
		//primary key(codigo_exame, CPF_Veterina, CPF_Cliente, codigo_do_Animal, data_hora),
		centralizarComponente();
	}
}
