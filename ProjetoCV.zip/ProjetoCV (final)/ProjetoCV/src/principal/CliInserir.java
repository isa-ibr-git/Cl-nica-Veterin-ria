package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Cliente;
import bean.Veterinario;
import dao.ClienteDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;

public class CliInserir extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfCpf;
	private JTextField tfRg;
	private JTextField tfEmail;
	private JTextField tfCep;
	private JTextField tfNum;
	private JTextField tfLog;
	private JTextField tfCidade;
	private JTextField tfBairro;
	private JTextField tfPais;
	
	ClienteDAO cdao = new ClienteDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CliInserir frame = new CliInserir();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	
	/**
	 * Create the frame.
	 */
	public CliInserir() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CliInserir.class.getResource("/img/adicao (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		centralizarComponente();
		
		JLabel lblNewLabel = new JLabel("Nome\r\n:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 45, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setForeground(Color.WHITE);
		lblCpf.setBounds(10, 70, 46, 14);
		contentPane.add(lblCpf);
		
		JLabel lblRg = new JLabel("RG:");
		lblRg.setForeground(Color.WHITE);
		lblRg.setBounds(10, 95, 46, 14);
		contentPane.add(lblRg);
		
		JLabel lblCep = new JLabel("E-mail:");
		lblCep.setForeground(Color.WHITE);
		lblCep.setBounds(10, 120, 46, 14);
		contentPane.add(lblCep);
		
		JLabel lblCep_1 = new JLabel("CEP:");
		lblCep_1.setForeground(Color.WHITE);
		lblCep_1.setBounds(10, 142, 46, 14);
		contentPane.add(lblCep_1);
		
		JLabel lblNmero = new JLabel("N\u00FAmero:");
		lblNmero.setForeground(Color.WHITE);
		lblNmero.setBounds(161, 45, 66, 14);
		contentPane.add(lblNmero);
		
		JLabel lblLogradouro = new JLabel("Logradouro:");
		lblLogradouro.setForeground(Color.WHITE);
		lblLogradouro.setBounds(161, 70, 86, 14);
		contentPane.add(lblLogradouro);
		
		JLabel lblCidade = new JLabel("Cidade:");
		lblCidade.setForeground(Color.WHITE);
		lblCidade.setBounds(161, 95, 46, 14);
		contentPane.add(lblCidade);
		
		JLabel lblEstado = new JLabel("Estado:");
		lblEstado.setForeground(Color.WHITE);
		lblEstado.setBounds(161, 142, 46, 14);
		contentPane.add(lblEstado);
		
		JLabel lblPas = new JLabel("Pa\u00EDs:");
		lblPas.setForeground(Color.WHITE);
		lblPas.setBounds(161, 167, 46, 14);
		contentPane.add(lblPas);
		
		JLabel lblBairro = new JLabel("Bairro:");
		lblBairro.setForeground(Color.WHITE);
		lblBairro.setBounds(161, 120, 46, 14);
		contentPane.add(lblBairro);
		
		tfNome = new JTextField();
		tfNome.setBounds(65, 42, 86, 20);
		contentPane.add(tfNome);
		tfNome.setColumns(10);
		
		tfCpf = new JTextField();
		tfCpf.setColumns(10);
		tfCpf.setBounds(65, 67, 86, 20);
		contentPane.add(tfCpf);
		
		tfRg = new JTextField();
		tfRg.setColumns(10);
		tfRg.setBounds(65, 92, 86, 20);
		contentPane.add(tfRg);
		
		tfEmail = new JTextField();
		tfEmail.setColumns(10);
		tfEmail.setBounds(65, 117, 86, 20);
		contentPane.add(tfEmail);
		
		tfCep = new JTextField();
		tfCep.setColumns(10);
		tfCep.setBounds(66, 142, 86, 20);
		contentPane.add(tfCep);
		
		tfNum = new JTextField();
		tfNum.setColumns(10);
		tfNum.setBounds(237, 42, 86, 20);
		contentPane.add(tfNum);
		
		tfLog = new JTextField();
		tfLog.setColumns(10);
		tfLog.setBounds(237, 67, 86, 20);
		contentPane.add(tfLog);
		
		tfCidade = new JTextField();
		tfCidade.setColumns(10);
		tfCidade.setBounds(237, 92, 86, 20);
		contentPane.add(tfCidade);
		
		tfBairro = new JTextField();
		tfBairro.setColumns(10);
		tfBairro.setBounds(237, 117, 86, 20);
		contentPane.add(tfBairro);
		
		tfPais = new JTextField();
		tfPais.setColumns(10);
		tfPais.setBounds(237, 164, 86, 20);
		contentPane.add(tfPais);
		
		JComboBox comboBoxEstado = new JComboBox();
		comboBoxEstado.setBounds(247, 138, 66, 22);
		comboBoxEstado.setModel(new DefaultComboBoxModel(new String[] {"AC", "AL", "AP", "AM", "BA", "CE", "ES", "GO", "MA", "MT", "MS",
				"MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", "DF"}));
		contentPane.add(comboBoxEstado);
		
		JButton btnNewButton = new JButton("Enviar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfNome.getText().isEmpty() || tfRg.getText().isEmpty() || tfCpf.getText().isEmpty() || tfCep.getText().isEmpty() || tfNum.getText() == null 
					|| tfCidade.getText().isEmpty() || tfBairro.getText().isEmpty()|| tfPais.getText().isEmpty()) { 
					
					
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
					
				}else {
					String cpf =  tfCpf.getText();
					String nome = tfNome.getText();
					String rg = tfRg.getText();
					String email = tfEmail.getText();
					String cep = tfCep.getText();
					int num = Integer.parseInt(tfNum.getText());
					String log = tfLog.getText();
					String cidade = tfCidade.getText();
					String bairro = tfBairro.getText();
					String estado =  (String) comboBoxEstado.getSelectedItem();
					String pais = tfPais.getText();
				
				
					Cliente c = new Cliente (cpf, rg, nome, email, cep, num, log, cidade, bairro, estado, pais);			 
					Cliente c2 = cdao.verificaCliente(cpf);
					if(c2 != null) {
						JOptionPane.showMessageDialog(null, "J� existe um Cliente cadastrado esse CPF", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
					}else {
						cdao.inserir(c);
						JOptionPane.showMessageDialog(null, "Inserido com sucesso!", "Cadastro realizado", JOptionPane.NO_OPTION);
					}
					
					tfCpf.setText("");
					tfNome.setText("");
					tfRg.setText("");
					tfCep.setText("");
					tfNum.setText("");
					tfLog.setText("");
					tfCidade.setText("");
					tfBairro.setText("");
					tfPais.setText("");
					tfEmail.setText("");
				
				}
			}
			
		});
		btnNewButton.setBounds(171, 209, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(CliInserir.class.getResource("/img/clients (1).png")));
		lblNewLabel_1.setBounds(333, 11, 121, 83);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblInseroCliente = new JLabel("Inser\u00E7\u00E3o - Cliente");
		lblInseroCliente.setForeground(Color.WHITE);
		lblInseroCliente.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblInseroCliente.setBounds(145, 11, 189, 19);
		contentPane.add(lblInseroCliente);
		
	}
}
