package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Animal;
import bean.Cliente;
import dao.AnimalDAO;
import dao.ClienteDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class AnimalRemover extends JFrame {

	private JPanel contentPane;
	ClienteDAO cdao = new ClienteDAO();
	AnimalDAO adao = new AnimalDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AnimalRemover frame = new AnimalRemover();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public AnimalRemover() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(AnimalRemover.class.getResource("/img/rmv (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Indique o CPF do cliente e o c\u00F3digo do animal para remo\u00E7\u00E3o:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(42, 11, 382, 24);
		contentPane.add(lblNewLabel);
		
		JLabel lblCpf = new JLabel("CPF:");
		lblCpf.setForeground(Color.WHITE);
		lblCpf.setBounds(10, 55, 40, 24);
		contentPane.add(lblCpf);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo:");
		lblCdigo.setForeground(Color.WHITE);
		lblCdigo.setBounds(10, 90, 59, 24);
		contentPane.add(lblCdigo);
		
		JComboBox comboBoxCpf = new JComboBox();
		comboBoxCpf.setBounds(66, 56, 104, 22);
		ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCpf.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCpf);
		
		JComboBox comboBoxCod = new JComboBox();
		comboBoxCod.setBounds(66, 91, 104, 22);
		ArrayList <String > linhaC = new ArrayList<>();
		for(int k = 0; k < adao.getLista().size(); k++) {
			linhaC.add(adao.getLista().get(k).getCodigo());
			
		}
		for(int l = 0; l < linhaC.size(); l++ ) {
			comboBoxCod.addItem(linhaC.get(l));
		}
		contentPane.add(comboBoxCod);
		
		JButton btnNewButton = new JButton("Remover");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCpf.getItemCount() == 0 ||  comboBoxCod.getItemCount() == 0 ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpf =  (String) comboBoxCpf.getSelectedItem();
				String cod = (String) comboBoxCod.getSelectedItem();
				
				boolean achou = false;
				boolean achou2 = false;
				boolean achou3 = false;
				int i;
				int j;
				for(i=0;i<cdao.getLista().size(); i++) {
					if(cdao.getLista().get(i).getCPF().equals(cpf)){
						achou = true;
						break;
						
					}
				}
	
				for(j=0; j < adao.getLista().size(); j++) {
					if(adao.getLista().get(j).getCodigo().equals(cod)) {
						achou2 = true;
						break;
					}

				}
				
					Animal a = new Animal(cdao.getLista().get(i).getCPF(), adao.getLista().get(j).getCodigo(), adao.getLista().get(j).getNome(),
					adao.getLista().get(j).getRaca(), adao.getLista().get(j).getData_nas(), adao.getLista().get(j).getEspecie(), adao.getLista().get(j).getPorte());
				

						int removeu = adao.remover(a);
						if(removeu > 0) {
							JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
							comboBoxCod.removeItem(cod);
						}else {
							JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
							}
					}
				
			}
		
		});
		btnNewButton.setBounds(227, 70, 89, 23);
		contentPane.add(btnNewButton);
		centralizarComponente();
	}

}
