package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Veterinario;
import dao.VeterinarioDAO;

import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class VetRemover extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VetRemover frame = new VetRemover();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public VetRemover() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VetRemover.class.getResource("/img/rmv (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(145, 112, 127, 22);
		contentPane.add(comboBox);
	
		VeterinarioDAO vdao = new VeterinarioDAO();
		ArrayList <String > linha = new ArrayList<>();
	
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBox.addItem(linha.get(j));
		}
		
		
		JButton btnNewButton = new JButton("Remover ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getItemCount() == 0  ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf =  (String) comboBox.getSelectedItem();
					boolean achou = false;
					int i;
					for(i=0;i<vdao.getLista().size(); i++) {
						if(vdao.getLista().get(i).getCPF_Func().equals(cpf)){
							achou = true;
							break;
							
						}
					}
					
					Veterinario v = new Veterinario(vdao.getLista().get(i).getCPF_Func(), vdao.getLista().get(i).getCRV(), vdao.getLista().get(i).getNro_cartao(), vdao.getLista().get(i).getNome(), vdao.getLista().get(i).getRG(), vdao.getLista().get(i).getData_nascimento(), vdao.getLista().get(i).getSalario(),
							vdao.getLista().get(i).getCEP(), vdao.getLista().get(i).getNumero(), vdao.getLista().get(i).getLogradouro(), vdao.getLista().get(i).getCidade(), vdao.getLista().get(i).getBairro(),
							vdao.getLista().get(i).getEstado(), vdao.getLista().get(i).getPais(), vdao.getLista().get(i).getInstituicao(), vdao.getLista().get(i).getData_conclusao());
					
					int removeu = vdao.remover(v);
					if(removeu > 0) {
						JOptionPane.showMessageDialog(null, "Removeu com sucesso!", "Remo��o realizada", JOptionPane.NO_OPTION);
						comboBox.removeItem(cpf);
					}else {
						JOptionPane.showMessageDialog(null, "Houve algum erro na remo��o", "Erro de remo��o", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
			
			
		});
		btnNewButton.setBounds(166, 145, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Indique o CPF do veterin\u00E1rio para remo\u00E7\u00E3o:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(75, 72, 316, 29);
		contentPane.add(lblNewLabel);
		
		centralizarComponente();
	}
}
