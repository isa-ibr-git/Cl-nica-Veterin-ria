package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Objects;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.AnimalDAO;
import dao.ClienteDAO;
import dao.ConsultasDAO;
import dao.Tel_cliDAO;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import bean.Animal;
import bean.Tel_cli;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelCliConsulta6 extends JFrame {

	private JPanel contentPane;
	ClienteDAO cdao = new ClienteDAO();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelCliConsulta6 frame = new TelCliConsulta6();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public TelCliConsulta6() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelCliConsulta6.class.getResource("/img/87-872219_lupa-icon (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIndiqueAEspcie = new JLabel("Indique o CPF do cliente para a listagem de telefones:");
		lblIndiqueAEspcie.setForeground(Color.WHITE);
		lblIndiqueAEspcie.setBounds(10, 11, 314, 14);
		contentPane.add(lblIndiqueAEspcie);
		
		JComboBox comboBoxCPF = new JComboBox();
		comboBoxCPF.setBounds(324, 7, 100, 22);
	ArrayList <String > linha = new ArrayList<>();
		
		for(int i=0; i < cdao.getLista().size(); i++) {
			linha.add(cdao.getLista().get(i).getCPF());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBoxCPF.addItem(linha.get(j));
		
		}
		contentPane.add(comboBoxCPF);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(49, 85, 343, 165);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Telefones "
			}
		));
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBoxCPF.getItemCount() == 0) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
				String cpf  = (String) comboBoxCPF.getSelectedItem();
				ConsultasDAO condao = new ConsultasDAO();
				Tel_cliDAO tcdao = new Tel_cliDAO();
				ArrayList<Tel_cli> consulta6 = condao.consulta6(cpf);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				
				if(tcdao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}else {
					
					
					for(int i = 0; i < consulta6.size(); i++) {
						model.addRow(new Object[] {condao.consulta6(cpf).get(i).getTelefone_cli()});
						
				}
				
			}
				}
			}
			
		});
		btnNewButton.setBounds(54, 50, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(293, 50, 89, 23);
		contentPane.add(btnNewButton_1);
		

		centralizarComponente();
	}
}
