package principal;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.VeterinarioDAO;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VetListar extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	
	VeterinarioDAO vdao = new VeterinarioDAO();
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VetListar frame = new VetListar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}

	/**
	 * Create the frame.
	 */
	public VetListar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VetListar.class.getResource("/img/listar.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 625, 301);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 64, 589, 173);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "cpf", "rg", "crv", "S", "D.N", "Nro C", "Cep", "Num", "L", "C", "B", "E", "P", "I", "D.C"
			}
		));
		

		JButton btnNewButton = new JButton("Listar veterin\u00E1rios");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(vdao.getLista().isEmpty()) {
					JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}else {
				
					for(int i = 0; i < vdao.getLista().size(); i++) {
						model.addRow(new Object[] { vdao.getLista().get(i).getNome(), vdao.getLista().get(i).getCPF_Func(), vdao.getLista().get(i).getRG(),
								vdao.getLista().get(i).getCRV(), vdao.getLista().get(i).getSalario(), vdao.getLista().get(i).getData_nascimento(), vdao.getLista().get(i).getNro_cartao(),
								vdao.getLista().get(i).getCEP(), vdao.getLista().get(i).getNumero(), vdao.getLista().get(i).getLogradouro(), vdao.getLista().get(i).getCidade(), vdao.getLista().get(i).getBairro(), 
						vdao.getLista().get(i).getEstado(), vdao.getLista().get(i).getPais(), vdao.getLista().get(i).getInstituicao(),
						vdao.getLista().get(i).getData_conclusao()});
					}
					
				}
				
			}
		});
		btnNewButton.setBounds(123, 25, 132, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Limpar lista");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(362, 25, 132, 23);
		contentPane.add(btnNewButton_1);
		
		centralizarComponente();
		
		
	
	}
}
