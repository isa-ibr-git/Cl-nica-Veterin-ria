package principal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.VeterinarioDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VetListarParametro extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	VeterinarioDAO vdao = new VeterinarioDAO();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VetListarParametro frame = new VetListarParametro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	public void centralizarComponente() { 
		Dimension ds = Toolkit.getDefaultToolkit().getScreenSize(); 
		Dimension dw = getSize(); setLocation((ds.width - dw.width) / 2, (ds.height - dw.height) / 2); 
		}


	/**
	 * Create the frame.
	 */
	public VetListarParametro() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VetListarParametro.class.getResource("/img/checklist_106575 (1).png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 625, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 91, 589, 135);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "cpf", "rg", "crv", "S", "D.N", "Nro C", "Cep", "Num", "L", "C", "B", "E", "P", "I", "D.C"
			}
		));
		
		JLabel lblNewLabel = new JLabel("Informe o CPF para a listagem pelo par\u00E2metro:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 26, 294, 14);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(314, 22, 121, 22);
		
	
		ArrayList <String > linha = new ArrayList<>();
	
		for(int i=0; i < vdao.getLista().size(); i++) {
			linha.add(vdao.getLista().get(i).getCPF_Func());
		}
		
		for(int j=0; j < linha.size(); j++) {
			
		comboBox.addItem(linha.get(j));
		
		}
		contentPane.add(comboBox);
		
		
		
		JButton btnNewButton = new JButton("Listar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getItemCount() == 0  ) {
					JOptionPane.showMessageDialog(null, "Preencha todos os campos", "Campo(s) vazio(s)", JOptionPane.WARNING_MESSAGE, null);
				}else {
					String cpf =  (String) comboBox.getSelectedItem();
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					boolean achou = false;
					int i;
					if(vdao.getLista().isEmpty()) {
						JOptionPane.showMessageDialog(null, "A tabela n�o possui dados", "Tabela vazia", JOptionPane.WARNING_MESSAGE, null);
						model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
					}else {
						for( i = 0; i < vdao.getLista().size(); i++) {
							if(vdao.getLista().get(i).getCPF_Func().equals(cpf)) {
								model.addRow(new Object[] { vdao.getLista().get(i).getNome(), vdao.getLista().get(i).getCPF_Func(), vdao.getLista().get(i).getRG(),
										vdao.getLista().get(i).getCRV(), vdao.getLista().get(i).getSalario(), vdao.getLista().get(i).getData_nascimento(), vdao.getLista().get(i).getNro_cartao(),
										vdao.getLista().get(i).getCEP(), vdao.getLista().get(i).getNumero(), vdao.getLista().get(i).getLogradouro(), vdao.getLista().get(i).getCidade(), vdao.getLista().get(i).getBairro(), 
								vdao.getLista().get(i).getEstado(), vdao.getLista().get(i).getPais(), vdao.getLista().get(i).getInstituicao(),
								vdao.getLista().get(i).getData_conclusao()});
								achou = true;
								break;
								
							}
						}
					}
				}
			}
		});
		btnNewButton.setBounds(472, 22, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(model.getRowCount() <= 0) {
					JOptionPane.showMessageDialog(null, "Sem dados, n�o foram listados ou n�o existem", "Tabela vazia", JOptionPane.WARNING_MESSAGE);
					model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
				}
				if (model.getRowCount() > 0){
		            while(model.getRowCount() >= 0){
		                model.removeRow(0);
		                if(model.getRowCount() == 0) {
		                	model.addRow(new Object[] {"", "", "", "", "", "","", "", "", "", "", "", "", "", "", ""});
		                	model.removeRow(0);
		                	break;
		                }
		            }
				}
			}
		});
		btnNewButton_1.setBounds(472, 55, 89, 23);
		contentPane.add(btnNewButton_1);
		
	
		centralizarComponente();
	}

}
