package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.ConsultaRegistra;

public class ConsultaRegistraDAO {
	private Connection connection;
	ArrayList <ConsultaRegistra> crs = new ArrayList<>(); 
	ArrayList <ConsultaRegistra> crsMostrar = new ArrayList<>(); 
	ArrayList <ConsultaRegistra> crP = new ArrayList<>(); 

	public ConsultaRegistraDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(ConsultaRegistra cr) {
		int inseriu = 0;
		String sql = "INSERT INTO Consulta_Registra(CPF_veteri, CPF_Cliente, codigo_animal, data_hora, valor, diagnostico) VALUES (?, ?, ?, ?, ?, ?);";
		PreparedStatement stmt;
		try {
			stmt=(PreparedStatement) connection.prepareStatement(sql);
			stmt.setString(1, cr.getCPF_Veterinairo());
			stmt.setString(2, cr.getCPF_Cliente());
			stmt.setString(3, cr.getCodigo_animal());
			stmt.setString(4, cr.getData_hora());
			stmt.setDouble(5, cr.getValor());
			stmt.setString(6,cr.getDiagnostico());
			
			inseriu=stmt.executeUpdate();
			crs.add(cr);
			stmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return inseriu;
		
	}
	
	public ArrayList <ConsultaRegistra> getLista(){ 
		String sql = "SELECT * FROM Consulta_Registra;"; 
		PreparedStatement stmt; 
		ConsultaRegistra cr; 
		ArrayList <ConsultaRegistra> crsMostrar = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					cr = new ConsultaRegistra(); 
					cr.setCPF_Veterinairo(rs.getString("CPF_Veteri"));
					cr.setCPF_Cliente(rs.getString("CPF_Cliente"));
					cr.setCodigo_animal(rs.getString("codigo_animal"));
					cr.setData_hora(rs.getString("data_hora"));
					cr.setValor(rs.getDouble("valor"));
					cr.setDiagnostico(rs.getString("diagnostico"));
			
					crsMostrar.add(cr);
				} 
					rs.close(); 
					stmt.close(); 
					return crsMostrar;
				} catch(SQLException e) { 
					e.printStackTrace(); 
				} 
			
			return null; 
	} 
	
	public ArrayList <ConsultaRegistra> getListaParametro(String CPF_vet, String CPF_cli, String cod_a, String d_h){ 
		String sql = "SELECT * FROM Consulta_Registra WHERE CPF_Veteri = ? and CPF_Cliente = ? and codigo_animal = ? and data_hora = ?;"; 
		PreparedStatement stmt; 
		ConsultaRegistra cr;
		ArrayList <ConsultaRegistra> crP = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, CPF_vet);
					stmt.setString(2, CPF_cli);
					stmt.setString(3,cod_a);
					stmt.setString(4, d_h);
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
						cr = new ConsultaRegistra();  
						cr.setCPF_Veterinairo(rs.getString("CPF_Veteri"));
						cr.setCPF_Cliente(rs.getString("CPF_Cliente"));
						cr.setCodigo_animal(rs.getString("codigo_animal"));
						cr.setData_hora(rs.getString("data_hora"));
						cr.setValor(rs.getDouble("valor"));
						cr.setDiagnostico(rs.getString("diagnostico"));
						crP.add(cr);
				} 
					rs.close(); 
					stmt.close(); 
					return crP;
				} catch(SQLException e) { 
					e.printStackTrace(); 
			}
			return null; 
	} 
	
	public int remover(ConsultaRegistra cr) {
		int removeu = 0;
		boolean achou = false;
			String sql2 = "SELECT e.data_hora, r.data_hora FROM gera_exame e, receita r WHERE e.data_hora = ? or r.data_hora=? ;";
			PreparedStatement stmt2;
			try {
				stmt2=connection.prepareStatement(sql2);
				stmt2.setString(1, cr.getData_hora());
				stmt2.setString(2, cr.getData_hora());
				ResultSet rs2 = stmt2.executeQuery();
				if(rs2.next()) {
					achou = true;
					
				}
				rs2.close();
				stmt2.close();
				//return verifica;
				
				}catch(SQLException e) {
					e.printStackTrace();
				}
			if(achou) {
				JOptionPane.showMessageDialog(null, "H� tabelas referenciadas pelos registros de consulta, � necess�rio exclu�-las primeiro", "Erro de refer�ncia", JOptionPane.ERROR_MESSAGE, null);
			}else{
		
		String sql = "DELETE FROM consulta_registra WHERE CPF_veteri = ? and CPF_Cliente = ? and codigo_animal = ? and data_hora = ?;";
		PreparedStatement stmt;
				try {
					stmt = connection.prepareStatement(sql);
					stmt.setString(1, cr.getCPF_Veterinairo());
					stmt.setString(2, cr.getCPF_Cliente());
					stmt.setString(3, cr.getCodigo_animal());
					stmt.setString(4, cr.getData_hora());
					removeu = stmt.executeUpdate();
					stmt.close();
					
				}catch(SQLException e) {
					e.printStackTrace();
			}
		}
			crsMostrar.remove(cr);
			crP.remove(cr);
			crs.remove(cr);
		
		return removeu;
	}
	
	public int alterar(ConsultaRegistra cr) {
		
		int alterou = 0;
		String sql = "UPDATE Consulta_registra SET valor = ?, diagnostico = ? WHERE  CPF_Veteri = ? and CPF_Cliente = ? and codigo_animal = ? and data_hora = ?;";
		PreparedStatement stmt;
		crsMostrar.remove(cr);
		crP.remove(cr);
		crs.remove(cr);
				try {
					stmt=connection.prepareStatement(sql);
					stmt.setDouble(1, cr.getValor());
					stmt.setString(2,cr.getDiagnostico());
					stmt.setString(3, cr.getCPF_Veterinairo());
					stmt.setString(4, cr.getCPF_Cliente());
					stmt.setString(5, cr.getCodigo_animal());
					stmt.setString(6, cr.getData_hora());
					alterou = stmt.executeUpdate();
					stmt.close();
				}catch(SQLException e){
					e.printStackTrace();
					
		}
		crsMostrar.add(cr);
		crP.add(cr);
		crs.add(cr);
		return alterou;
	}
	public ConsultaRegistra verificaCR (String CPF_vet, String CPF_cli, String cod_a, String d_h) {
		ConsultaRegistra cr = null;
		String sql = "SELECT CPF_Veteri, CPF_Cliente, codigo_animal, data_hora FROM Consulta_registra WHERE CPF_Veteri = ? and CPF_Cliente = ? and codigo_animal = ? and data_hora = ?;";
		PreparedStatement stmt;
				try {
					stmt=connection.prepareStatement(sql);
					stmt.setString(1, CPF_vet);
					stmt.setString(2, CPF_cli);
					stmt.setString(3,cod_a);
					stmt.setString(4, d_h);
					ResultSet rs = stmt.executeQuery();
					if(rs.next()) {
					cr = new ConsultaRegistra();
					}
					rs.close();
					stmt.close();
					//return verifica;
					
				}catch(SQLException e) {
					e.printStackTrace();

		}
		return cr;
	}


}
