package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Receita;

public class ReceitaDAO {
	private Connection connection;
	ArrayList <Receita> receitas = new ArrayList<>(); 
	ArrayList <Receita> receitasMostrar = new ArrayList<>(); 
	ArrayList <Receita> receitasP = new ArrayList<>(); 
	
	public ReceitaDAO() {
		this.connection = new FabricaConexoes().getConnection();
		
	}
	
	public int inserir(Receita r) {
		int inseriu = 0;
		String sql = "INSERT INTO receita(Codigo_R, medicamento, dose_diaria, tempo_tratamento, CPF_veterinario, CPF_do_Cliente, codigo_de_um_animal, data_hora) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement stmt;
		try {
			stmt=(PreparedStatement) connection.prepareStatement(sql);
			stmt.setString(1, r.getCodigo_R());
			stmt.setString(2, r.getMedicamento());
			stmt.setString(3, r.getDose_diaria());
			stmt.setString(4, r.getTempo_tratamento());
			stmt.setString(5, r.getCPF_Veterinario());
			stmt.setString(6, r.getCPF_Cliente());
			stmt.setString(7, r.getCodigo_de_um_animal());
			stmt.setString(8, r.getData_hora());
			inseriu=stmt.executeUpdate();
			receitas.add(r);
			stmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		
		return inseriu;
		}
	
	
	public ArrayList <Receita> getLista(){ 
		String sql = "SELECT * FROM receita;"; 
		PreparedStatement stmt; 
		Receita r; 
		ArrayList <Receita> receitasMostrar = new ArrayList<>(); 
			try { 
				stmt = connection.prepareStatement(sql); 
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				r = new Receita(); 
				r.setCodigo_R(rs.getString("codigo_R"));
				r.setMedicamento(rs.getString("medicamento"));
				r.setDose_diaria(rs.getString("dose_diaria"));
				r.setTempo_tratamento(rs.getString("tempo_tratamento"));
				r.setCPF_Veterinario(rs.getString("CPF_Veterinario"));
				r.setCPF_Cliente(rs.getString("CPF_do_Cliente"));
				r.setCodigo_de_um_animal(rs.getString("codigo_de_um_animal"));
				r.setData_hora(rs.getString("data_hora"));
				receitasMostrar.add(r);
			} 
				rs.close(); 
				stmt.close(); 
				return receitasMostrar;
			} catch(SQLException e) { 
				e.printStackTrace(); 
			} 
			return null; 
	} 
	
	public ArrayList <Receita> getListaParametro(String cod_r){ 
		String sql = "SELECT * FROM receita WHERE codigo_R = ?;"; 
		PreparedStatement stmt; 
		Receita r; 
		ArrayList <Receita> receitasP = new ArrayList<>(); 
			try { 
				stmt = connection.prepareStatement(sql); 
				stmt.setString(1, cod_r);
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				r = new Receita(); 
				r.setCodigo_R(rs.getString("codigo_R"));
				r.setMedicamento(rs.getString("medicamento"));
				r.setDose_diaria(rs.getString("dose_diaria"));
				r.setTempo_tratamento(rs.getString("tempo_tratamento"));
				r.setCPF_Veterinario(rs.getString("CPF_Veterinario"));
				r.setCPF_Cliente(rs.getString("CPF_do_Cliente"));
				r.setCodigo_de_um_animal(rs.getString("codigo_de_um_animal"));
				r.setData_hora(rs.getString("data_hora"));
				receitasP.add(r);
			} 
				rs.close(); 
				stmt.close(); 
				return receitasP; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
	} 
	
	
	public int remover(Receita r) {
		int removeu = 0;
		String sql = "DELETE FROM receita WHERE codigo_R = ?;";
		PreparedStatement stmt;
			try {
				stmt = connection.prepareStatement(sql);
				stmt.setString(1,r.getCodigo_R());
				removeu = stmt.executeUpdate();
				stmt.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
		}
			receitas.remove(r);
			receitasMostrar.remove(r);
			receitasP.remove(r);
		return removeu;
	}
	
	public int alterar(Receita r) {
		int alterou = 0;
		String sql = "UPDATE receita SET medicamento = ?, dose_diaria = ?, tempo_tratamento = ?, CPF_Veterinario = ?, CPF_do_Cliente = ?, codigo_de_um_animal = ?, data_hora = ? WHERE codigo_R = ?;";
		PreparedStatement stmt;
		receitas.remove(r);
		receitasMostrar.remove(r);
		receitasP.remove(r);
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, r.getMedicamento());
				stmt.setString(2, r.getDose_diaria());
				stmt.setString(3, r.getTempo_tratamento());
				stmt.setString(4, r.getCPF_Veterinario());
				stmt.setString(5, r.getCPF_Cliente());
				stmt.setString(6, r.getCodigo_de_um_animal());
				stmt.setString(7, r.getData_hora());
				stmt.setString(8, r.getCodigo_R());
				alterou = stmt.executeUpdate();
				stmt.close();
			}catch(SQLException e){
				e.printStackTrace();
				
			}
			receitas.add(r);
			receitasMostrar.add(r);
			receitasP.add(r);
		return alterou;
	}
	public Receita verificaReceita(String cod_r) {
		Receita r = null;
		String sql = "SELECT codigo_R FROM receita WHERE codigo_R = ?;";
		PreparedStatement stmt;
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, cod_r);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					r = new Receita();
				}
				rs.close();
				stmt.close();
				//return verifica;
				
				}catch(SQLException e) {
					e.printStackTrace();
		}
		return r;
	}



}
