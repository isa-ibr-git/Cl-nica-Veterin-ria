package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Tel_cli;


public class Tel_cliDAO {
	private Connection connection;
	ArrayList <Tel_cli> tels_cli = new ArrayList<>(); 
	ArrayList <Tel_cli> tclP = new ArrayList<>(); 
	ArrayList <Tel_cli> tels_cli_Mostrar = new ArrayList<>(); 

	public Tel_cliDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Tel_cli tcl) {
		int inseriu = 0;
			String sql = "INSERT INTO tel_cliente(CPF_cli, tel_cli) VALUES (?, ?);";
			PreparedStatement stmt;
			try {
				stmt=(PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, tcl.getCPF_Cliente());
				stmt.setString(2, tcl.getTelefone_cli());
				tels_cli.add(tcl);
				
				inseriu=stmt.executeUpdate();
				stmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return inseriu;
		}
	
	
	public ArrayList <Tel_cli> getLista(){ 
		String sql = "SELECT * FROM tel_cliente;"; 
		PreparedStatement stmt; 
		Tel_cli tcl; 
		ArrayList <Tel_cli> tels_cli_Mostrar = new ArrayList<>(); 
			try { 
				stmt = connection.prepareStatement(sql); 
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				tcl = new Tel_cli(); 
				tcl.setCPF_Cliente(rs.getString("CPF_cli"));
				tcl.setTelefone_cli(rs.getString("tel_cli"));
				
				tels_cli_Mostrar.add(tcl); 
			} 
				rs.close(); 
				stmt.close(); 
				return tels_cli_Mostrar; 
			} catch(SQLException e) { 
				e.printStackTrace(); 
			} 
		
			return null; 
	}
	
	public ArrayList <Tel_cli> getListaParametro(String CPF_cli, String tel){ 
		String sql = "SELECT * FROM tel_cliente WHERE CPF_cli = ? and tel_cli = ?;"; 
		PreparedStatement stmt; 
		Tel_cli tcl; 
		ArrayList <Tel_cli> tclP = new ArrayList<>(); 
			try { 
				tcl = new Tel_cli();
				stmt = connection.prepareStatement(sql); 
				stmt.setString(1, CPF_cli);
				stmt.setString(2, tel);
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				tcl.setCPF_Cliente(rs.getString("CPF_cli"));
				tcl.setTelefone_cli(rs.getString("tel_cli"));
				tclP.add(tcl);
			} 
				rs.close(); 
				stmt.close(); 
				return tclP; 
			} catch(SQLException e) { 
				e.printStackTrace(); 
		}
			return null; 
	}
	
	public int remover(Tel_cli tcl) {
		int removeu = 0;
		String sql = "DELETE FROM tel_cliente WHERE CPF_cli = ? and tel_cli = ?;";
		PreparedStatement stmt;
			try {
				stmt = connection.prepareStatement(sql);
				stmt.setString(1, tcl.getCPF_Cliente());
				stmt.setString(2, tcl.getTelefone_cli());
				removeu = stmt.executeUpdate();
				stmt.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
			tclP.remove(tcl);
			tels_cli_Mostrar.remove(tcl);
			tels_cli.remove(tcl);
		return removeu;
	}
	
	public int alterar(Tel_cli tcl, Tel_cli tcl2) {
		int alterou = 0;
		PreparedStatement stmt;
		PreparedStatement stmt2;
		PreparedStatement stmt3;
		String cpf_cli_antigo = "";
		String tel_antigo  = "";
		String cpfTeste = "";
		String telTeste = "";
		boolean achou = false;
			try {
				String sql1 = "SELECT * FROM tel_cliente WHERE cpf_cli = ? and tel_cli = ?;";
				stmt = connection.prepareStatement(sql1);
					stmt.setString(1, tcl.getCPF_Cliente());
					stmt.setString(2, tcl.getTelefone_cli());
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
						cpf_cli_antigo = rs.getString("CPF_Cli");
						tel_antigo = rs.getString("tel_cli");
						achou = true;
					}
					}catch(SQLException e){
						e.printStackTrace();
						
					}
			try {
				String sql3 = "SELECT * FROM tel_cliente where cpf_cli = ? and tel_cli = ?;";
				
				stmt3 = connection.prepareStatement(sql3);
				stmt3.setString(1, tcl2.getCPF_Cliente());
				stmt3.setString(2, tcl2.getTelefone_cli());
				
				ResultSet rs3 = stmt3.executeQuery(); 
				while (rs3.next()) {
					cpfTeste = rs3.getString("CPF_cli");
					telTeste = rs3.getString("tel_cli");
					
					
				}
					}catch(SQLException e){
						e.printStackTrace();
						
					}
		if(cpfTeste.equals(tcl2.getCPF_Cliente()) && telTeste.equals(tcl2.getTelefone_cli())){
			JOptionPane.showMessageDialog(null, "J� existe um registro de telefone de cliente cadastrado com esses dados solicitados para altera��o", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
			
		}else {
			if(achou) {
						String sql2 = "UPDATE tel_cliente SET cpf_cli = ?, tel_cli = ? WHERE cpf_cli = ? and tel_cli = ?;";
							try {
							stmt2 = connection.prepareStatement(sql2);
							stmt2.setString(1, tcl2.getCPF_Cliente());
							stmt2.setString(2, tcl2.getTelefone_cli());
							
							stmt2.setString(3, cpf_cli_antigo);
							stmt2.setString(4, tel_antigo);
							
							alterou = stmt2.executeUpdate();
							
							
							
							
							}catch(SQLException e){
								e.printStackTrace();
								
							
						}
			}

		
		tclP.remove(tcl);
		tels_cli_Mostrar.remove(tcl);
		tels_cli.remove(tcl);
	}
		return alterou;
		
		
	}
	
	
	public Tel_cli verificaTel_cli(String cpf_cli, String tel_cli) {
		Tel_cli tc = null;
		String sql = "SELECT CPF_cli, tel_cli FROM tel_cliente WHERE CPF_cli=? and tel_cli = ?;";
		PreparedStatement stmt;
		
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, cpf_cli);
				stmt.setString(2, tel_cli);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					tc = new Tel_cli();
				}
				rs.close();
				stmt.close();
				//return verifica;
				
			}catch(SQLException e) {
				e.printStackTrace();
		}
		return tc;
	}
}
