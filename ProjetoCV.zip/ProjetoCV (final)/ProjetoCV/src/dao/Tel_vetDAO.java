package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Tel_vet;


public class Tel_vetDAO {
	private Connection connection;
	ArrayList <Tel_vet> tels_vet = new ArrayList<>();
	ArrayList <Tel_vet> tvtP = new ArrayList<>(); 
	ArrayList <Tel_vet> tels_vet_Mostrar = new ArrayList<>();

	public Tel_vetDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Tel_vet tvt) {
		int inseriu = 0;

		String sql = "INSERT INTO tel_func(CPF_func, telefone) VALUES (?, ?);";
		PreparedStatement stmt;
			try {
				stmt=(PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, tvt.getCPF_Veterinario());
				stmt.setString(2, tvt.getTelefone_vet());
				
				inseriu=stmt.executeUpdate();
				tels_vet.add(tvt);
				stmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			return inseriu;
		}
	
	public ArrayList <Tel_vet> getLista(){ 
		String sql = "SELECT * FROM tel_func;"; 
		PreparedStatement stmt; 
		Tel_vet tvt;
		ArrayList <Tel_vet> tels_vet_Mostrar = new ArrayList<>(); 

			try { 
				stmt = connection.prepareStatement(sql); 
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				tvt = new Tel_vet(); 
				tvt.setCPF_Veterinario(rs.getString("CPF_Func"));
				tvt.setTelefone_vet(rs.getString("telefone"));
				
				tels_vet_Mostrar.add(tvt); 
			} 
				rs.close(); 
				stmt.close(); 
				return tels_vet_Mostrar; 
			} catch(SQLException e) { 
				e.printStackTrace(); 
			} 
			return null; 
	}
	
	public ArrayList <Tel_vet> getListaParametro(String CPF_vet, String tel){ 
		String sql = "SELECT * FROM tel_func WHERE CPF_func = ? and telefone = ?;"; 
		PreparedStatement stmt; 
		Tel_vet tvt; 
		ArrayList <Tel_vet> tvtP = new ArrayList<>(); 
			try { 
				tvt= new Tel_vet();
				stmt = connection.prepareStatement(sql); 
				stmt.setString(1, CPF_vet);
				stmt.setString(2, tel);
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				tvt.setCPF_Veterinario(rs.getString("CPF_Func"));
				tvt.setTelefone_vet(rs.getString("Telefone"));
				tvtP.add(tvt);
			} 
				rs.close(); 
				stmt.close(); 
				return tvtP; 
			} catch(SQLException e) { 
				e.printStackTrace();
			} 
	
			return null; 
	}
	
	public int remover(Tel_vet tvt) {
		int removeu = 0;
		String sql = "DELETE FROM tel_func WHERE CPF_func = ? and telefone = ?;";
		PreparedStatement stmt;
		
			try {
				stmt = connection.prepareStatement(sql);
				stmt.setString(1, tvt.getCPF_Veterinario());
				stmt.setString(2, tvt.getTelefone_vet());
				removeu = stmt.executeUpdate();
				stmt.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
		tvtP.remove(tvt);
		tels_vet_Mostrar.remove(tvt);
		tels_vet.remove(tvt);
		return removeu;
	}
	
	public int alterar(Tel_vet tvt, Tel_vet tvt2) {
		int alterou = 0;
		PreparedStatement stmt;
		PreparedStatement stmt2;
		PreparedStatement stmt3;
		String cpf_func_antigo = "";
		String tel_antigo = "";
		String telTeste = "";
		String cpfTeste = "";
		boolean achou = false;

			try {
				String sql1 = "SELECT * FROM tel_func WHERE cpf_func = ? and telefone = ?;";
				stmt = connection.prepareStatement(sql1);
					stmt.setString(1, tvt.getCPF_Veterinario());
					stmt.setString(2, tvt.getTelefone_vet());
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
						cpf_func_antigo = rs.getString("CPF_func");
						tel_antigo = rs.getString("telefone");
						achou = true;
					}
					}catch(SQLException e){
						e.printStackTrace();
						
					}
			try {
					String sql3 = 	"SELECT * FROM tel_func;";
					stmt3 = connection.prepareStatement(sql3);
					ResultSet rs3 = stmt3.executeQuery(); 
					while (rs3.next()) {
						cpfTeste = rs3.getString("CPF_Func");
						telTeste = rs3.getString("telefone");
						
						
					}
						}catch(SQLException e){
							e.printStackTrace();
							
						}
			if(cpfTeste.equals(tvt2.getCPF_Veterinario()) && telTeste.equals(tvt2.getTelefone_vet())) {
				JOptionPane.showMessageDialog(null, "J� existe um registro de telefone de veterin�rio cadastrado com esses dados solicitados para altera��o", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
				
			}else {
				if(achou) {
						try {
						String sql2 = "UPDATE tel_func SET cpf_func = ?, telefone = ? WHERE cpf_func = ? and telefone = ?;";
						stmt2 = connection.prepareStatement(sql2);
						stmt2.setString(1, tvt2.getCPF_Veterinario());;
						stmt2.setString(2, tvt2.getTelefone_vet());
						
						stmt2.setString(3, cpf_func_antigo);
						stmt2.setString(4, tel_antigo);
						
						alterou = stmt2.executeUpdate();
						}catch(SQLException e){
							e.printStackTrace();
						}
						
				}
			}
			tvtP.remove(tvt);
			tels_vet_Mostrar.remove(tvt);
			tels_vet.remove(tvt);
			return alterou;
			
			}

			

	
	public Tel_vet verificaTel_vet(String cpf_vet, String tel_vet) {
		Tel_vet tv = null;
		String sql = "SELECT CPF_func, telefone FROM tel_func WHERE CPF_func=? and telefone = ?;";
		PreparedStatement stmt;
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, cpf_vet);
				stmt.setString(2, tel_vet);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					tv = new Tel_vet();
				}
				rs.close();
				stmt.close();
				//return verifica;
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
		
		return tv;
	}
	
	
 
	

}
