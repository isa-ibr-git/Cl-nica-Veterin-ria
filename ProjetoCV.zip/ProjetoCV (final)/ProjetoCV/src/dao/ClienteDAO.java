package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Cliente;


public class ClienteDAO {
	private Connection connection;
	ArrayList <Cliente> clientes = new ArrayList<>(); 
	ArrayList <Cliente> clientesMostrar = new ArrayList<>();
	ArrayList <Cliente> clientesP = new ArrayList<>(); 
	boolean achou = false;
	boolean achou2 = false;
	
	public ClienteDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Cliente c) {
		int inseriu = 0;
			String sql = "INSERT INTO Cliente(CPF, RG, nome, email, cep, num, logradouro, cidade, bairro, estado, pais) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
			PreparedStatement stmt;
			try {
				stmt=(PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, c.getCPF());
				stmt.setString(2, c.getRG());
				stmt.setString(3, c.getNome());
				stmt.setString(4, c.getEmail());
				stmt.setString(5, c.getCep());
				stmt.setInt(6, c.getNumero());
				stmt.setString(7, c.getLogradouro());
				stmt.setString(8, c.getCidade());
				stmt.setString(9, c.getBairro());
				stmt.setString(10, c.getEstado());
				stmt.setString(11, c.getPais());
				inseriu=stmt.executeUpdate();
				clientes.add(c);
				stmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			return inseriu;
		}
		
	
	
	public ArrayList <Cliente> getLista(){ 
		String sql = "SELECT * FROM Cliente;"; 
		PreparedStatement stmt; 
		Cliente c; 
		ArrayList <Cliente> clientesMostrar = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					c = new Cliente(); 
					c.setCPF(rs.getString("CPF"));
					c.setRG(rs.getString("RG"));
					c.setNome(rs.getString("nome"));
					c.setEmail(rs.getString("email"));
					c.setCep(rs.getString("cep"));
					c.setNumero(rs.getInt("num"));
					c.setLogradouro(rs.getString("logradouro"));
					c.setCidade(rs.getString("cidade"));
					c.setBairro(rs.getString("bairro"));
					c.setEstado(rs.getString("estado"));
					c.setPais(rs.getString("pais"));
					clientesMostrar.add(c); 
				} 
					rs.close(); 
					stmt.close(); 
					return clientesMostrar; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
				} 
			return null; 
	} 
	
	public ArrayList <Cliente> getListaParametro(String CPF){ 
		String sql = "SELECT * FROM Cliente WHERE CPF = ?;"; 
		PreparedStatement stmt; 
		Cliente c; 
		ArrayList <Cliente> clientesP = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, CPF);
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
						c = new Cliente(); 
						c.setCPF(rs.getString("CPF"));
						c.setRG(rs.getString("RG"));
						c.setNome(rs.getString("nome"));
						c.setEmail(rs.getString("email"));
						c.setCep(rs.getString("cep"));
						c.setNumero(rs.getInt("num"));
						c.setLogradouro(rs.getString("logradouro"));
						c.setCidade(rs.getString("cidade"));
						c.setBairro(rs.getString("bairro"));
						c.setEstado(rs.getString("estado"));
						c.setPais(rs.getString("pais"));
						clientesP.add(c);
				} 
					rs.close(); 
					stmt.close(); 
					return clientesP; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
				} 
			
			return null; 
	} 
	
	public int remover(Cliente c) {
		int removeu = 0;
			String sql2 = "SELECT tc.Cpf_cli, a.cpf_cli, cr.cpf_cliente, e.cpf_cliente, r.cpf_do_cliente"
					+ " FROM tel_cliente tc, animal a, consulta_registra cr, gera_exame e, receita r"
					+ " WHERE tc.cpf_cli = ? or a.cpf_cli = ? or cr.cpf_cliente = ? or e.cpf_cliente = ? or r.cpf_do_cliente = ?;";
			PreparedStatement stmt2;
			try {
				stmt2=connection.prepareStatement(sql2);
				stmt2.setString(1, c.getCPF());
				stmt2.setString(2, c.getCPF());
				stmt2.setString(3, c.getCPF());
				stmt2.setString(4, c.getCPF());
				stmt2.setString(5, c.getCPF());
				ResultSet rs2 = stmt2.executeQuery();
				if(rs2.next()) {
					achou2 = true;
					
				}
				rs2.close();
				stmt2.close();
				//return verifica;
				
				}catch(SQLException e) {
					e.printStackTrace();
				}
		
			if(achou2) {
				JOptionPane.showMessageDialog(null, "H� tabelas referenciadas por cliente, � necess�rio exclu�-las primeiro", "Erro de refer�ncia", JOptionPane.ERROR_MESSAGE, null);
			}else{
		String sql = "DELETE FROM Cliente WHERE CPF = ?;";
		PreparedStatement stmt;
				try {
					stmt = connection.prepareStatement(sql);
					stmt.setString(1, c.getCPF());
					removeu = stmt.executeUpdate();
					stmt.close();
					
				}catch(SQLException e) {
					e.printStackTrace();
			}
		}
		clientes.remove(c);
		clientesMostrar.remove(c);
		clientesP.remove(c);
		return removeu;
	}
	
	public int alterar(Cliente c) {
		clientes.remove(c);
		clientesMostrar.remove(c);
		clientesP.remove(c);
		int alterou = 0;
		String sql = "UPDATE Cliente SET RG = ?, nome = ?, email = ?, cep = ?, num = ?, logradouro = ?, cidade = ?, bairro = ?, estado = ?, pais = ? WHERE CPF = ?;";
		PreparedStatement stmt;
			
				try {
					stmt=connection.prepareStatement(sql);
					
					stmt.setString(1, c.getRG());
					stmt.setString(2, c.getNome());
					stmt.setString(3, c.getEmail());
					stmt.setString(4, c.getCep());
					stmt.setInt(5, c.getNumero());
					stmt.setString(6, c.getLogradouro());
					stmt.setString(7, c.getCidade());
					stmt.setString(8, c.getBairro());
					stmt.setString(9, c.getEstado());
					stmt.setString(10, c.getPais());
					stmt.setString(11, c.getCPF());
					alterou = stmt.executeUpdate();
					stmt.close();
				}catch(SQLException e){
					e.printStackTrace();
					
				}
			
		clientes.add(c);
		clientesMostrar.add(c);
		clientesP.add(c);
		return alterou;
	}
	public Cliente verificaCliente(String cpf) {
		Cliente c = null;
		String sql = "SELECT CPF FROM Cliente WHERE CPF = ?;";
		PreparedStatement stmt;
				try {
					stmt=connection.prepareStatement(sql);
					stmt.setString(1, cpf);
					ResultSet rs = stmt.executeQuery();
					if(rs.next()) {
						c = new Cliente();
					}
					rs.close();
					stmt.close();
					//return verifica;
					
				}catch(SQLException e) {
					e.printStackTrace();
			}
		return c;
	}

}
