package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import bean.Veterinario;


public class VeterinarioDAO {
	private Connection connection;
	ArrayList <Veterinario> veterinarios = new ArrayList<>(); 
	ArrayList <Veterinario> veterinariosMostrar  = new ArrayList<>(); 
	ArrayList <Veterinario> veterinariosP = new ArrayList<>();
	
	boolean achou = false;
	boolean achou2 = false;

	public VeterinarioDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Veterinario v) {
		int inseriu = 0;
		
			String sql = "INSERT INTO Veterinario(CPF_Func, CRV, nro_cartao, nome, RG, data_nascimento, salario, CEP, numero, logradouro, cidade, bairro, estado, pais, instituicao, data_conclusao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
			PreparedStatement stmt;
			try {
				stmt=(PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, v.getCPF_Func());
				stmt.setString(2, v.getCRV());
				stmt.setString(3, v.getNro_cartao());
				stmt.setString(4, v.getNome());
				stmt.setString(5, v.getRG());
				stmt.setString(6, v.getData_nascimento());
				stmt.setDouble(7, v.getSalario());
				stmt.setString(8, v.getCEP());
				stmt.setInt(9, v.getNumero());
				stmt.setString(10, v.getLogradouro());
				stmt.setString(11, v.getCidade());
				stmt.setString(12, v.getBairro());
				stmt.setString(13, v.getEstado());
				stmt.setString(14, v.getPais());
				stmt.setString(15, v.getInstituicao());
				stmt.setString(16, v.getData_conclusao());
				inseriu=stmt.executeUpdate();
				veterinarios.add(v);
				stmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			return inseriu;
		}
		
		
	
	public ArrayList <Veterinario> getLista(){ 
		String sql = "SELECT * FROM Veterinario;"; 
		PreparedStatement stmt; 
		Veterinario v; 
		ArrayList <Veterinario> veterinariosMostrar  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					v = new Veterinario(); 
					v.setCPF_Func(rs.getString("CPF_Func"));
					v.setCRV(rs.getString("crv"));
					v.setNro_cartao(rs.getString("nro_cartao"));
					v.setNome(rs.getString("nome"));
					v.setRG(rs.getString("RG"));
					v.setData_nascimento(rs.getString("data_nascimento"));
					v.setSalario(rs.getDouble("salario"));
					v.setCEP(rs.getString("CEP"));
					v.setNumero(rs.getInt("numero"));
					v.setLogradouro(rs.getString("logradouro"));
					v.setCidade(rs.getString("cidade"));
					v.setBairro(rs.getString("bairro"));
					v.setEstado(rs.getString("estado"));
					v.setPais(rs.getString("pais"));
					v.setInstituicao(rs.getString("instituicao"));
					v.setData_conclusao(rs.getString("data_conclusao"));
					veterinariosMostrar.add(v); 
				} 
					rs.close(); 
					stmt.close(); 
					return veterinariosMostrar; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
	} 
	
	public ArrayList <Veterinario> getListaParametro(String CPF_Func){ 
		String sql = "SELECT * FROM Veterinario WHERE CPF_Func = ?;"; 
		PreparedStatement stmt; 
		Veterinario v; 
		ArrayList <Veterinario> veterinariosP = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, CPF_Func);
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					v = new Veterinario(); 
					v.setCPF_Func(rs.getString("CPF_Func"));
					v.setCRV(rs.getString("crv"));
					v.setNro_cartao(rs.getString("nro_cartao"));
					v.setNome(rs.getString("nome"));
					v.setRG(rs.getString("RG"));
					v.setData_nascimento(rs.getString("data_nascimento"));
					v.setSalario(rs.getDouble("salario"));
					v.setCEP(rs.getString("CEP"));
					v.setNumero(rs.getInt("numero"));
					v.setLogradouro(rs.getString("logradouro"));
					v.setCidade(rs.getString("cidade"));
					v.setBairro(rs.getString("bairro"));
					v.setEstado(rs.getString("estado"));
					v.setPais(rs.getString("pais"));
					v.setInstituicao(rs.getString("instituicao"));
					v.setData_conclusao(rs.getString("data_conclusao"));
					veterinariosP.add(v); 
				} 
					rs.close(); 
					stmt.close(); 
					return veterinariosP; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
	} 
	
	
	public int remover(Veterinario v) {
		int removeu = 0;
			String sql2 = "SELECT tv.Cpf_func, cr.cpf_veteri, e.cpf_veterina, r.cpf_veterinario"
					+ " FROM tel_func tv, consulta_registra cr, gera_exame e, receita r"
					+ " WHERE tv.cpf_func = ? or cr.cpf_veteri = ? or e.cpf_veterina = ? or r.cpf_veterinario = ?;";
			PreparedStatement stmt2;
			try {
				stmt2=connection.prepareStatement(sql2);
				stmt2.setString(1, v.getCPF_Func());
				stmt2.setString(2, v.getCPF_Func());
				stmt2.setString(3, v.getCPF_Func());
				stmt2.setString(4, v.getCPF_Func());
				ResultSet rs2 = stmt2.executeQuery();
				if(rs2.next()) {
					achou2 = true;
					
				}
				rs2.close();
				stmt2.close();
				//return verifica;
				
				}catch(SQLException e) {
					e.printStackTrace();
				}
			if(achou2) {
				JOptionPane.showMessageDialog(null, "H� tabelas referenciadas por veterin�rio, � necess�rio exclu�-las primeiro", "Erro de refer�ncia", JOptionPane.ERROR_MESSAGE, null);
			}else{
				String sql = "DELETE FROM Veterinario WHERE CPF_Func = ?;";
			PreparedStatement stmt;
						try {
							stmt = connection.prepareStatement(sql);
							stmt.setString(1, v.getCPF_Func());
							removeu = stmt.executeUpdate();
							stmt.close();
							
						}catch(SQLException e) {
							e.printStackTrace();
						}
				}
		veterinarios.remove(v);
		veterinariosP.remove(v);
		veterinariosMostrar.remove(v);
		return removeu;
		}
	
	
	public int alterar(Veterinario v) {
		veterinarios.remove(v);
		int alterou = 0;
		String sql = "UPDATE Veterinario SET crv=?, nro_cartao = ?, nome = ?, rg = ?, data_nascimento = ?, salario = ?, cep = ?, numero = ?, logradouro = ?, cidade = ?, bairro = ?, estado = ?, pais = ?, instituicao = ?, data_conclusao = ? WHERE CPF_Func = ?;";
		PreparedStatement stmt;
		veterinarios.remove(v);
		veterinariosP.remove(v);
		veterinariosMostrar.remove(v);
				try {
					stmt=connection.prepareStatement(sql);
					stmt.setString(1, v.getCRV());
					stmt.setString(2, v.getNro_cartao());
					stmt.setString(3, v.getNome());
					stmt.setString(4, v.getRG());
					stmt.setString(5, v.getData_nascimento());
					stmt.setDouble(6, v.getSalario());
					stmt.setString(7, v.getCEP());
					stmt.setInt(8, v.getNumero());
					stmt.setString(9, v.getLogradouro());
					stmt.setString(10, v.getCidade());
					stmt.setString(11, v.getBairro());
					stmt.setString(12, v.getEstado());
					stmt.setString(13, v.getPais());
					stmt.setString(14, v.getInstituicao());
					stmt.setString(15, v.getData_conclusao());
					stmt.setString(16, v.getCPF_Func());
					alterou = stmt.executeUpdate();
					stmt.close();
				}catch(SQLException e){
					e.printStackTrace();
			}
		veterinarios.add(v);
		veterinariosP.add(v);
		veterinariosMostrar.add(v);
		return alterou;
	}
	public Veterinario verificaVet(String cpf_func) {
		Veterinario v = null;
		String sql = "SELECT CPF_Func FROM Veterinario WHERE CPF_Func=?;";
		PreparedStatement stmt;
				try {
					stmt=connection.prepareStatement(sql);
					stmt.setString(1, cpf_func);
					ResultSet rs = stmt.executeQuery();
					if(rs.next()) {
						v = new Veterinario();
					}
					rs.close();
					stmt.close();
					//return verifica;
					
				}catch(SQLException e) {
					e.printStackTrace();
			
		}
		return v;
	}

}
