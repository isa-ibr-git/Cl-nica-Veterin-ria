package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Dependente;
import bean.Exame;
import bean.Tel_cli;
import bean.Tel_vet;

public class DependenteDAO {
	ArrayList <Dependente> depMostrar = new ArrayList<>();
	private Connection connection;
	
	public DependenteDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Dependente d) {
		int inseriu = 0;

		String sql = "INSERT INTO dependente(CPF_Func, nome, Data_Nas, sexo) VALUES (?, ?, ?, ?);";
		PreparedStatement stmt;
			try {
				stmt=(PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, d.getCpf_func());
				stmt.setString(2, d.getNome());
				stmt.setString(3, d.getData_nas());
				stmt.setString(4, d.getSexo());
				
				inseriu=stmt.executeUpdate();
				stmt.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			return inseriu;
		}
	public ArrayList <Dependente> getLista(){ 
		String sql = "SELECT * FROM dependente;"; 
		PreparedStatement stmt; 
		Dependente d;
		ArrayList <Dependente> depMostrar = new ArrayList<>();
		
			try { 
				stmt = connection.prepareStatement(sql); 
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				d = new Dependente(); 
				d.setCpf_func(rs.getString("CPF_Func"));
				d.setNome(rs.getString("nome"));
				d.setData_nas(rs.getString("Data_Nas"));
				d.setSexo(rs.getString("sexo"));
				depMostrar.add(d);
			} 
				rs.close(); 
				stmt.close(); 
				return depMostrar;
			} catch(SQLException e) { 
				e.printStackTrace(); 
			} 
			return null; 
	} 
	
	public Dependente verificaDep(String cpf_f, String nome) {
		Dependente dep = null;
		String sql = "SELECT CPF_func, nome FROM dependente WHERE CPF_func=? and nome = ?;";
		PreparedStatement stmt;
		
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, cpf_f);
				stmt.setString(2, nome);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					dep = new Dependente();
				}
				rs.close();
				stmt.close();
				//return verifica;
				
			}catch(SQLException e) {
				e.printStackTrace();
		}
		return dep;
	}
	
	public int remover(Dependente d) {
		int removeu = 0;
		String sql = "DELETE FROM Dependente WHERE CPF_func = ? and nome = ?;";
		PreparedStatement stmt;
			try {
				stmt = connection.prepareStatement(sql);
				stmt.setString(1, d.getCpf_func());
				stmt.setString(2, d.getNome());
				removeu = stmt.executeUpdate();
				stmt.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
		return removeu;
	}
}
