package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Animal;



public class AnimalDAO {
	private Connection connection;
	ArrayList <Animal> animais = new ArrayList<>(); 
	ArrayList <Animal> animaisMostrar = new ArrayList<>(); 
	ArrayList <Animal> animaisP = new ArrayList<>(); 

	public AnimalDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Animal a) {
		int inseriu = 0;
		String sql = "INSERT INTO Animal(CPF_Cli, codigo, nome, raca, data_nas, especie, porteAnimal) VALUES (?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement stmt;
				try {
					stmt=(PreparedStatement) connection.prepareStatement(sql);
					stmt.setString(1, a.getCPF_Cli());
					stmt.setString(2, a.getCodigo());
					stmt.setString(3, a.getNome());
					stmt.setString(4, a.getRaca());
					stmt.setString(5, a.getData_nas());
					stmt.setString(6, a.getEspecie());
					stmt.setString(7, a.getPorte());
					inseriu=stmt.executeUpdate();
					animais.add(a);
					stmt.close();
				}catch(SQLException e) {
					e.printStackTrace();
		}
				
				return inseriu;
		}
	
	public ArrayList <Animal> getLista(){ 
		String sql = "SELECT * FROM Animal;"; 
		PreparedStatement stmt; 
		Animal a;
		ArrayList <Animal> animaisMostrar = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					a = new Animal(); 
					a.setCPF_Cli(rs.getString("CPF_Cli"));
					a.setCodigo(rs.getString("codigo"));
					a.setNome(rs.getString("nome"));
					a.setRaca(rs.getString("raca"));
					a.setData_nas(rs.getString("data_nas"));
					a.setEspecie(rs.getString("especie"));
					a.setPorte(rs.getString("porteAnimal"));
					animaisMostrar.add(a);
				} 
					rs.close(); 
					stmt.close(); 
					return animaisMostrar; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
				}
			return null; 
	} 
	
	public ArrayList <Animal> getListaParametro(String CPF_Cli, String cod_a){ 
		String sql = "SELECT * FROM Animal WHERE CPF_Cli = ? and codigo = ?;"; 
		PreparedStatement stmt; 
		Animal a; 
		ArrayList <Animal> animaisP = new ArrayList<>(); 
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, CPF_Cli);
					stmt.setString(2, cod_a);
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) {  
					a = new Animal(); 
					a.setCPF_Cli(rs.getString("CPF_Cli"));
					a.setCodigo(rs.getString("codigo"));
					a.setNome(rs.getString("nome"));
					a.setRaca(rs.getString("raca"));
					a.setData_nas(rs.getString("data_nas"));
					a.setEspecie(rs.getString("especie"));
					a.setPorte(rs.getString("porteAnimal"));
					animaisP.add(a);
				} 
					rs.close(); 
					stmt.close(); 
					return animaisP; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
				} 
			return null; 
	} 
	
	
	public int remover(Animal a) {
		
		int removeu = 0;
		boolean achou = false;
			String sql2 = "SELECT cr.codigo_animal, e.codigo_do_animal, r.codigo_de_um_animal"
					+ " FROM consulta_registra cr, gera_exame e, receita r"
					+ " WHERE cr.codigo_animal = ? or e.codigo_do_animal = ? or  r.codigo_de_um_animal = ?;";
			PreparedStatement stmt2;
			try {
				stmt2=connection.prepareStatement(sql2);
				stmt2.setString(1, a.getCodigo());
				stmt2.setString(2, a.getCodigo());
				stmt2.setString(3, a.getCodigo());
				ResultSet rs2 = stmt2.executeQuery();
				if(rs2.next()) {
					achou = true;
					
				}
				rs2.close();
				stmt2.close();
				//return verifica;
				
				}catch(SQLException e) {
					e.printStackTrace();
				}
			if(achou) {
				JOptionPane.showMessageDialog(null, "H� tabelas referenciadas por animal, � necess�rio exclu�-las primeiro", "Erro de refer�ncia", JOptionPane.ERROR_MESSAGE, null);
			}else{
		String sql = "DELETE FROM Animal WHERE CPF_Cli = ? and codigo = ?;";
		PreparedStatement stmt;
	
				try {
					stmt = connection.prepareStatement(sql);
					stmt.setString(1, a.getCPF_Cli());
					stmt.setString(2, a.getCodigo());
					removeu = stmt.executeUpdate();
					stmt.close();
					
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}
		animais.remove(a);
		animaisMostrar.remove(a);
		animaisP.remove(a);
		return removeu;
	}
	
	public int alterar(Animal a) {
		animais.remove(a);
		int alterou = 0;
		String sql = "UPDATE Animal SET nome = ?, raca = ?, data_nas = ?, especie = ?, porteAnimal = ? "
				+ "WHERE CPF_Cli = ? and codigo = ?; ";
		PreparedStatement stmt;
				try {
					stmt=connection.prepareStatement(sql);
				
					stmt.setString(1, a.getNome());
					stmt.setString(2, a.getRaca());
					stmt.setString(3, a.getData_nas());
					stmt.setString(4, a.getEspecie());
					stmt.setString(5, a.getPorte());
					stmt.setString(6, a.getCPF_Cli());
					stmt.setString(7, a.getCodigo());
					alterou = stmt.executeUpdate();
					stmt.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
		animais.add(a);
		animaisP.add(a);
		animaisMostrar.add(a);
		return alterou;
	}
	public Animal verificaAnimal(String cpf_cli, String cod_a) {
		Animal a = null;
		String sql = "SELECT CPF_Cli, codigo FROM Animal WHERE CPF_Cli = ? and codigo = ?;";
		PreparedStatement stmt;
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, cpf_cli);
				stmt.setString(2, cod_a);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					a = new Animal();
				}
				rs.close();
				stmt.close();
				//return verifica;
				
			}catch(SQLException e) {
				e.printStackTrace();

			
		}
			
		return a;
	}


}
