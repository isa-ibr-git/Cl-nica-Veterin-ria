
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Animal;
import bean.ConsultaRegistra;
import bean.Dependente;
import bean.Tel_cli;
import bean.Veterinario;


public class ConsultasDAO {
	private Connection connection;
	
	public ConsultasDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	public ArrayList <Veterinario> consulta1(){
		String sql = "SELECT  nome, Cpf_func, salario FROM Veterinario WHERE salario = (select max(salario) from veterinario);";
		//Lista o maior sal�rio entre todos os veterin�rios
		PreparedStatement stmt; 
		Veterinario v; 
		ArrayList <Veterinario> veterinariosMostrarSalario  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					v = new Veterinario(); 
					v.setCPF_Func(rs.getString("CPF_Func"));
					v.setNome(rs.getString("nome"));
					v.setSalario(rs.getDouble("salario"));
					veterinariosMostrarSalario.add(v); 
				} 
					rs.close(); 
					stmt.close(); 
					return veterinariosMostrarSalario; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
				
	}
	
	public ArrayList <Veterinario> consulta2(){
		String sql = "SELECT sum(salario) as salarioS from veterinario;"; 
		// Exibe a soma de todos os sal�rios dos veterin�rios
		PreparedStatement stmt; 
		Veterinario v; 
		ArrayList <Veterinario> SomaSalario  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					v = new Veterinario(); 
					v.setSalario(Double.parseDouble(rs.getString("salarioS")));
					SomaSalario.add(v); 
				} 
					rs.close(); 
					stmt.close(); 
					return SomaSalario; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
				
	}
	
	public ArrayList <Dependente> consulta3(){
		String sql = "SELECT d.data_nas, d.nome, v.cpf_func from dependente d, veterinario v where v.cpf_func=d.cpf_func order by d.data_nas desc;";
		// Exibe data de nascimento e nome dos dependentes, ordenados de mais novo para mais velho.
		PreparedStatement stmt; 
		Dependente d;
		Veterinario v;
		ArrayList <Dependente> deps  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					d = new Dependente(); 
					v = new Veterinario();
					v.setCPF_Func( rs.getString("Cpf_func"));
					d.setData_nas(rs.getString("data_nas"));
					d.setNome(rs.getString("nome"));
					d.setCpf_func(rs.getString("cpf_func"));
					
					deps.add(d); 
				} 
					rs.close(); 
					stmt.close(); 
					return deps; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
	}
	
	public ArrayList <Dependente> consulta4(String s){
		String sql = "SELECT d.* from dependente d where sexo = ?;";
		// Exibe todos os dados de dependentes que possuem o sexo dado como par�metro na entrada (s)
		PreparedStatement stmt; 
		Dependente d;
		ArrayList <Dependente> depsP  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, s);
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					d = new Dependente(); 
					d.setCpf_func(rs.getString("cpf_func"));
					d.setNome(rs.getString("nome"));
					d.setData_nas(rs.getString("data_nas"));
					d.setSexo(rs.getString("sexo"));
					
					
					depsP.add(d); 
				} 
					rs.close(); 
					stmt.close(); 
					return depsP; 
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
	}
				
	public ArrayList <Animal> consulta5(String esp){
		String sql = "SELECT * from animal where especie = ?;";
		// Exibe todos os dados de animais que est�o de acordo com a esp�cie passada como par�metro (esp)
		PreparedStatement stmt; 
		Animal a;
		ArrayList <Animal> animais  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, esp);
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					a = new Animal(); 
					a.setCPF_Cli(rs.getString("cpf_cli"));
					a.setCodigo(rs.getString("codigo"));
					a.setNome(rs.getString("nome"));
					a.setData_nas(rs.getString("data_nas"));
					a.setRaca(rs.getString("raca"));
					a.setEspecie(rs.getString("especie"));
					a.setPorte(rs.getString("porteAnimal"));
					
					
					animais.add(a); 
				} 
					rs.close(); 
					stmt.close(); 
					return animais;
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
			return null; 
	}
	public ArrayList <Tel_cli> consulta6(String cpf){
		String sql = "SELECT tel_cli from tel_cliente where cpf_cli = ?;"; 
		//Exibe todos os talefones do cliente com cpf passado como par�metro
		PreparedStatement stmt; 
		Tel_cli cl = new Tel_cli();
		ArrayList <Tel_cli> tels  = new ArrayList<>(); 
			
				try { 
					stmt = connection.prepareStatement(sql); 
					stmt.setString(1, cpf);
					
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
					
					cl.setTelefone_cli( rs.getString("tel_cli"));
					tels.add(cl);
				} 
					rs.close(); 
					stmt.close(); 
					
					
			return tels;
						
						
					
					
				} catch(SQLException e) { 
					e.printStackTrace(); 
			} 
				
				
				
			return null; 
	}
}
