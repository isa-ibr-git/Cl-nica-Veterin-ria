package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import bean.Exame;

public class ExameDAO {
	private Connection connection;
	ArrayList <Exame> exames = new ArrayList<>();
	ArrayList <Exame> examesMostrar = new ArrayList<>(); 
	ArrayList <Exame> examesP = new ArrayList<>(); 

	public ExameDAO() {
		this.connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Exame ex) {
		int inseriu = 0;
		
		String sql = "INSERT INTO gera_exame(Codigo_exame, CPF_veterina, CPF_Cliente, codigo_do_animal, data_hora) VALUES (?, ?, ?, ?, ?);";
		PreparedStatement stmt;
		try {
			stmt=(PreparedStatement) connection.prepareStatement(sql);
			stmt.setString(1, ex.getCodigo_exame());
			stmt.setString(2, ex.getCPF_Veterinario());
			stmt.setString(3, ex.getCPF_Cliente());
			stmt.setString(4, ex.getCodigo_animal());
			stmt.setString(5, ex.getData_hora());
			inseriu=stmt.executeUpdate();
			exames.add(ex);
			ex.addExame(ex);
			stmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
			}
		
		return inseriu;
		}
		
	
	public ArrayList <Exame> getLista(){ 
		String sql = "SELECT * FROM gera_exame;"; 
		PreparedStatement stmt; 
		Exame ex; 
		ArrayList <Exame> examesMostrar = new ArrayList<>(); 
		
			try { 
				stmt = connection.prepareStatement(sql); 
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				ex = new Exame(); 
				ex.setCodigo_exame(rs.getString("codigo_exame"));
				ex.setCPF_Veterinario(rs.getString("CPF_Veterina"));
				ex.setCPF_Cliente(rs.getString("CPF_Cliente"));
				ex.setCodigo_animal(rs.getString("codigo_do_animal"));
				ex.setData_hora(rs.getString("data_hora"));
				examesMostrar.add(ex);
			} 
				rs.close(); 
				stmt.close(); 
				return examesMostrar;
			} catch(SQLException e) { 
				e.printStackTrace(); 
			} 
			return null; 
	} 
	
	public ArrayList <Exame> getListaParametro(String cod_ex, String cpf_vet, String cpf_cli, String cod_a, String d_h){ 
		String sql = "SELECT * FROM gera_exame WHERE codigo_exame = ? and CPF_Veterina = ? and CPF_Cliente = ? and codigo_do_animal = ? and data_hora = ?;"; 
		PreparedStatement stmt; 
		Exame ex; 
		ArrayList <Exame> examesP = new ArrayList<>(); 
		
			try { 
				stmt = connection.prepareStatement(sql); 
				stmt.setString(1, cod_ex);
				stmt.setString(2 ,cpf_vet);
				stmt.setString(3, cpf_cli);
				stmt.setString(4, cod_a);
				stmt.setString(5, d_h);
				ResultSet rs = stmt.executeQuery(); 
				while (rs.next()) { 
				ex = new Exame(); 
				ex.setCodigo_exame(rs.getString("codigo_exame"));
				ex.setCPF_Veterinario(rs.getString("CPF_Veterina"));
				ex.setCPF_Cliente(rs.getString("CPF_Cliente"));
				ex.setCodigo_animal(rs.getString("codigo_do_animal"));
				ex.setData_hora(rs.getString("data_hora"));
				examesP.add(ex); 
			} 
				rs.close(); 
				stmt.close(); 
				return examesP; 
			} catch(SQLException e) { 
				e.printStackTrace(); 
			}
			return null; 
	} 
	
	
	public int remover(Exame ex) {
		int removeu = 0;
		String sql = "DELETE FROM gera_exame WHERE codigo_exame = ? and CPF_Veterina = ? and CPF_Cliente = ? and codigo_do_animal = ? and data_hora = ?;";
		PreparedStatement stmt;
		
			try {
				stmt = connection.prepareStatement(sql);
				stmt.setString(1, ex.getCodigo_exame());;
				stmt.setString(2, ex.getCPF_Veterinario());
				stmt.setString(3, ex.getCPF_Cliente());
				stmt.setString(4, ex.getCodigo_animal());
				stmt.setString(5, ex.getData_hora());
				removeu = stmt.executeUpdate();
				stmt.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
		}
			exames.remove(ex);
			examesMostrar.remove(ex);
			examesP.remove(ex);
		return removeu;
	}
	
	public int alterar(Exame ex, Exame ex2) { //Exames ex - Dados anteriores | Exame ex2 - Dados novos
		int alterou = 0; 
		boolean achou = false;
		PreparedStatement stmt;
		PreparedStatement stmt2;
		PreparedStatement stmt3;
		
		String cod_ex_antigo = "";
		String cpf_vet_antigo = "";
		String cpf_cli_antigo = "";
		String cod_a_antigo = "";
		String d_h_antigo = "";
		
		String codExTeste = "";
		String cpfVetTeste = "";
		String cpfCliTeste = "";
		String codATeste="";
		String DHTeste = "";
		
		
			String sql1 = "SELECT * FROM gera_exame WHERE codigo_exame = ? and CPF_Veterina = ? and CPF_Cliente = ? and "
					+ "codigo_do_animal = ? and data_hora = ?;";
			try {
				stmt = connection.prepareStatement(sql1);
				
					stmt.setString(1, ex.getCodigo_exame());
					stmt.setString(2, ex.getCPF_Veterinario());
					stmt.setString(3, ex.getCPF_Cliente());
					stmt.setString(4, ex.getCodigo_animal());
					stmt.setString(5, ex.getData_hora());
					ResultSet rs = stmt.executeQuery(); 
					while (rs.next()) { 
						cod_ex_antigo = rs.getString("codigo_exame");
						cpf_vet_antigo = rs.getString("CPF_Veterina");
						cpf_cli_antigo = rs.getString("CPF_Cliente");
						cod_a_antigo = rs.getString("codigo_do_animal");
						d_h_antigo = rs.getString("data_hora");
						achou = true;
						}
					}catch(SQLException e){
						e.printStackTrace();
					
					}
			try {
				String sql3 = 	"SELECT * FROM gera_exame WHERE codigo_exame = ? and CPF_Veterina = ? and CPF_Cliente = ? and "
						+ "codigo_do_animal = ? and data_hora = ?;";
				stmt3 = connection.prepareStatement(sql3);
				stmt3.setString(1, ex2.getCodigo_exame());
				stmt3.setString(2, ex2.getCPF_Veterinario());
				stmt3.setString(3, ex2.getCPF_Cliente());
				stmt3.setString(4, ex2.getCodigo_animal());
				stmt3.setString(5, ex2.getData_hora());
				ResultSet rs3 = stmt3.executeQuery(); 
				while (rs3.next()) {
					
					codExTeste = rs3.getString("codigo_exame");
					cpfVetTeste = rs3.getString("CPF_Veterina");
					cpfCliTeste = rs3.getString("CPF_Cliente");
					codATeste = rs3.getString("codigo_do_animal");
					DHTeste = rs3.getString("data_hora");
					
				}
					}catch(SQLException e){
						e.printStackTrace();
						
					}
		if(codExTeste.equals(ex2.getCodigo_exame()) && cpfVetTeste.equals(ex2.getCPF_Veterinario()) && cpfCliTeste.equals(ex2.getCPF_Cliente())
				&& codATeste.equals(ex2.getCodigo_animal()) && DHTeste.equals(ex2.getData_hora()))  {
			JOptionPane.showMessageDialog(null, "J� existe um registro de exame cadastrado com esses dados solicitados para altera��o", "Erro de duplica��o", JOptionPane.ERROR_MESSAGE, null);
			
		}else {
			if(achou) {
	
				String sql2 = "UPDATE gera_exame SET codigo_exame = ?, CPF_Veterina = ?, CPF_Cliente = ?, codigo_do_animal = ?, "
						+ "data_hora = ? WHERE codigo_exame = ? and CPF_Veterina = ? and "
						+ "CPF_Cliente = ? and codigo_do_animal = ? and data_hora = ?;";
					try {
					stmt2 = connection.prepareStatement(sql2);
					stmt2.setString(1, ex2.getCodigo_exame());
					stmt2.setString(2, ex2.getCPF_Veterinario());
					stmt2.setString(3, ex2.getCPF_Cliente());
					stmt2.setString(4, ex2.getCodigo_animal());
					stmt2.setString(5, ex2.getData_hora());
					
					stmt2.setString(6, cod_ex_antigo);
					stmt2.setString(7, cpf_vet_antigo);
					stmt2.setString(8, cpf_cli_antigo);
					stmt2.setString(9, cod_a_antigo);
					stmt2.setString(10, d_h_antigo);
					alterou = stmt2.executeUpdate();
					}catch(SQLException e){
						e.printStackTrace();
					
					}

			}
		exames.remove(ex);
		examesP.remove(ex);
		examesMostrar.remove(ex);
			}
		return alterou;
	}
		
		
	
	
	
	public Exame verificaEx(String cod_ex, String cpf_vet, String cpf_cli, String cod_a, String d_h) {
		Exame ex = null;
		String sql = "SELECT codigo_exame, CPF_Veterina, CPF_Cliente, codigo_do_animal, data_hora FROM gera_exame WHERE codigo_exame = ? and CPF_Veterina = ? and CPF_Cliente = ? and codigo_do_animal = ? and data_hora = ?;";
		PreparedStatement stmt;
			try {
				stmt=connection.prepareStatement(sql);
				stmt.setString(1, cod_ex);
				stmt.setString(2 ,cpf_vet);
				stmt.setString(3, cpf_cli);
				stmt.setString(4, cod_a);
				stmt.setString(5, d_h);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()) {
					ex = new Exame();
				}
				rs.close();
				stmt.close();
				//return verifica;
				
			}catch(SQLException e) {
				e.printStackTrace();
			
		}
		return ex;
	}

}
